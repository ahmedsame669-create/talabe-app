import React, { lazy, Suspense } from 'react';
import { useApp } from './context/AppContext';
import { Header } from './components/Header';
import { ShowcaseGalleryView } from './components/showcase/ShowcaseGalleryView';
import { MobileAppContainer } from './components/mobile/MobileAppContainer';
import { TalabatiAdminDashboard } from './components/admin/TalabatiAdminDashboard';
import { ToastContainer } from './components/Toast';
import { NotesModal } from './components/modals/NotesModal';
import { NotificationsModal } from './components/modals/NotificationsModal';
import { AboutModal } from './components/modals/AboutModal';
import { ActivationCodeModal } from './components/modals/ActivationCodeModal';
import { StudentLoginModal } from './components/modals/StudentLoginModal';
import { AddMinisterialQuestionModal } from './components/modals/AddMinisterialQuestionModal';
import { SupervisorLoginModal } from './components/modals/SupervisorLoginModal';
import { BookEditorModal } from './components/modals/BookEditorModal';
import {
  Loader2,
  Smartphone,
  LayoutDashboard,
  Grid,
  Sparkles,
  ArrowRight,
  BookOpen
} from 'lucide-react';

// Lazy loaded modals
const PaymentModal = lazy(() =>
  import('./components/PaymentModal').then((m) => ({ default: m.PaymentModal }))
);
const SampleViewerModal = lazy(() =>
  import('./components/SampleViewerModal').then((m) => ({ default: m.SampleViewerModal }))
);
const MyBooksModal = lazy(() =>
  import('./components/MyBooksModal').then((m) => ({ default: m.MyBooksModal }))
);
const OrderStatusModal = lazy(() =>
  import('./components/OrderStatusModal').then((m) => ({ default: m.OrderStatusModal }))
);
const MinisterialExamCountdown = lazy(() =>
  import('./components/MinisterialExamCountdown').then((m) => ({
    default: m.MinisterialExamCountdown,
  }))
);
const BookReaderView = lazy(() =>
  import('./components/BookReaderView').then((m) => ({ default: m.BookReaderView }))
);
const SelfQuizModal = lazy(() =>
  import('./components/SelfQuizModal').then((m) => ({ default: m.SelfQuizModal }))
);
const VideoTutorialModal = lazy(() =>
  import('./components/VideoTutorialModal').then((m) => ({ default: m.VideoTutorialModal }))
);
const InstallAppModal = lazy(() =>
  import('./components/InstallAppModal').then((m) => ({ default: m.InstallAppModal }))
);
const DeploymentHelperModal = lazy(() =>
  import('./components/DeploymentHelperModal').then((m) => ({
    default: m.DeploymentHelperModal,
  }))
);

export function App() {
  const {
    viewMode,
    setViewMode,
    activeReadingBook,
    setActiveReadingBook,
    activeModal,
    closeModal,
    selectedBookForQuiz,
    activeMobileScreen,
    setActiveMobileScreen
  } = useApp();

  // If reading an active book, show the full reader
  if (activeReadingBook) {
    return (
      <Suspense
        fallback={
          <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-white gap-3 font-['Tajawal']">
            <Loader2 className="w-8 h-8 text-blue-500 animate-spin" />
            <p className="text-xs font-bold text-slate-400">جاري فتح قارئ الكتب والمناهج...</p>
          </div>
        }
      >
        <BookReaderView
          book={activeReadingBook}
          onClose={() => setActiveReadingBook(null)}
        />
        <ToastContainer />
      </Suspense>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100 selection:bg-blue-600 selection:text-white font-['Tajawal','Cairo',sans-serif]">
      {/* Universal Header with Navigation & Mode Switchers */}
      <Header />

      {/* Main Viewport Router based on ViewMode */}
      <main className="flex-1 flex flex-col">
        {/* VIEW 1: Showcase Gallery (Matching exact uploaded image design layout) */}
        {viewMode === 'showcase-gallery' && <ShowcaseGalleryView />}

        {/* VIEW 2: Interactive Mobile Smartphone Simulator */}
        {viewMode === 'mobile-app' && (
          <div className="flex-1 py-8 px-4 flex flex-col items-center justify-center bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
            <div className="mb-4 text-center space-y-1">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-bold border border-blue-500/30">
                <Smartphone className="w-3.5 h-3.5" />
                <span>محاكي تطبيق منصة طلبتي التفاعلي 📱</span>
              </div>
              <h2 className="text-sm sm:text-base font-black text-white">
                تصفح الشاشات، حمّل الكتب بصيغة PDF، وجرّب الملاحظات والاختبارات
              </h2>
            </div>

            {/* Mobile Smartphone Frame */}
            <div className="w-full max-w-md flex justify-center">
              <MobileAppContainer />
            </div>
          </div>
        )}

        {/* VIEW 3: Full-width Admin Dashboard */}
        {viewMode === 'admin-dashboard' && <TalabatiAdminDashboard />}
      </main>

      {/* Modals & Dialogs */}
      <Suspense fallback={null}>
        <PaymentModal />
        <VideoTutorialModal />
        <InstallAppModal />
        <SampleViewerModal />
        <MyBooksModal />
        <OrderStatusModal />
        <MinisterialExamCountdown />
        <DeploymentHelperModal />
        <ActivationCodeModal />
        <StudentLoginModal />
        <AddMinisterialQuestionModal />
        <SupervisorLoginModal />
        <BookEditorModal />
        {activeModal === 'notes-modal' && <NotesModal />}
        {activeModal === 'notifications-modal' && <NotificationsModal />}
        {activeModal === 'about-modal' && <AboutModal />}
        {activeModal === 'quiz' && selectedBookForQuiz && (
          <SelfQuizModal
            book={selectedBookForQuiz}
            isOpen={true}
            onClose={closeModal}
            onOpenReader={() => {
              setActiveReadingBook(selectedBookForQuiz);
            }}
          />
        )}
      </Suspense>

      {/* Toast Notification Container */}
      <ToastContainer />
    </div>
  );
}

export default App;
