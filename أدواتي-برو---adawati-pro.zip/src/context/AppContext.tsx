import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  BookItem,
  Order,
  PaymentInfo,
  SubjectCategory,
  EducationalStage,
  UserProfile,
  StudyNote,
  NotificationItem,
  ActivationCode,
  RegisteredStudent,
  MinisterialQuestionItem
} from '../types';
import {
  INITIAL_BOOKS,
  INITIAL_PAYMENT_INFO,
  INITIAL_NOTIFICATIONS,
  INITIAL_STUDY_NOTES,
  INITIAL_ACTIVATION_CODES,
  INITIAL_REGISTERED_STUDENTS
} from '../data/booksData';

export type AppViewMode = 'mobile-app' | 'admin-dashboard' | 'showcase-gallery' | 'web-platform';
export type MobileScreenType = 'login' | 'home' | 'library' | 'details' | 'profile';

export type ModalType =
  | null
  | 'payment'
  | 'sample'
  | 'my-books'
  | 'order-status'
  | 'exam-countdown'
  | 'admin'
  | 'deploy-guide'
  | 'quiz'
  | 'video-tutorial'
  | 'install-app'
  | 'add-book-modal'
  | 'notes-modal'
  | 'notifications-modal'
  | 'about-modal'
  | 'activation-code'
  | 'student-login-modal'
  | 'supervisor-login'
  | 'book-editor'
  | 'add-ministerial-question-modal';

interface ToastMessage {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

interface AppContextType {
  // Books & Filtering
  books: BookItem[];
  setBooks: React.Dispatch<React.SetStateAction<BookItem[]>>;
  selectedCategory: SubjectCategory;
  setSelectedCategory: (cat: SubjectCategory) => void;
  selectedGrade: EducationalStage;
  setSelectedGrade: (grade: EducationalStage) => void;
  selectedYear: string;
  setSelectedYear: (year: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;

  // View & Screen Modes
  viewMode: AppViewMode;
  setViewMode: (mode: AppViewMode) => void;
  activeMobileScreen: MobileScreenType;
  setActiveMobileScreen: (screen: MobileScreenType) => void;
  activeBookDetails: BookItem | null;
  setActiveBookDetails: (book: BookItem | null) => void;

  // Modals & Reader
  activeModal: ModalType;
  openModal: (modal: ModalType) => void;
  closeModal: () => void;
  selectedBookForPay: BookItem | null;
  openPayModalForBook: (book: BookItem) => void;
  selectedBookForSample: BookItem | null;
  openSampleModalForBook: (book: BookItem) => void;
  selectedBookForQuiz: BookItem | null;
  openQuizModalForBook: (book: BookItem) => void;
  activeReadingBook: BookItem | null;
  setActiveReadingBook: (book: BookItem | null) => void;

  // User Profile & Auth
  user: UserProfile;
  setUser: React.Dispatch<React.SetStateAction<UserProfile>>;
  isLoggedIn: boolean;
  loginUser: (phone: string, name?: string, grade?: string, governorate?: string) => void;
  logoutUser: () => void;
  isAdminLoggedIn: boolean;
  setIsAdminLoggedIn: (val: boolean) => void;
  adminLogin: (pass: string) => boolean;
  adminLogout: () => void;

  // Registered Students Management
  registeredStudents: RegisteredStudent[];
  addRegisteredStudent: (student: Omit<RegisteredStudent, 'id' | 'registeredAt' | 'lastActive' | 'unlockedSubjectsCount'>) => void;
  deleteRegisteredStudent: (id: string) => void;

  // User Library, Favorites, Downloads
  favoriteBookIds: number[];
  toggleFavorite: (bookId: number) => void;
  downloadedBookIds: number[];
  downloadBook: (book: BookItem) => Promise<void>;
  downloadProgress: { [bookId: number]: number };
  unlockedBookIds: number[];
  isBookUnlocked: (bookId: number) => boolean;
  unlockBookDirectly: (bookId: number | 'all') => void;
  lockBook: (bookId: number) => void;
  lockAllBooks: () => void;

  // Activation Codes System
  activationCodes: ActivationCode[];
  generateActivationCode: (bookId: number | 'all', studentName?: string, studentPhone?: string) => ActivationCode;
  redeemActivationCode: (codeString: string) => { success: boolean; message: string; bookId?: number | 'all' };
  deleteActivationCode: (id: string) => void;

  // Notes & Notifications
  studyNotes: StudyNote[];
  addStudyNote: (note: Omit<StudyNote, 'id' | 'date'>) => void;
  deleteStudyNote: (id: string) => void;
  notifications: NotificationItem[];
  markNotificationAsRead: (id: string) => void;
  unreadNotificationsCount: number;

  // Payment & Orders
  paymentInfo: PaymentInfo;
  orders: Order[];
  createOrder: (orderData: {
    student_name: string;
    phone: string;
    governorate: string;
    book_id: number;
    book_title: string;
    payment_method: any;
    transaction_ref: string;
    receipt_img?: string;
  }) => Promise<{ success: boolean; message: string }>;
  approveOrder: (orderId: string) => void;
  rejectOrder: (orderId: string, reason?: string) => void;
  updatePaymentInfo: (newInfo: Partial<PaymentInfo>) => void;
  addNewBook: (book: BookItem) => void;
  updateBook: (bookId: number, updatedData: Partial<BookItem>) => void;
  deleteBook: (bookId: number) => void;
  resetBooksToDefault: () => void;
  editingBook: BookItem | null;
  setEditingBook: (b: BookItem | null) => void;
  openBookEditorForBook: (b: BookItem) => void;
  addMinisterialQuestionToBook: (bookId: number, question: Omit<MinisterialQuestionItem, 'id'>) => void;
  deleteMinisterialQuestion: (bookId: number, questionId: number) => void;

  // Supervisor (Super Admin) System
  isSupervisor: boolean;
  verifySupervisorCode: (code: string) => boolean;
  exitSupervisorMode: () => void;
  SUPERVISOR_CODES: string[];

  // Notifications / Toasts
  toasts: ToastMessage[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;

  // PWA
  deferredPrompt: any;
  isInstallable: boolean;
  isInstalled: boolean;
  isIOS: boolean;
  isAndroid: boolean;
  promptInstall: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const LOCAL_STORAGE_BOOKS_KEY = 'talabati_books_catalog_v5';
const LOCAL_STORAGE_FAVORITES_KEY = 'talabati_favorites_v4';
const LOCAL_STORAGE_DOWNLOADS_KEY = 'talabati_downloads_v4';
const LOCAL_STORAGE_ORDERS_KEY = 'talabati_orders_v4';
const LOCAL_STORAGE_NOTES_KEY = 'talabati_notes_v4';
const LOCAL_STORAGE_USER_KEY = 'talabati_user_v4';
const LOCAL_STORAGE_UNLOCKED_KEY = 'talabati_unlocked_books_v5';
const LOCAL_STORAGE_CODES_KEY = 'talabati_activation_codes_v4';
const LOCAL_STORAGE_STUDENTS_KEY = 'talabati_registered_students_v4';
const LOCAL_STORAGE_ADMIN_KEY = 'talabati_admin_logged_v4';
const LOCAL_STORAGE_SUPERVISOR_KEY = 'talabati_supervisor_mode_v5';

const SUPERVISOR_CODES = [
  'SUPERVISOR2026',
  'ADMIN2026',
  'TALABATI2026',
  'IRAQ3RD',
  '123456',
  'TALABATI_SUPER'
];

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Books Catalog with automatic sync of new subjects
  const [books, setBooks] = useState<BookItem[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_BOOKS_KEY);
      if (saved) {
        const parsed: BookItem[] = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Merge with any new initial books that don't exist in parsed
          const existingIds = new Set(parsed.map((b) => b.id));
          const missingInitial = INITIAL_BOOKS.filter((b) => !existingIds.has(b.id));
          return [...parsed, ...missingInitial];
        }
      }
    } catch {}
    return INITIAL_BOOKS;
  });

  const [selectedCategory, setSelectedCategory] = useState<SubjectCategory>('all');
  const [selectedGrade, setSelectedGrade] = useState<EducationalStage>('all');
  const [selectedYear, setSelectedYear] = useState<string>('الكل');
  const [searchQuery, setSearchQuery] = useState('');

  // Supervisor (Super Admin) State
  const [isSupervisor, setIsSupervisor] = useState<boolean>(() => {
    try {
      return localStorage.getItem(LOCAL_STORAGE_SUPERVISOR_KEY) === 'true';
    } catch {
      return false;
    }
  });

  const [editingBook, setEditingBook] = useState<BookItem | null>(null);

  // Views & Mobile state
  const [viewMode, setViewMode] = useState<AppViewMode>('showcase-gallery');
  const [activeMobileScreen, setActiveMobileScreen] = useState<MobileScreenType>('home');
  const [activeBookDetails, setActiveBookDetails] = useState<BookItem | null>(() => INITIAL_BOOKS[0] || null);

  // Modal & Reader
  const [activeModal, setActiveModal] = useState<ModalType>(null);
  const [selectedBookForPay, setSelectedBookForPay] = useState<BookItem | null>(null);
  const [selectedBookForSample, setSelectedBookForSample] = useState<BookItem | null>(null);
  const [selectedBookForQuiz, setSelectedBookForQuiz] = useState<BookItem | null>(null);
  const [activeReadingBook, setActiveReadingBook] = useState<BookItem | null>(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Admin Auth
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(() => {
    return localStorage.getItem(LOCAL_STORAGE_ADMIN_KEY) === 'true';
  });

  const adminLogin = (pass: string): boolean => {
    const clean = pass.trim().toUpperCase();
    if (clean === 'TALABATI2026' || clean === 'ADMIN' || clean === '123456' || SUPERVISOR_CODES.includes(clean)) {
      setIsAdminLoggedIn(true);
      localStorage.setItem(LOCAL_STORAGE_ADMIN_KEY, 'true');
      showToast('مرحباً بك في لوحة الإدارة لمنصة طلبتي 🛡️', 'success');
      return true;
    } else {
      showToast('كلمة مرور الإدارة غير صحيحة! (جرب talabati2026 أو SUPERVISOR2026)', 'error');
      return false;
    }
  };

  const adminLogout = () => {
    setIsAdminLoggedIn(false);
    localStorage.removeItem(LOCAL_STORAGE_ADMIN_KEY);
    showToast('تم تسجيل خروج الإدارة بنجاح', 'info');
  };

  // Supervisor Super Admin Verification
  const verifySupervisorCode = (code: string): boolean => {
    const clean = code.trim().toUpperCase();
    if (SUPERVISOR_CODES.includes(clean)) {
      setIsSupervisor(true);
      setIsAdminLoggedIn(true);
      localStorage.setItem(LOCAL_STORAGE_SUPERVISOR_KEY, 'true');
      localStorage.setItem(LOCAL_STORAGE_ADMIN_KEY, 'true');
      showToast('👑 تم تفعيل كود المشرف العام بنجاح! لديك الآن كافة الصلاحيات لتعديل الكتب والمناهج', 'success');
      return true;
    } else {
      showToast('كود المشرف غير صحيح! تأكد من الكود المعتمد (مثال: SUPERVISOR2026 أو 123456)', 'error');
      return false;
    }
  };

  const exitSupervisorMode = () => {
    setIsSupervisor(false);
    localStorage.removeItem(LOCAL_STORAGE_SUPERVISOR_KEY);
    showToast('تم إيقاف وضع المشرف العام', 'info');
  };

  const openBookEditorForBook = (book: BookItem) => {
    setEditingBook(book);
    setActiveModal('book-editor');
  };

  // User Profile
  const [user, setUser] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_USER_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      name: 'طالب منصة طلبتي',
      email: 'student@talabati.iq',
      role: 'طالب',
      badge: 'طالب مسجل ⭐',
      grade: 'الثالث متوسط',
      phone: '07734378998',
      governorate: 'بغداد',
      joinedDate: '2026-08-24'
    };
  });

  const [isLoggedIn, setIsLoggedIn] = useState(true);

  // Registered Students State
  const [registeredStudents, setRegisteredStudents] = useState<RegisteredStudent[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_STUDENTS_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return INITIAL_REGISTERED_STUDENTS;
  });

  // Favorites
  const [favoriteBookIds, setFavoriteBookIds] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_FAVORITES_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [1, 11, 21];
  });

  // Downloads
  const [downloadedBookIds, setDownloadedBookIds] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_DOWNLOADS_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [];
  });
  const [downloadProgress, setDownloadProgress] = useState<{ [bookId: number]: number }>({});

  // Study Notes
  const [studyNotes, setStudyNotes] = useState<StudyNote[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_NOTES_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return INITIAL_STUDY_NOTES;
  });

  // Notifications
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);

  // Payment Info (Price 10,000 د.ع and phone 07734378998)
  const [paymentInfo, setPaymentInfo] = useState<PaymentInfo>(INITIAL_PAYMENT_INFO);

  // Activation Codes State
  const [activationCodes, setActivationCodes] = useState<ActivationCode[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_CODES_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return INITIAL_ACTIVATION_CODES;
  });

  // Orders
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_ORDERS_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: 'ORD-9021',
        student_name: 'أحمد سامي',
        phone: '07734378998',
        governorate: 'بغداد - الكرخ',
        book_id: 1,
        book_title: 'الرياضيات - الثالث متوسط',
        payment_method: 'زين كاش',
        transaction_ref: 'ZC-2026-9812',
        price: '10,000 د.ع',
        status: 'تم التفعيل والفتح',
        created_at: new Date(Date.now() - 3600000 * 2).toLocaleString('ar-IQ'),
      },
      {
        id: 'ORD-9022',
        student_name: 'فاطمة حيدر',
        phone: '07801234567',
        governorate: 'النجف الأشرف',
        book_id: 11,
        book_title: 'الرياضيات - السادس العلمي',
        payment_method: 'زين كاش',
        transaction_ref: 'ZC-991204',
        price: '10,000 د.ع',
        status: 'تم التفعيل والفتح',
        created_at: new Date(Date.now() - 3600000 * 5).toLocaleString('ar-IQ'),
      }
    ];
  });

  // Unlocked Books State: Initially empty [] or specific IDs so EVERY MATERIAL IS LOCKED by default (10,000 IQD or Code to open)
  const [unlockedBookIds, setUnlockedBookIds] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_UNLOCKED_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return []; // All locked by default
  });

  // Sync state to local storage
  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_BOOKS_KEY, JSON.stringify(books));
  }, [books]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_FAVORITES_KEY, JSON.stringify(favoriteBookIds));
  }, [favoriteBookIds]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_DOWNLOADS_KEY, JSON.stringify(downloadedBookIds));
  }, [downloadedBookIds]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_NOTES_KEY, JSON.stringify(studyNotes));
  }, [studyNotes]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_UNLOCKED_KEY, JSON.stringify(unlockedBookIds));
  }, [unlockedBookIds]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_CODES_KEY, JSON.stringify(activationCodes));
  }, [activationCodes]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_STUDENTS_KEY, JSON.stringify(registeredStudents));
  }, [registeredStudents]);

  // Toasts
  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Modals
  const openModal = (modal: ModalType) => {
    setActiveModal(modal);
  };

  const closeModal = () => {
    setActiveModal(null);
    setSelectedBookForPay(null);
    setSelectedBookForSample(null);
    setSelectedBookForQuiz(null);
  };

  const openPayModalForBook = (book: BookItem) => {
    setSelectedBookForPay(book);
    setActiveModal('payment');
  };

  const openSampleModalForBook = (book: BookItem) => {
    setSelectedBookForSample(book);
    setActiveModal('sample');
  };

  const openQuizModalForBook = (book: BookItem) => {
    setSelectedBookForQuiz(book);
    setActiveModal('quiz');
  };

  // Toggle Favorite
  const toggleFavorite = (bookId: number) => {
    setFavoriteBookIds((prev) => {
      const exists = prev.includes(bookId);
      if (exists) {
        showToast('تمت إزالة المادة من المفضلة', 'info');
        return prev.filter((id) => id !== bookId);
      } else {
        showToast('تمت إضافة المادة للمفضلة بنجاح ❤️', 'success');
        return [...prev, bookId];
      }
    });
  };

  // Check if a book is unlocked (Supervisor has VIP access to all books)
  const isBookUnlocked = (bookId: number) => {
    if (isSupervisor) return true;
    return unlockedBookIds.includes(bookId) || unlockedBookIds.includes(-1);
  };

  // Direct unlock book
  const unlockBookDirectly = (bookId: number | 'all') => {
    if (bookId === 'all') {
      const allIds = books.map((b) => b.id);
      allIds.push(-1);
      setUnlockedBookIds(allIds);
      showToast('🎉 تم فتح جميع المواد والمناهج بنجاح (VIP)!', 'success');
    } else {
      setUnlockedBookIds((prev) => (prev.includes(bookId) ? prev : [...prev, bookId]));
      const book = books.find((b) => b.id === bookId);
      showToast(`🎉 تم فتح مادة "${book?.title || 'المختارة'}" بنجاح!`, 'success');
    }
  };

  // Lock specific book
  const lockBook = (bookId: number) => {
    setUnlockedBookIds((prev) => prev.filter((id) => id !== bookId && id !== -1));
    showToast('تم قفل المادة بنجاح 🔒', 'info');
  };

  // Lock all books
  const lockAllBooks = () => {
    setUnlockedBookIds([]);
    showToast('تم قفل جميع المواد في منصة طلبتي بنجاح 🔒', 'info');
  };

  // Add registered student
  const addRegisteredStudent = (studentData: Omit<RegisteredStudent, 'id' | 'registeredAt' | 'lastActive' | 'unlockedSubjectsCount'>) => {
    const newStudent: RegisteredStudent = {
      ...studentData,
      id: `std-${Date.now()}`,
      registeredAt: new Date().toISOString().split('T')[0],
      lastActive: 'الآن',
      unlockedSubjectsCount: unlockedBookIds.length
    };
    setRegisteredStudents((prev) => [newStudent, ...prev]);
  };

  const deleteRegisteredStudent = (id: string) => {
    setRegisteredStudents((prev) => prev.filter((s) => s.id !== id));
    showToast('تم حذف بيانات الطالب بنجاح', 'info');
  };

  // Activation Code Generator (Admin)
  const generateActivationCode = (bookId: number | 'all', studentName?: string, studentPhone?: string): ActivationCode => {
    const book = bookId === 'all' ? null : books.find((b) => b.id === bookId);
    const bookTitle = bookId === 'all' ? 'جميع المواد والمناهج المعتمدة (اشتراك VIP شامل)' : (book?.title || `المادة رقم ${bookId}`);
    
    // Generate readable code: TAL-2026-XXXX or TAL-VIP-XXXX
    const randomSuffix = Math.floor(1000 + Math.random() * 9000).toString();
    const tag = bookId === 'all' ? 'VIP' : (book?.category?.slice(0, 4) || 'SUB').toUpperCase();
    const generatedCode = `TAL-${tag}-${randomSuffix}`;

    const newCodeItem: ActivationCode = {
      id: `act-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      code: generatedCode,
      bookId,
      bookTitle,
      studentName: studentName || 'طالب منصة طلبتي',
      studentPhone: studentPhone || '07734378998',
      isUsed: false,
      createdAt: new Date().toISOString().split('T')[0],
      createdBy: 'مدير منصة طلبتي'
    };

    setActivationCodes((prev) => [newCodeItem, ...prev]);
    showToast(`تم إنشاء كود التفعيل بنجاح: ${generatedCode} 🔑`, 'success');
    return newCodeItem;
  };

  // Redeem Activation Code (Student)
  const redeemActivationCode = (codeString: string): { success: boolean; message: string; bookId?: number | 'all' } => {
    const clean = codeString.trim().toUpperCase();
    if (!clean) {
      return { success: false, message: 'يرجى إدخال كود التفعيل' };
    }

    const foundCode = activationCodes.find((c) => c.code.toUpperCase() === clean);

    if (!foundCode) {
      return {
        success: false,
        message: 'كود التفعيل غير صحيح! يرجى التأكد من الكود أو مراسلة الدعم على الواتساب 07734378998.'
      };
    }

    if (foundCode.isUsed) {
      return {
        success: false,
        message: `تم استخدام هذا الكود سابقاً بتاريخ ${foundCode.usedAt || 'سابقاً'} بواسطة ${foundCode.usedBy || 'طالب آخر'}.`
      };
    }

    // Mark code as used
    setActivationCodes((prev) =>
      prev.map((c) =>
        c.id === foundCode.id
          ? {
              ...c,
              isUsed: true,
              usedBy: user.name || 'طالب',
              usedAt: new Date().toISOString().split('T')[0]
            }
          : c
      )
    );

    // Unlock the book
    unlockBookDirectly(foundCode.bookId);

    // Create confirmation order
    const confirmationOrder: Order = {
      id: `ORD-CODE-${Math.floor(1000 + Math.random() * 9000)}`,
      student_name: user.name || foundCode.studentName || 'طالب',
      phone: foundCode.studentPhone || user.phone || '07734378998',
      governorate: user.governorate || 'العراق',
      book_id: foundCode.bookId === 'all' ? 1 : foundCode.bookId,
      book_title: foundCode.bookTitle,
      payment_method: 'تحميل مجاني',
      transaction_ref: `CODE:${clean}`,
      price: '10,000 د.ع (كود تفعيل)',
      status: 'تم التفعيل والفتح',
      created_at: new Date().toLocaleString('ar-IQ'),
    };
    setOrders((prev) => [confirmationOrder, ...prev]);

    return {
      success: true,
      message: `مبروك! تم تفعيل وفتح "${foundCode.bookTitle}" بنجاح 🎓`,
      bookId: foundCode.bookId
    };
  };

  // Delete Activation Code
  const deleteActivationCode = (id: string) => {
    setActivationCodes((prev) => prev.filter((c) => c.id !== id));
    showToast('تم حذف كود التفعيل', 'info');
  };

  // Simulated Download Book
  const downloadBook = async (book: BookItem) => {
    if (!isBookUnlocked(book.id)) {
      showToast(`مادة "${book.title}" مقفلة. يرجى تفعيلها بـ 10,000 د.ع أو إدخال كود التفعيل للتحميل 🔒`, 'error');
      openPayModalForBook(book);
      return;
    }

    if (downloadedBookIds.includes(book.id)) {
      showToast(`كتاب ${book.title} تم تحميله مسبقاً وجاهز للقراءة أوفلاين 📥`, 'info');
      return;
    }

    showToast(`بدأ تحميل كتاب ${book.title} بصيغة PDF...`, 'info');

    for (let progress = 15; progress <= 100; progress += 25) {
      setDownloadProgress((prev) => ({ ...prev, [book.id]: progress }));
      await new Promise((r) => setTimeout(r, 180));
    }

    setDownloadedBookIds((prev) => [...prev, book.id]);
    setDownloadProgress((prev) => {
      const updated = { ...prev };
      delete updated[book.id];
      return updated;
    });

    setBooks((prev) =>
      prev.map((b) => (b.id === book.id ? { ...b, downloadsCount: b.downloadsCount + 1 } : b))
    );

    showToast(`تم اكتمال تحميل "${book.title}" بنجاح! 📥✅`, 'success');
  };

  // Study Notes CRUD
  const addStudyNote = (note: Omit<StudyNote, 'id' | 'date'>) => {
    const newNote: StudyNote = {
      ...note,
      id: `sn-${Date.now()}`,
      date: new Date().toISOString().split('T')[0]
    };
    setStudyNotes((prev) => [newNote, ...prev]);
    showToast('تمت إضافة الملاحظة الدراسية بنجاح 📝', 'success');
  };

  const deleteStudyNote = (id: string) => {
    setStudyNotes((prev) => prev.filter((n) => n.id !== id));
    showToast('تم حذف الملاحظة بنجاح', 'info');
  };

  // Notifications
  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const unreadNotificationsCount = notifications.filter((n) => !n.read).length;

  // Student Auth
  const loginUser = (phone: string, name?: string, grade?: string, governorate?: string) => {
    const userName = name || 'طالب منصة طلبتي';
    const userGrade = grade || 'الثالث متوسط';
    const userGov = governorate || 'بغداد';

    const profile: UserProfile = {
      name: userName,
      email: `${phone}@talabati.iq`,
      role: 'طالب',
      badge: 'طالب مسجل ⭐',
      grade: userGrade,
      phone: phone,
      governorate: userGov,
      joinedDate: new Date().toISOString().split('T')[0]
    };

    setUser(profile);
    setIsLoggedIn(true);

    // Also register in registeredStudents list if not exists
    setRegisteredStudents((prev) => {
      const exists = prev.find((s) => s.phone === phone);
      if (exists) {
        return prev.map((s) => (s.phone === phone ? { ...s, lastActive: 'الآن', grade: userGrade, name: userName } : s));
      }
      return [
        {
          id: `std-${Date.now()}`,
          name: userName,
          phone: phone,
          governorate: userGov,
          grade: userGrade,
          registeredAt: new Date().toISOString().split('T')[0],
          unlockedSubjectsCount: unlockedBookIds.length,
          lastActive: 'الآن',
          status: 'نشط'
        },
        ...prev
      ];
    });

    showToast(`مرحباً بك مجدداً ${userName} في منصة طلبتي! 👋`, 'success');
  };

  const logoutUser = () => {
    setIsLoggedIn(false);
    showToast('تم تسجيل الخروج بنجاح', 'info');
  };

  // Create Order
  const createOrder = async (orderData: {
    student_name: string;
    phone: string;
    governorate: string;
    book_id: number;
    book_title: string;
    payment_method: any;
    transaction_ref: string;
    receipt_img?: string;
  }) => {
    const newOrder: Order = {
      id: `ORD-${Math.floor(1000 + Math.random() * 9000)}`,
      student_name: orderData.student_name,
      phone: orderData.phone,
      governorate: orderData.governorate,
      book_id: orderData.book_id,
      book_title: orderData.book_title,
      payment_method: orderData.payment_method,
      transaction_ref: orderData.transaction_ref,
      price: paymentInfo.price,
      status: 'قيد التحقق',
      created_at: new Date().toLocaleString('ar-IQ'),
      receipt_img: orderData.receipt_img,
    };

    setOrders((prev) => [newOrder, ...prev]);

    return {
      success: true,
      message: 'تم إرسال طلبك بنجاح! سيتم تزويدك بكود التفعيل فور تأكيد الحوالة.',
    };
  };

  const approveOrder = (orderId: string) => {
    let approvedBookId: number | null = null;
    let studentPhone = '07734378998';
    let studentName = 'طالب';

    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id === orderId) {
          approvedBookId = ord.book_id;
          studentPhone = ord.phone;
          studentName = ord.student_name;
          if (!unlockedBookIds.includes(ord.book_id)) {
            setUnlockedBookIds((ids) => [...ids, ord.book_id]);
          }
          return { ...ord, status: 'تم التفعيل والفتح' };
        }
        return ord;
      })
    );

    if (approvedBookId) {
      generateActivationCode(approvedBookId, studentName, studentPhone);
    }

    showToast('تمت الموافقة وتفعيل المادة وإنشاء كود التفعيل بنجاح 🎉', 'success');
  };

  const rejectOrder = (orderId: string, reason?: string) => {
    setOrders((prev) =>
      prev.map((ord) => (ord.id === orderId ? { ...ord, status: 'مرفوض', admin_notes: reason } : ord))
    );
    showToast('تم تحديث حالة الطلب إلى مرفوض', 'info');
  };

  const updatePaymentInfo = (newInfo: Partial<PaymentInfo>) => {
    setPaymentInfo((prev) => ({ ...prev, ...newInfo }));
    showToast('تم حفظ تفاصيل الدفع والواتساب بنجاح ✅', 'success');
  };

  const addNewBook = (book: BookItem) => {
    setBooks((prev) => [book, ...prev]);
    showToast('تمت إضافة المادة الجديدة بنجاح 📚', 'success');
  };

  const updateBook = (bookId: number, updatedData: Partial<BookItem>) => {
    setBooks((prev) =>
      prev.map((b) => {
        if (b.id === bookId) {
          const updatedBook = {
            ...b,
            ...updatedData,
            lastEditedBy: 'المشرف العام',
            lastEditedAt: new Date().toLocaleString('ar-IQ')
          };
          return updatedBook;
        }
        return b;
      })
    );

    setActiveBookDetails((prev) => {
      if (prev && prev.id === bookId) {
        return {
          ...prev,
          ...updatedData,
          lastEditedBy: 'المشرف العام',
          lastEditedAt: new Date().toLocaleString('ar-IQ')
        };
      }
      return prev;
    });

    setActiveReadingBook((prev) => {
      if (prev && prev.id === bookId) {
        return {
          ...prev,
          ...updatedData,
          lastEditedBy: 'المشرف العام',
          lastEditedAt: new Date().toLocaleString('ar-IQ')
        };
      }
      return prev;
    });

    showToast('تم حفظ كافة تعديلات المادة وتحديثها بالمنصة بنجاح 💾✨', 'success');
  };

  const resetBooksToDefault = () => {
    setBooks(INITIAL_BOOKS);
    localStorage.setItem(LOCAL_STORAGE_BOOKS_KEY, JSON.stringify(INITIAL_BOOKS));
    showToast('تمت استعادة كافة المناهج والكتب الأصلية بنجاح 🔄', 'info');
  };

  const deleteBook = (bookId: number) => {
    setBooks((prev) => prev.filter((b) => b.id !== bookId));
    showToast('تم حذف المادة بنجاح', 'info');
  };

  const addMinisterialQuestionToBook = (bookId: number, question: Omit<MinisterialQuestionItem, 'id'>) => {
    setBooks((prev) =>
      prev.map((b) => {
        if (b.id === bookId) {
          const currentArchive = b.ministerialArchive || [];
          const newQ: MinisterialQuestionItem = {
            ...question,
            id: Date.now()
          };
          return {
            ...b,
            ministerialArchive: [newQ, ...currentArchive]
          };
        }
        return b;
      })
    );
    showToast('تمت إضافة السؤال الوزاري/المرشح بنجاح 🎯', 'success');
  };

  const deleteMinisterialQuestion = (bookId: number, questionId: number) => {
    setBooks((prev) =>
      prev.map((b) => {
        if (b.id === bookId) {
          return {
            ...b,
            ministerialArchive: (b.ministerialArchive || []).filter((q) => q.id !== questionId)
          };
        }
        return b;
      })
    );
    showToast('تم حذف السؤال بنجاح', 'info');
  };

  // PWA
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState<boolean>(false);
  const [isInstalled, setIsInstalled] = useState<boolean>(false);
  const [isIOS, setIsIOS] = useState<boolean>(false);
  const [isAndroid, setIsAndroid] = useState<boolean>(false);

  useEffect(() => {
    const checkStandalone = () => {
      const isStandalone =
        window.matchMedia('(display-mode: standalone)').matches ||
        (window.navigator as any).standalone === true;
      setIsInstalled(isStandalone);
    };
    checkStandalone();

    const ua = window.navigator.userAgent.toLowerCase();
    const isAppleDevice = /iphone|ipad|ipod|macintosh/.test(ua) && ((window.navigator as any).maxTouchPoints > 1 || /iphone|ipad|ipod/.test(ua));
    const isAndroidDevice = /android/.test(ua);
    setIsIOS(isAppleDevice);
    setIsAndroid(isAndroidDevice);

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setIsInstallable(false);
      setDeferredPrompt(null);
      showToast('تم تثبيت تطبيق منصة طلبتي على جهازك بنجاح! 📱🎉', 'success');
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const promptInstall = async () => {
    if (deferredPrompt) {
      try {
        deferredPrompt.prompt();
        const choiceResult = await deferredPrompt.userChoice;
        if (choiceResult.outcome === 'accepted') {
          showToast('جاري تثبيت تطبيق منصة طلبتي...', 'info');
        }
        setDeferredPrompt(null);
      } catch (err) {
        setActiveModal('install-app');
      }
    } else {
      setActiveModal('install-app');
    }
  };

  return (
    <AppContext.Provider
      value={{
        books,
        setBooks,
        selectedCategory,
        setSelectedCategory,
        selectedGrade,
        setSelectedGrade,
        selectedYear,
        setSelectedYear,
        searchQuery,
        setSearchQuery,
        viewMode,
        setViewMode,
        activeMobileScreen,
        setActiveMobileScreen,
        activeBookDetails,
        setActiveBookDetails,
        activeModal,
        openModal,
        closeModal,
        selectedBookForPay,
        openPayModalForBook,
        selectedBookForSample,
        openSampleModalForBook,
        selectedBookForQuiz,
        openQuizModalForBook,
        activeReadingBook,
        setActiveReadingBook,
        user,
        setUser,
        isLoggedIn,
        loginUser,
        logoutUser,
        isAdminLoggedIn,
        setIsAdminLoggedIn,
        adminLogin,
        adminLogout,
        registeredStudents,
        addRegisteredStudent,
        deleteRegisteredStudent,
        favoriteBookIds,
        toggleFavorite,
        downloadedBookIds,
        downloadBook,
        downloadProgress,
        studyNotes,
        addStudyNote,
        deleteStudyNote,
        notifications,
        markNotificationAsRead,
        unreadNotificationsCount,
        paymentInfo,
        orders,
        createOrder,
        approveOrder,
        rejectOrder,
        updatePaymentInfo,
        addNewBook,
        updateBook,
        deleteBook,
        resetBooksToDefault,
        editingBook,
        setEditingBook,
        openBookEditorForBook,
        addMinisterialQuestionToBook,
        deleteMinisterialQuestion,
        isSupervisor,
        verifySupervisorCode,
        exitSupervisorMode,
        SUPERVISOR_CODES,
        unlockedBookIds,
        isBookUnlocked,
        unlockBookDirectly,
        lockBook,
        lockAllBooks,
        activationCodes,
        generateActivationCode,
        redeemActivationCode,
        deleteActivationCode,
        toasts,
        showToast,
        removeToast,
        deferredPrompt,
        isInstallable,
        isInstalled,
        isIOS,
        isAndroid,
        promptInstall,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
