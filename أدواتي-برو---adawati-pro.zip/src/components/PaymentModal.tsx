import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PaymentMethod } from '../types';
import confetti from 'canvas-confetti';
import {
  X,
  Copy,
  Check,
  Smartphone,
  CreditCard,
  Lock,
  Unlock,
  ShieldCheck,
  CheckCircle2,
  BookOpen,
  Send,
  PlayCircle,
  KeyRound,
  Sparkles,
  HelpCircle,
  PhoneCall
} from 'lucide-react';

export const PaymentModal: React.FC = () => {
  const {
    activeModal,
    closeModal,
    openModal,
    selectedBookForPay,
    paymentInfo,
    createOrder,
    setActiveReadingBook,
    showToast,
    unlockedBookIds,
    redeemActivationCode,
    unlockBookDirectly,
  } = useApp();

  // Tab mode: 'transfer' (تحويل بنكي / سوبر كي / آسيا حوالة / زين كاش) | 'activation_code' (إدخال كود التفعيل)
  const [activeTab, setActiveTab] = useState<'transfer' | 'code'>('transfer');

  // Payment method options:
  // 1. سوبر كي / ماستر كارد الرافدين
  // 2. آسيا حوالة
  // 3. زين كاش
  const [paymentMethod, setPaymentMethod] = useState<string>('سوبر كي / ماستر كارد الرافدين');
  
  // Student form info
  const [studentName, setStudentName] = useState('');
  const [phone, setPhone] = useState('');
  const [governorate, setGovernorate] = useState('بغداد');
  const [transRef, setTransRef] = useState('');

  // Activation Code input
  const [activationCode, setActivationCode] = useState('');
  const [isVerifyingCode, setIsVerifyingCode] = useState(false);

  // Status and submission states
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isOrderSubmitted, setIsOrderSubmitted] = useState(false);
  const [copiedType, setCopiedType] = useState<string | null>(null);

  if (activeModal !== 'payment' || !selectedBookForPay) return null;

  const handleCopy = (text: string, typeName: string) => {
    navigator.clipboard.writeText(text.replace(/\s+/g, ''));
    setCopiedType(typeName);
    showToast(`تم نسخ رقم ${typeName} بنجاح ✅`, 'success');
    setTimeout(() => setCopiedType(null), 2500);
  };

  // 1. WhatsApp Instant Redirection
  const handleOpenWhatsApp = (customMsg?: string) => {
    const rawNumber = paymentInfo.supportPhone || '9647734378998';
    const cleanPhone = rawNumber.replace(/\D/g, '');
    
    let defaultMsg = `السلام عليكم أستاذ 🌹\nلقد قمت بتحويل مبلغ (${paymentInfo.price}) لتفعيل ملزمة:\n📚 *${selectedBookForPay.title}*\n\n👤 اسم الطالب: ${studentName || 'طالب'}\n📱 رقم الهاتف: ${phone || 'غير مدخل'}\n📍 المحافظة: ${governorate}\n💳 طريقة التحويل: ${paymentMethod}\n🔢 رقم الحوالة / الإشعار: ${transRef || 'مرفق بالصورة'}\n\nيرجى إرسال كود التفعيل لفتح المادة وشكراً جزيلاً!`;
    
    const finalMsg = customMsg || defaultMsg;
    const waUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(finalMsg)}`;
    window.open(waUrl, '_blank');
  };

  // 2. Submit order form and redirect to WhatsApp
  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!studentName.trim()) {
      showToast('يرجى كتابة اسم الطالب الثلاثي', 'error');
      return;
    }
    if (!phone.trim()) {
      showToast('يرجى كتابة رقم الهاتف للتواصل والإشعار', 'error');
      return;
    }

    setIsSubmitting(true);

    try {
      await createOrder({
        student_name: studentName.trim(),
        phone: phone.trim(),
        governorate,
        book_id: selectedBookForPay.id,
        book_title: selectedBookForPay.title,
        payment_method: paymentMethod,
        transaction_ref: transRef.trim() || `TRX-${Math.floor(100000 + Math.random() * 900000)}`,
      });

      setIsOrderSubmitted(true);

      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {}

      showToast('تم تسجيل طلبك بنجاح! يتم الآن فتح الواتساب لإرسال الوصل...', 'success');
      
      // Auto open WhatsApp after brief moment
      setTimeout(() => {
        handleOpenWhatsApp();
      }, 1000);
    } catch {
      showToast('حدث خطأ أثناء إرسال الطلب، يرجى المحاولة ثانية', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // 3. Activation Code Verification
  const handleVerifyCode = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanCode = activationCode.trim().toUpperCase();

    if (!cleanCode) {
      showToast('يرجى إدخال كود التفعيل', 'error');
      return;
    }

    setIsVerifyingCode(true);

    setTimeout(() => {
      setIsVerifyingCode(false);
      
      // First try real redeemActivationCode
      const res = redeemActivationCode(cleanCode);

      if (res.success) {
        try {
          confetti({
            particleCount: 120,
            spread: 80,
            origin: { y: 0.6 },
          });
        } catch {}

        showToast(res.message, 'success');
        setActiveReadingBook(selectedBookForPay);
        closeModal();
      } else {
        // Fallback promo codes
        const validCodes = ['TALABATI2026', 'IQ2026', 'VIP999', 'QI2026', 'SUPERQI', 'BAGHDAD2026'];
        if (validCodes.includes(cleanCode)) {
          unlockBookDirectly(selectedBookForPay.id);
          try {
            confetti({
              particleCount: 120,
              spread: 80,
              origin: { y: 0.6 },
            });
          } catch {}

          showToast('🎉 كود التفعيل صحيح 100%! تم تفعيل وفتح المادة بنجاح', 'success');
          setActiveReadingBook(selectedBookForPay);
          closeModal();
        } else {
          showToast(res.message || '❌ كود التفعيل غير صحيح أو منتهي الصلاحية! تواصل مع الدعم الفني على 07734378998', 'error');
        }
      }
    }, 400);
  };

  const IRAQI_GOVERNORATES = [
    'بغداد',
    'البصرة',
    'نينوى (الموصل)',
    'أربيل',
    'كركوك',
    'النجف الأشرف',
    'كربلاء المقدسة',
    'ذي قار (الناصرية)',
    'بابل (الحلة)',
    'ديالى',
    'الأنبار',
    'واسط (الكوت)',
    'ميسان (العمارة)',
    'المثنى (السماوة)',
    'القادسية (الديوانية)',
    'صلاح الدين (تكريت)',
    'دهوك',
    'السليمانية',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6 animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-slate-950 via-indigo-950 to-slate-950 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shadow-lg">
              <CreditCard className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black">طرق الدفع والتفعيل المباشر</h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-black border border-emerald-500/30">
                  تفعيل سريع ⚡
                </span>
              </div>
              <p className="text-xs text-slate-300">
                المبلغ المطلوب: <span className="text-amber-300 font-bold font-mono text-sm">{paymentInfo.price}</span> (فتح الملزمة كاملة)
              </p>
            </div>
          </div>

          <button
            onClick={closeModal}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 p-2 gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('transfer')}
            className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeTab === 'transfer'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200/60 dark:hover:bg-slate-800'
            }`}
          >
            <CreditCard className="w-4 h-4 text-amber-300" />
            <span>1. التحويل البنكي والمحافظ (سوبر كي / كاش)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('code')}
            className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeTab === 'code'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200/60 dark:hover:bg-slate-800'
            }`}
          >
            <KeyRound className="w-4 h-4 text-amber-300" />
            <span>2. لدي كود تفعيل 🔑</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 space-y-5 max-h-[78vh] overflow-y-auto">
          
          {/* Selected Book Summary Bar */}
          <div className="p-3.5 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/60 flex items-center justify-between text-xs">
            <div>
              <span className="text-slate-500 dark:text-slate-400 block text-[10px]">الملزمة المختارة للتفعيل:</span>
              <span className="font-black text-indigo-900 dark:text-indigo-200">{selectedBookForPay.title}</span>
            </div>
            <div className="text-left">
              <span className="text-slate-400 block text-[10px]">السعر</span>
              <span className="px-2 py-0.5 rounded-lg bg-amber-500/20 text-amber-700 dark:text-amber-300 font-black font-mono">
                {paymentInfo.price}
              </span>
            </div>
          </div>

          {/* TAB 1: TRANSFER (سوبر كي، ماستر كارد، آسيا حوالة، زين كاش) */}
          {activeTab === 'transfer' && (
            <div className="space-y-5">
              {/* Payment Accounts Box */}
              <div className="p-4 rounded-3xl bg-slate-950 border border-amber-500/30 text-white space-y-3 shadow-xl">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-xs font-bold text-slate-200">بيانات التحويل المعتمدة (حول 10,000 د.ع):</span>
                  </div>
                  <span className="text-[11px] text-amber-400 font-bold">حسابات رسمية مفعلة</span>
                </div>

                {/* 1. سوبر كي و ماستر كارد الرافدين */}
                <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 text-xs font-black">
                      QI
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 block">سوبر كي / ماستر كارد الرافدين:</span>
                      <span className="text-sm font-black font-mono tracking-wider text-amber-300">
                        {paymentInfo.rafidainCard}
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleCopy(paymentInfo.rafidainCard, 'ماستر كارد الرافدين')}
                    className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold flex items-center gap-1 transition-all active:scale-95 cursor-pointer shadow"
                  >
                    {copiedType === 'ماستر كارد الرافدين' ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>تم النسخ</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>نسخ الرقم</span>
                      </>
                    )}
                  </button>
                </div>

                {/* 2. آسيا حوالة */}
                <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400 text-xs font-black">
                      Asia
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 block">آسيا حوالة (رقم المحفظة):</span>
                      <span className="text-sm font-black font-mono tracking-wider text-rose-300">
                        {paymentInfo.asiaHawala || '07734378998'}
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleCopy(paymentInfo.asiaHawala || '07734378998', 'آسيا حوالة')}
                    className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1 transition-all active:scale-95 cursor-pointer shadow"
                  >
                    {copiedType === 'آسيا حوالة' ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>تم النسخ</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>نسخ الرقم</span>
                      </>
                    )}
                  </button>
                </div>

                {/* 3. زين كاش */}
                <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-pink-500/20 border border-pink-500/30 flex items-center justify-center text-pink-400 text-xs font-black">
                      Zain
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 block">زين كاش (رقم المحفظة):</span>
                      <span className="text-sm font-black font-mono tracking-wider text-pink-300">
                        {paymentInfo.zainCash}
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleCopy(paymentInfo.zainCash, 'زين كاش')}
                    className="px-3 py-1.5 rounded-xl bg-pink-600 hover:bg-pink-500 text-white text-xs font-bold flex items-center gap-1 transition-all active:scale-95 cursor-pointer shadow"
                  >
                    {copiedType === 'زين كاش' ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>تم النسخ</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>نسخ الرقم</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Direct WhatsApp Quick Chat Helper */}
              <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/60 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="text-right">
                  <span className="text-xs font-black text-emerald-900 dark:text-emerald-200 block">
                    💬 تواصل مباشر عبر الواتساب لتأكيد الحوالة
                  </span>
                  <span className="text-[11px] text-emerald-700 dark:text-emerald-400">
                    حوّلت المبلغ وتريد إرسال صورة الوصل والحصول على كود التفعيل فوراً؟
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => handleOpenWhatsApp()}
                  className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black flex items-center justify-center gap-2 transition-transform active:scale-95 shadow-md shadow-emerald-600/30 cursor-pointer shrink-0"
                >
                  <Send className="w-4 h-4" />
                  <span>فتح الواتساب مباشرة 💬</span>
                </button>
              </div>

              {/* Confirmation Form */}
              <form onSubmit={handleFormSubmit} className="space-y-4 pt-2">
                <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
                  <span className="text-xs font-black text-slate-800 dark:text-slate-200">
                    📝 بيانات الطالب بعد التحويل (لتثبيت الطلب):
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      اسم الطالب الثلاثي: <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={studentName}
                      onChange={(e) => setStudentName(e.target.value)}
                      placeholder="مثال: أحمد سامي حسن"
                      className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-medium focus:border-indigo-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      رقم الهاتف / الواتساب: <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="07700000000"
                      className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono font-medium focus:border-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      طريقة التحويل التي استخدمتها:
                    </label>
                    <select
                      value={paymentMethod}
                      onChange={(e) => setPaymentMethod(e.target.value)}
                      className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold focus:border-indigo-500 focus:outline-none"
                    >
                      <option value="سوبر كي / ماستر كارد الرافدين">سوبر كي / ماستر كارد الرافدين</option>
                      <option value="آسيا حوالة">آسيا حوالة</option>
                      <option value="زين كاش">زين كاش</option>
                      <option value="ماستر كارد الرشيد">ماستر كارد الرشيد</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      رقم الحوالة / الإشعار (اختياري):
                    </label>
                    <input
                      type="text"
                      value={transRef}
                      onChange={(e) => setTransRef(e.target.value)}
                      placeholder="رقم العملية من التطبيق"
                      className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono font-medium focus:border-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    المحافظة:
                  </label>
                  <select
                    value={governorate}
                    onChange={(e) => setGovernorate(e.target.value)}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold focus:border-indigo-500 focus:outline-none"
                  >
                    {IRAQI_GOVERNORATES.map((gov) => (
                      <option key={gov} value={gov}>
                        {gov}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Submit button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-600 via-indigo-600 to-emerald-700 hover:from-emerald-500 hover:to-indigo-500 text-white font-black text-sm shadow-xl shadow-emerald-600/20 transition-all hover:scale-[1.01] active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Send className="w-5 h-5" />
                  <span>تأكيد الطلب وإرسال الوصل للواتساب 🚀</span>
                </button>
              </form>
            </div>
          )}

          {/* TAB 2: ACTIVATION CODE (إدخال كود التفعيل المباشر) */}
          {activeTab === 'code' && (
            <div className="space-y-5 py-2">
              <div className="text-center space-y-2">
                <div className="w-16 h-16 rounded-3xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto border border-amber-500/30 shadow-lg">
                  <KeyRound className="w-8 h-8" />
                </div>
                <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                  إدخال كود التفعيل المباشر 🔑
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto">
                  إذا قمت بالتحويل واستلمت كود التفعيل من المشرف عبر الواتساب، أدخل الكود هنا لفتح الملزمة فوراً.
                </p>
              </div>

              <form onSubmit={handleVerifyCode} className="space-y-4 max-w-md mx-auto">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2 text-center">
                    كود التفعيل (Activation Code):
                  </label>
                  <input
                    type="text"
                    required
                    value={activationCode}
                    onChange={(e) => setActivationCode(e.target.value.toUpperCase())}
                    placeholder="مثال: IQ2026 أو TALABATI2026"
                    className="w-full p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border-2 border-indigo-500/50 text-base font-mono font-black text-center tracking-widest text-indigo-600 dark:text-indigo-300 focus:border-indigo-600 focus:outline-none uppercase shadow-inner"
                  />
                </div>

                <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 space-y-1">
                  <div className="flex items-center gap-1.5 font-bold">
                    <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>أكواد التفعيل المعتمدة:</span>
                  </div>
                  <ul className="text-[11px] text-slate-300 space-y-0.5 pr-5 list-disc">
                    <li><strong className="text-amber-400 font-mono">IQ2026</strong> : تفعيل فوري للمادة المختارة</li>
                    <li><strong className="text-amber-400 font-mono">TALABATI2026</strong> : كود شامل VIP لفتح كافة الملازم الـ 11</li>
                  </ul>
                </div>

                <button
                  type="submit"
                  disabled={isVerifyingCode}
                  className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-sm shadow-xl shadow-emerald-600/30 transition-all hover:scale-[1.01] active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Unlock className="w-5 h-5 text-amber-300" />
                  <span>{isVerifyingCode ? 'جاري التحقق من الكود...' : 'تأكيد الكود وفتح الملزمة فوراً 🔓'}</span>
                </button>

                <div className="text-center pt-2">
                  <button
                    type="button"
                    onClick={() => handleOpenWhatsApp('مرحباً، أرغب بالحصول على كود تفعيل للملزمة')}
                    className="text-xs text-emerald-500 dark:text-emerald-400 hover:underline font-bold inline-flex items-center gap-1 cursor-pointer"
                  >
                    <span>ليس لديك كود؟ تواصل مع المشرف عبر الواتساب</span>
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
