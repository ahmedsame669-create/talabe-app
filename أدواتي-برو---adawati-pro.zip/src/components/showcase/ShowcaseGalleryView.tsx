import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { MobileAppContainer } from '../mobile/MobileAppContainer';
import { TalabatiAdminDashboard } from '../admin/TalabatiAdminDashboard';
import {
  Smartphone,
  LayoutDashboard,
  CheckCircle2,
  Code2,
  Database,
  Layers,
  Sparkles,
  Zap,
  ArrowRight,
  ExternalLink,
  BookOpen,
  Eye,
  Sliders,
  Copy,
  Check
} from 'lucide-react';

export const ShowcaseGalleryView: React.FC = () => {
  const { setViewMode, setActiveMobileScreen, showToast, openModal } = useApp();
  const [activeCodeTab, setActiveCodeTab] = useState<'addBook' | 'downloadBook' | 'schema'>('schema');
  const [copied, setCopied] = useState(false);

  const handleCopy = (text: string) => {
    navigator.clipboard?.writeText(text);
    setCopied(true);
    showToast('تم نسخ الكود البرمجي 📋', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  const FIRESTORE_SCHEMA_JSON = `{
  "users": {
    "userId": {
      "uid": "str",
      "name": "أحمد محمد",
      "email": "ahmed@example.com",
      "role": "admin | user",
      "badge": "مميز ⭐",
      "createdAt": "timestamp"
    }
  },
  "books": {
    "bookId": {
      "title": "الرياضيات - الثالث متوسط",
      "category": "الرياضيات",
      "grade": "الثالث متوسط",
      "year": "2026",
      "pages": 320,
      "size": "15.2 MB",
      "fileUrl": "https://storage.googleapis.com/.../math_2026.pdf",
      "rating": 4.8,
      "downloads": 16250
    }
  }
}`;

  const FLUTTER_ADD_BOOK_CODE = `Future<void> addBook(Map<String, dynamic> bookData) async {
  try {
    await FirebaseFirestore.instance.collection('books').add({
      ...bookData,
      'createdAt': FieldValue.serverTimestamp(),
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('تمت إضافة الكتاب بنجاح')),
    );
  } catch (e) {
    print('Error: $e');
  }
}`;

  const FLUTTER_DOWNLOAD_CODE = `ElevatedButton.icon(
  icon: Icon(Icons.download),
  label: Text('تحميل الكتاب'),
  onPressed: () async {
    final url = book['fileUrl'];
    final taskId = await FlutterDownloader.enqueue(
      url: url,
      savedDir: '/storage/emulated/0/Download',
      fileName: '\${book['title']}.pdf',
      showNotification: true,
      openFileFromNotification: true,
    );
  },
)`;

  const FEATURES = [
    'تسجيل دخول وتسجيل جديد',
    'تصفح الكتب حسب الأقسام والصفوف',
    'تحميل الكتب بصيغة PDF',
    'إضافة الكتب وحذفها (للإدارة)',
    'إدارة المرشحات والملخصات',
    'لوحة تحكم إدارة متكاملة',
    'إحصائيات وتقارير مفصلة',
    'تصميم حديث وسريع الاستجابة',
    'دعم الوضع الليلي والنهاري'
  ];

  const TECH_STACK = [
    { title: 'واجهة التطبيق', val: 'Flutter & React', color: 'text-blue-400' },
    { title: 'لغة البرمجة', val: 'Dart & TypeScript', color: 'text-cyan-400' },
    { title: 'قاعدة البيانات والمصادقة', val: 'Firebase Firestore & Auth', color: 'text-amber-400' },
    { title: 'استضافة وتخزين الملفات', val: 'Firebase Cloud Storage', color: 'text-emerald-400' },
    { title: 'العمليات الخلفية', val: 'Cloud Functions & Node.js', color: 'text-purple-400' }
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-['Tajawal','Cairo',sans-serif] p-4 lg:p-8 space-y-12 select-none">
      {/* Gallery Header */}
      <div className="text-center space-y-3 max-w-3xl mx-auto pt-4">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 text-blue-400 text-xs font-bold border border-blue-500/20">
          <Sparkles className="w-3.5 h-3.5" />
          <span>تصميم ومنظومة منصة طلبتي الكاملة • طبعة 2026</span>
        </div>

        <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
          منصة <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-indigo-300 to-cyan-400">طلبتي</span> للمناهج والكتب الدراسية
        </h1>

        <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-2xl mx-auto font-medium">
          استعراض الشاشات الخمس للتطبيق مع لوحة تحكم الإدارة وهيكلية قاعدة البيانات وميزات التحميل المباشر.
        </p>

        {/* Quick Launch Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
          <button
            onClick={() => {
              setViewMode('mobile-app');
              setActiveMobileScreen('home');
            }}
            className="px-5 py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-black shadow-lg shadow-blue-600/30 flex items-center gap-2 cursor-pointer transition-transform hover:scale-105"
          >
            <Smartphone className="w-4 h-4" />
            <span>تشغيل التطبيق التفاعلي (Live Simulator)</span>
          </button>

          <button
            onClick={() => setViewMode('admin-dashboard')}
            className="px-5 py-2.5 rounded-2xl bg-slate-900 hover:bg-slate-850 text-slate-200 border border-slate-700 text-xs font-black flex items-center gap-2 cursor-pointer transition-transform hover:scale-105"
          >
            <LayoutDashboard className="w-4 h-4 text-blue-400" />
            <span>فتح لوحة تحكم الإدارة الكاملة</span>
          </button>
        </div>
      </div>

      {/* 5 Mobile Mockups Row (Exactly matching the top row in the image!) */}
      <section className="space-y-4">
        <div className="flex items-center justify-between px-2">
          <span className="text-xs font-black text-blue-400">انقر على أي شاشة لتجربتها مباشرة 👆</span>
          <h2 className="text-base sm:text-lg font-black text-white">
            شاشات التطبيق (شاشة الدخول • الرئيسية • المكتبة • التفاصيل • الملف الشخصي)
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6 overflow-x-auto pb-4 pt-2">
          {/* Screen 1: تسجيل الدخول */}
          <div
            onClick={() => {
              setViewMode('mobile-app');
              setActiveMobileScreen('login');
            }}
            className="cursor-pointer transform hover:scale-[1.02] transition-transform flex flex-col items-center space-y-2 group"
          >
            <div className="w-full flex items-center justify-center pointer-events-none">
              <MobileAppContainer forcedScreen="login" />
            </div>
            <span className="text-xs font-black text-slate-300 group-hover:text-blue-400 transition-colors">
              1. شاشة تسجيل الدخول
            </span>
          </div>

          {/* Screen 2: الرئيسية */}
          <div
            onClick={() => {
              setViewMode('mobile-app');
              setActiveMobileScreen('home');
            }}
            className="cursor-pointer transform hover:scale-[1.02] transition-transform flex flex-col items-center space-y-2 group"
          >
            <div className="w-full flex items-center justify-center pointer-events-none">
              <MobileAppContainer forcedScreen="home" />
            </div>
            <span className="text-xs font-black text-slate-300 group-hover:text-blue-400 transition-colors">
              2. شاشة الرئيسية والأقسام
            </span>
          </div>

          {/* Screen 3: المكتبة */}
          <div
            onClick={() => {
              setViewMode('mobile-app');
              setActiveMobileScreen('library');
            }}
            className="cursor-pointer transform hover:scale-[1.02] transition-transform flex flex-col items-center space-y-2 group"
          >
            <div className="w-full flex items-center justify-center pointer-events-none">
              <MobileAppContainer forcedScreen="library" />
            </div>
            <span className="text-xs font-black text-slate-300 group-hover:text-blue-400 transition-colors">
              3. شاشة المكتبة والفلاتر
            </span>
          </div>

          {/* Screen 4: تفاصيل الكتاب */}
          <div
            onClick={() => {
              setViewMode('mobile-app');
              setActiveMobileScreen('details');
            }}
            className="cursor-pointer transform hover:scale-[1.02] transition-transform flex flex-col items-center space-y-2 group"
          >
            <div className="w-full flex items-center justify-center pointer-events-none">
              <MobileAppContainer forcedScreen="details" />
            </div>
            <span className="text-xs font-black text-slate-300 group-hover:text-blue-400 transition-colors">
              4. شاشة تفاصيل الكتاب والتحميل
            </span>
          </div>

          {/* Screen 5: المزيد والملف الشخصي */}
          <div
            onClick={() => {
              setViewMode('mobile-app');
              setActiveMobileScreen('profile');
            }}
            className="cursor-pointer transform hover:scale-[1.02] transition-transform flex flex-col items-center space-y-2 group"
          >
            <div className="w-full flex items-center justify-center pointer-events-none">
              <MobileAppContainer forcedScreen="profile" />
            </div>
            <span className="text-xs font-black text-slate-300 group-hover:text-blue-400 transition-colors">
              5. شاشة المزيد والملف الشخصي
            </span>
          </div>
        </div>
      </section>

      {/* Middle Grid: Admin Dashboard Preview + Features & Tech Stack cards */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-6 pt-4">
        {/* Left 2 Cols: Admin Panel Interactive Frame */}
        <div className="lg:col-span-2 rounded-3xl bg-slate-900/90 border border-slate-800 overflow-hidden shadow-2xl space-y-0">
          <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
            <button
              onClick={() => setViewMode('admin-dashboard')}
              className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <span>تكبير لوحة الإدارة</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>

            <div className="flex items-center gap-2">
              <span className="text-xs font-black text-white">لوحة تحكم الإدارة (Admin Dashboard)</span>
              <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></div>
            </div>
          </div>

          <div className="max-h-[600px] overflow-y-auto">
            <TalabatiAdminDashboard />
          </div>
        </div>

        {/* Right 1 Col: Features checklist & Tech stack */}
        <div className="space-y-6">
          {/* Features Card matching image */}
          <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4 text-right">
            <div className="flex items-center justify-end gap-2 text-emerald-400">
              <h3 className="text-base font-black text-white">مميزات التطبيق</h3>
              <CheckCircle2 className="w-5 h-5" />
            </div>

            <div className="space-y-2.5">
              {FEATURES.map((feat, idx) => (
                <div key={idx} className="flex items-center justify-end gap-2.5 text-xs text-slate-300">
                  <span>{feat}</span>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                </div>
              ))}
            </div>
          </div>

          {/* Tech Stack Card matching image */}
          <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4 text-right">
            <div className="flex items-center justify-end gap-2 text-cyan-400">
              <h3 className="text-base font-black text-white">التقنيات المستخدمة</h3>
              <Layers className="w-5 h-5" />
            </div>

            <div className="space-y-3 divide-y divide-slate-800/80">
              {TECH_STACK.map((item, idx) => (
                <div key={idx} className="pt-2.5 flex items-center justify-between text-xs">
                  <span className={`font-mono font-bold ${item.color}`}>{item.val}</span>
                  <span className="text-slate-400 font-bold">{item.title}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Bottom Section: Firebase Firestore Architecture & Code Snippets matching the screenshot */}
      <section className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleCopy(
                activeCodeTab === 'schema'
                  ? FIRESTORE_SCHEMA_JSON
                  : activeCodeTab === 'addBook'
                  ? FLUTTER_ADD_BOOK_CODE
                  : FLUTTER_DOWNLOAD_CODE
              )}
              className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold border border-slate-700 flex items-center gap-1.5 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'تم النسخ' : 'نسخ الكود'}</span>
            </button>
          </div>

          <div className="space-y-1 text-right">
            <h3 className="text-base sm:text-lg font-black text-white">
              هيكل Firestore ومثال كود إضافة وتحميل كتاب
            </h3>
            <p className="text-xs text-slate-400">
              بنية المخطط والعمليات البرمجية المتوافقة مع Flutter و Firebase
            </p>
          </div>
        </div>

        {/* Code Tabs */}
        <div className="flex items-center justify-end gap-2 border-b border-slate-800 pb-2">
          <button
            onClick={() => setActiveCodeTab('downloadBook')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeCodeTab === 'downloadBook'
                ? 'bg-blue-600 text-white'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            مثال كود تحميل كتاب
          </button>

          <button
            onClick={() => setActiveCodeTab('addBook')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeCodeTab === 'addBook'
                ? 'bg-blue-600 text-white'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            مثال كود إضافة كتاب (Firebase)
          </button>

          <button
            onClick={() => setActiveCodeTab('schema')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeCodeTab === 'schema'
                ? 'bg-blue-600 text-white'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            هيكل Firestore - Schema
          </button>
        </div>

        {/* Code Display Area */}
        <div className="rounded-2xl bg-slate-950 p-4 border border-slate-800 font-mono text-xs text-slate-200 overflow-x-auto text-left leading-relaxed">
          <pre className="text-emerald-400">
            {activeCodeTab === 'schema' && FIRESTORE_SCHEMA_JSON}
            {activeCodeTab === 'addBook' && FLUTTER_ADD_BOOK_CODE}
            {activeCodeTab === 'downloadBook' && FLUTTER_DOWNLOAD_CODE}
          </pre>
        </div>
      </section>
    </div>
  );
};
