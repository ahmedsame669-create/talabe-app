import React from 'react';
import { useApp } from '../context/AppContext';
import {
  Search,
  CheckCircle2,
  Sparkles,
  Award,
  CreditCard,
  Smartphone,
  BookMarked,
  GraduationCap,
  PenTool,
  Zap,
  PlayCircle,
  Tv,
  Download,
  Apple
} from 'lucide-react';

export const HeroSection: React.FC = () => {
  const { searchQuery, setSearchQuery, paymentInfo, openModal, promptInstall, isInstallable } = useApp();

  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 border border-indigo-900/50 shadow-2xl p-6 sm:p-10 text-white">
      {/* Subtle background glow effect */}
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-4xl mx-auto text-center space-y-6">
        {/* Top Announcement Badge & Quick Actions */}
        <div className="flex flex-wrap items-center justify-center gap-2">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-bold shadow-inner">
            <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
            <span>مرشحات وثوابت مقلصة وممتعة • بدون حشو زائد • مع ميزة (امتحن نفسي ✍️)</span>
          </div>

          <button
            onClick={() => openModal('install-app')}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black shadow-lg shadow-emerald-600/30 hover:scale-105 transition-all cursor-pointer border border-emerald-400/40"
          >
            <Download className="w-4 h-4 text-white animate-bounce" />
            <span>تثبيت التطبيق (أندرويد & آبل) 📲</span>
          </button>

          <button
            onClick={() => openModal('video-tutorial')}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white text-xs font-black shadow-lg shadow-rose-600/30 hover:scale-105 transition-all cursor-pointer border border-rose-400/40"
          >
            <PlayCircle className="w-4 h-4 text-white animate-spin" style={{ animationDuration: '4s' }} />
            <span>شاهد فيديو طريقة الاشتراك والدفع (دقيقة واحدة) 🎬▶</span>
          </button>
        </div>

        {/* Main Headline */}
        <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight sm:leading-tight">
          منصة طلبتي للمرشحات و
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-300 to-pink-400">
            الثوابت الوزارية المقلصة
          </span>
        </h1>

        {/* Subtitle */}
        <p className="text-slate-300 text-sm sm:text-base max-w-2xl mx-auto leading-relaxed">
          مرشحات مركزة جداً لكافة المراحل (الثالث متوسط، السادس علمي وأدبي وأحيائي ومهني، والسادس ابتدائي) مع تقليص التعاريف والتعاليل لضمان أعلى الدرجات، مع اختبار فوري لكل مادة!
        </p>

        {/* Search Bar */}
        <div className="max-w-xl mx-auto relative mt-4">
          <div className="relative flex items-center">
            <Search className="w-5 h-5 text-indigo-400 absolute right-4 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن مادتك أو صفك (رياضيات، كيمياء، ثالث متوسط، سادس علمي)..."
              className="w-full pl-4 pr-12 py-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 focus:border-indigo-500 focus:bg-slate-800 text-sm text-white placeholder-slate-400 focus:outline-none shadow-xl backdrop-blur-md transition-all font-medium"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute left-4 text-xs bg-slate-700 hover:bg-slate-600 text-slate-300 px-2 py-1 rounded-lg"
              >
                مسح
              </button>
            )}
          </div>
        </div>

        {/* Accepted Payment Methods bar */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-3 text-xs text-slate-300">
          <span className="text-slate-400 font-bold">الدفع المباشر:</span>
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-800/70 border border-slate-700">
            <CreditCard className="w-3.5 h-3.5 text-amber-400" />
            <span>ماستر كارد الرافدين (الكي كارد)</span>
          </span>
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-800/70 border border-slate-700">
            <Smartphone className="w-3.5 h-3.5 text-pink-400" />
            <span>زين كاش (Zain Cash)</span>
          </span>
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-800/70 border border-slate-700">
            <CreditCard className="w-3.5 h-3.5 text-cyan-400" />
            <span>ماستر كارد الرشيد</span>
          </span>
        </div>

        {/* Key Highlights Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-6 border-t border-slate-800/80">
          <div className="p-3 rounded-2xl bg-slate-800/40 border border-slate-800 text-center">
            <div className="flex items-center justify-center gap-1.5 text-indigo-400 mb-1">
              <GraduationCap className="w-4 h-4" />
              <span className="text-sm sm:text-base font-black">كافة الصفوف</span>
            </div>
            <span className="text-[11px] text-slate-400">ابتدائي • متوسط • إعدادي</span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-800/40 border border-slate-800 text-center">
            <div className="flex items-center justify-center gap-1.5 text-emerald-400 mb-1">
              <Award className="w-4 h-4" />
              <span className="text-sm sm:text-base font-black">تقليص ذكي</span>
            </div>
            <span className="text-[11px] text-slate-400">حذف الحشو والتركيز عالثوابت</span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-800/40 border border-slate-800 text-center">
            <div className="flex items-center justify-center gap-1.5 text-amber-400 mb-1">
              <PenTool className="w-4 h-4" />
              <span className="text-sm sm:text-base font-black">امتحن نفسي</span>
            </div>
            <span className="text-[11px] text-slate-400">اختبار وتقييم تفاعلي فوري</span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-800/40 border border-slate-800 text-center">
            <div className="flex items-center justify-center gap-1.5 text-purple-400 mb-1">
              <Zap className="w-4 h-4" />
              <span className="text-sm sm:text-base font-black">فتح فوري</span>
            </div>
            <span className="text-[11px] text-slate-400">بدون انتظار أو وسيط</span>
          </div>
        </div>
      </div>
    </div>
  );
};
