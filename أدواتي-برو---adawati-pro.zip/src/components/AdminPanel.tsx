import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Clock,
  Send,
  Download,
  Settings,
  DollarSign,
  Users,
  BookOpen,
  KeyRound,
  FileSpreadsheet,
  Edit,
  Save,
  Plus
} from 'lucide-react';

export const AdminPanel: React.FC = () => {
  const {
    activeModal,
    closeModal,
    orders,
    approveOrder,
    rejectOrder,
    paymentInfo,
    updatePaymentInfo,
    isAdminLoggedIn,
    setIsAdminLoggedIn,
    showToast,
    books,
  } = useApp();

  const [pinCode, setPinCode] = useState('');
  const [adminTab, setAdminTab] = useState<'orders' | 'settings'>('orders');

  // Edit payment info fields
  const [zainCash, setZainCash] = useState(paymentInfo.zainCash);
  const [rafidainCard, setRafidainCard] = useState(paymentInfo.rafidainCard);
  const [rasheedCard, setRasheedCard] = useState(paymentInfo.rasheedCard);
  const [asiaHawala, setAsiaHawala] = useState(paymentInfo.asiaHawala);
  const [price, setPrice] = useState(paymentInfo.price);
  const [supportPhone, setSupportPhone] = useState(paymentInfo.supportPhone);

  if (activeModal !== 'admin') return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinCode === '1234' || pinCode === 'admin' || pinCode === '45468') {
      setIsAdminLoggedIn(true);
      showToast('تم تسجيل دخول المشرف بنجاح 🛡️', 'success');
    } else {
      showToast('رمز الدخول غير صحيح! (الرمز الافتراضي: 1234)', 'error');
    }
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updatePaymentInfo({
      zainCash,
      rafidainCard,
      rasheedCard,
      asiaHawala,
      price,
      supportPhone,
    });
  };

  const handleWhatsAppStudent = (phone: string, studentName: string, bookTitle: string) => {
    const cleanPhone = phone.replace(/^0/, '964');
    const msg = `مرحباً عزيزي الطالب ${studentName}،\nتم استلام وتأكيد حوالتك بنجاح ✅.\nتم فتح وتفعيل ملزمة (${bookTitle}) في حسابك على منصة طلبتي التعليمية.\nنتمنى لك التفوق والدرجة الكاملة بالوزاري! 🌟`;
    window.open(`https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  const handleExportCSV = () => {
    const header = 'رقم الطلب,اسم الطالب,رقم الهاتف,المحافظة,الملزمة,طريقة الدفع,رقم الحوالة,الحالة,التاريخ\n';
    const rows = orders
      .map(
        (o) =>
          `"${o.id}","${o.student_name}","${o.phone}","${o.governorate || 'بغداد'}","${o.book_title}","${o.payment_method}","${o.transaction_ref}","${o.status}","${o.created_at}"`
      )
      .join('\n');

    const blob = new Blob(['\uFEFF' + header + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `طلبات_منصة_طلبتي_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('تم تصدير سجل المبيعات كملف Excel/CSV بنجاح 📊', 'success');
  };

  // Stats calculation
  const totalOrders = orders.length;
  const approvedOrders = orders.filter((o) => o.status === 'تم التفعيل والفتح').length;
  const pendingOrders = orders.filter((o) => o.status === 'قيد التحقق').length;
  const estimatedRevenue = approvedOrders * 10000;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-md">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black bg-indigo-500/30 text-indigo-300 px-2 py-0.5 rounded-full border border-indigo-400/30">
                  لوحة التحكم المركزية
                </span>
                <span className="text-xs text-slate-400">إدارة المبيعات والتفعيل</span>
              </div>
              <h2 className="text-sm sm:text-base font-black">
                إدارة منصة طلبتي التعليمية
              </h2>
            </div>
          </div>

          <button
            onClick={closeModal}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {!isAdminLoggedIn ? (
          /* Login Form */
          <div className="p-8 max-w-sm mx-auto text-center space-y-5 my-auto">
            <div className="w-16 h-16 rounded-3xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto border border-indigo-200 dark:border-indigo-800">
              <KeyRound className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white">
                تسجيل دخول مسؤول المنصة
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                أدخل رمز الأمان للوصول لطلبات الدفع وإعدادات الحسابات
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-3">
              <input
                type="password"
                value={pinCode}
                onChange={(e) => setPinCode(e.target.value)}
                placeholder="أدخل رمز الـ PIN (الرمز: 1234)"
                className="w-full text-center tracking-widest text-lg font-mono p-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:border-indigo-500"
                autoFocus
              />
              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 transition-transform active:scale-95 cursor-pointer"
              >
                دخول لوحة الإدارة
              </button>
            </form>
          </div>
        ) : (
          /* Admin Dashboard Content */
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Top Bar Stats & Tabs */}
            <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 flex-shrink-0 space-y-4">
              {/* Analytics Summary */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] text-slate-400 block font-medium">إجمالي الطلبات</span>
                  <span className="text-lg font-mono font-black text-slate-900 dark:text-white">{totalOrders}</span>
                </div>

                <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] text-amber-500 block font-medium">قيد التحقق ⏳</span>
                  <span className="text-lg font-mono font-black text-amber-500">{pendingOrders}</span>
                </div>

                <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] text-emerald-500 block font-medium">تم التفعيل ✅</span>
                  <span className="text-lg font-mono font-black text-emerald-500">{approvedOrders}</span>
                </div>

                <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] text-indigo-400 block font-medium">الإيراد المقدر</span>
                  <span className="text-sm sm:text-base font-mono font-black text-indigo-600 dark:text-indigo-300">
                    {estimatedRevenue.toLocaleString()} د.ع
                  </span>
                </div>
              </div>

              {/* Navigation tabs */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setAdminTab('orders')}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                      adminTab === 'orders'
                        ? 'bg-indigo-600 text-white'
                        : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    طلبات الطلاب والحوالات ({orders.length})
                  </button>

                  <button
                    onClick={() => setAdminTab('settings')}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                      adminTab === 'settings'
                        ? 'bg-indigo-600 text-white'
                        : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    تعديل أرقام الحسابات والأسعار
                  </button>
                </div>

                {adminTab === 'orders' && (
                  <button
                    onClick={handleExportCSV}
                    className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" />
                    <span>تصدير Excel/CSV</span>
                  </button>
                )}
              </div>
            </div>

            {/* Tab 1: Orders List */}
            {adminTab === 'orders' && (
              <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3">
                {orders.length > 0 ? (
                  orders.map((order) => (
                    <div
                      key={order.id}
                      className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4"
                    >
                      <div className="space-y-1.5 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-mono font-bold bg-indigo-500/20 text-indigo-400 px-2 py-0.5 rounded-md">
                            {order.id}
                          </span>
                          <span className="text-xs text-slate-400">{order.created_at}</span>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                              order.status === 'تم التفعيل والفتح'
                                ? 'bg-emerald-500/20 text-emerald-500'
                                : order.status === 'قيد التحقق'
                                ? 'bg-amber-500/20 text-amber-500'
                                : 'bg-rose-500/20 text-rose-500'
                            }`}
                          >
                            {order.status}
                          </span>
                        </div>

                        <div className="flex flex-wrap items-center gap-3">
                          <h4 className="text-sm font-black text-slate-900 dark:text-white">
                            {order.student_name}
                          </h4>
                          <span className="text-xs text-slate-500 font-mono">📱 {order.phone}</span>
                          <span className="text-xs text-slate-500">📍 {order.governorate || 'بغداد'}</span>
                        </div>

                        <p className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
                          {order.book_title}
                        </p>

                        <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-2">
                          <span>طريقة الدفع: <strong>{order.payment_method}</strong></span>
                          <span>•</span>
                          <span>رقم الحوالة: <strong className="font-mono text-slate-700 dark:text-slate-200">{order.transaction_ref}</strong></span>
                        </div>
                      </div>

                      {/* Admin action buttons */}
                      <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto justify-end">
                        <button
                          onClick={() => handleWhatsAppStudent(order.phone, order.student_name, order.book_title)}
                          className="px-3 py-2 rounded-xl bg-emerald-600/20 hover:bg-emerald-600 text-emerald-600 hover:text-white text-xs font-bold flex items-center gap-1 transition-colors"
                          title="مراسلة الطالب واتساب"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>واتساب</span>
                        </button>

                        {order.status !== 'تم التفعيل والفتح' && (
                          <button
                            onClick={() => approveOrder(order.id)}
                            className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>تفعيل فوري</span>
                          </button>
                        )}

                        {order.status !== 'مرفوض' && (
                          <button
                            onClick={() => rejectOrder(order.id, 'رقم الحوالة غير مطابق')}
                            className="px-3 py-2 rounded-xl bg-rose-600/20 hover:bg-rose-600 text-rose-600 hover:text-white text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            <span>رفض</span>
                          </button>
                        )}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-12 text-slate-400">
                    لا توجد طلبات مسجلة بعد
                  </div>
                )}
              </div>
            )}

            {/* Tab 2: Settings */}
            {adminTab === 'settings' && (
              <form onSubmit={handleSaveSettings} className="flex-1 overflow-y-auto p-6 space-y-4 max-w-xl mx-auto w-full">
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      رقم زين كاش (Zain Cash):
                    </label>
                    <input
                      type="text"
                      value={zainCash}
                      onChange={(e) => setZainCash(e.target.value)}
                      className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs font-mono font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      رقم بطاقة ماستر كارد الرافدين (الكي كارد):
                    </label>
                    <input
                      type="text"
                      value={rafidainCard}
                      onChange={(e) => setRafidainCard(e.target.value)}
                      className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs font-mono font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      رقم بطاقة ماستر كارد الرشيد:
                    </label>
                    <input
                      type="text"
                      value={rasheedCard}
                      onChange={(e) => setRasheedCard(e.target.value)}
                      className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs font-mono font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      رقم محفظة آسيا حوالة:
                    </label>
                    <input
                      type="text"
                      value={asiaHawala}
                      onChange={(e) => setAsiaHawala(e.target.value)}
                      className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs font-mono font-bold"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        سعر الملزمة المعروض:
                      </label>
                      <input
                        type="text"
                        value={price}
                        onChange={(e) => setPrice(e.target.value)}
                        className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs font-bold"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        رقم هاتف الدعم (واتساب):
                      </label>
                      <input
                        type="text"
                        value={supportPhone}
                        onChange={(e) => setSupportPhone(e.target.value)}
                        className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs font-mono font-bold"
                      />
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>حفظ التعديلات في النظام</span>
                </button>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
