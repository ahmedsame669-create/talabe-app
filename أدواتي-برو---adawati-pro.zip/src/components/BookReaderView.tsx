import React, { useState, useMemo } from 'react';
import { BookItem } from '../types';
import { useApp } from '../context/AppContext';
import {
  ArrowRight,
  Bookmark,
  BookOpen,
  CheckCircle2,
  Download,
  FileText,
  Highlighter,
  Search,
  Sparkles,
  ZoomIn,
  ZoomOut,
  Award,
  Check,
  HelpCircle,
  PenTool,
  Zap,
  Tag,
  FileCheck,
  ExternalLink,
  Edit3
} from 'lucide-react';

interface BookReaderViewProps {
  book: BookItem;
  onClose: () => void;
}

export const BookReaderView: React.FC<BookReaderViewProps> = ({ book, onClose }) => {
  const { showToast, openQuizModalForBook, isSupervisor, openBookEditorForBook } = useApp();
  const hasPdf = Boolean(book.pdfDataUrl || book.customPdfUrl);
  const [activeTab, setActiveTab] = useState<'content' | 'pdf' | 'ministerial' | 'notes'>(
    hasPdf ? 'pdf' : 'content'
  );
  const [userNotes, setUserNotes] = useState<string>(() => {
    try {
      return localStorage.getItem(`talabati_notes_${book.id}`) || '';
    } catch {
      return '';
    }
  });
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [isSaved, setIsSaved] = useState(false);
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<string>('all');
  const [ministerialSearch, setMinisterialSearch] = useState<string>('');

  const handleSaveNotes = () => {
    localStorage.setItem(`talabati_notes_${book.id}`, userNotes);
    setIsSaved(true);
    showToast('تم حفظ ملاحظاتك الدراسية بنجاح 📝', 'success');
    setTimeout(() => setIsSaved(false), 2000);
  };

  const handlePrintSummary = () => {
    window.print();
  };

  const allMinisterialQuestions = useMemo(() => {
    const list = [...(book.ministerialArchive || [])];
    book.samplePages.forEach((p, idx) => {
      if (p.questionSnippet) {
        list.push({
          id: 9000 + idx,
          question: p.questionSnippet.question,
          answer: p.questionSnippet.answer,
          topic: p.title,
          isImportant: true,
          type: 'ثابت وزاري'
        });
      }
    });
    return list;
  }, [book]);

  const filteredQuestions = useMemo(() => {
    return allMinisterialQuestions.filter((q) => {
      const matchType =
        selectedTypeFilter === 'all'
          ? true
          : q.type === selectedTypeFilter || (q.topic && q.topic.includes(selectedTypeFilter));

      const matchSearch =
        ministerialSearch.trim() === ''
          ? true
          : q.question.toLowerCase().includes(ministerialSearch.toLowerCase()) ||
            q.answer.toLowerCase().includes(ministerialSearch.toLowerCase()) ||
            (q.topic && q.topic.toLowerCase().includes(ministerialSearch.toLowerCase()));

      return matchType && matchSearch;
    });
  }, [allMinisterialQuestions, selectedTypeFilter, ministerialSearch]);

  const FILTER_TYPES = [
    { id: 'all', label: 'كافة الثوابت والمهمات' },
    { id: 'تعليل', label: '🔍 التعاليل المقلصة' },
    { id: 'تعريف', label: '📖 التعاريف الذهبية' },
    { id: 'ثابت وزاري', label: '⭐ ثوابت الامتحان' },
    { id: 'مسألة', label: '⚡ مسائل وقوانين' },
    { id: 'مقارنة', label: '⚖️ مقارنات وجداول' },
  ];

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col animate-in fade-in duration-200">
      {/* Top Sticky Reader Header */}
      <header className="sticky top-0 z-50 bg-slate-950/95 backdrop-blur-md border-b border-slate-800 px-4 sm:px-8 py-3.5 flex items-center justify-between no-print">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer flex items-center gap-1.5 text-xs font-bold"
          >
            <ArrowRight className="w-4 h-4" />
            <span>العودة للمنصة</span>
          </button>

          <div className="h-5 w-[1px] bg-slate-800 hidden sm:block" />

          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-extrabold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                نسخة مفعلة بالكامل ✓
              </span>
              <span className="text-xs text-amber-300 font-bold hidden sm:inline-block">
                {book.targetGuarantee}
              </span>
            </div>
            <h1 className="text-sm sm:text-base font-black truncate max-w-xs sm:max-w-md">
              {book.title} ({book.grade})
            </h1>
          </div>
        </div>

        {/* Reader Tools */}
        <div className="flex items-center gap-2">
          {/* Quick Quiz button */}
          <button
            onClick={() => openQuizModalForBook(book)}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-black shadow-md shadow-purple-600/30 transition-transform active:scale-95 flex items-center gap-1.5 cursor-pointer"
          >
            <PenTool className="w-3.5 h-3.5 text-amber-300" />
            <span>امتحن نفسي ✍️</span>
          </button>

          {/* Zoom controls */}
          <div className="hidden md:flex items-center bg-slate-900 border border-slate-800 rounded-xl p-1 text-xs">
            <button
              onClick={() => setZoomLevel((z) => Math.max(80, z - 10))}
              className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white cursor-pointer"
              title="تصغير"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="px-2 font-mono text-[11px] text-slate-300">{zoomLevel}%</span>
            <button
              onClick={() => setZoomLevel((z) => Math.min(140, z + 10))}
              className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white cursor-pointer"
              title="تكبير"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>

          <button
            onClick={handlePrintSummary}
            className="p-2 sm:px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="طباعة أو تصدير PDF"
          >
            <Download className="w-4 h-4 text-indigo-400" />
            <span className="hidden sm:inline">طباعة / PDF</span>
          </button>
        </div>
      </header>

      {/* Tabs navigation bar */}
      <div className="bg-slate-950 border-b border-slate-800/80 px-4 sm:px-8 py-2.5 flex items-center justify-center gap-2 no-print overflow-x-auto">
        {hasPdf && (
          <button
            onClick={() => setActiveTab('pdf')}
            className={`px-4 py-2 rounded-xl text-xs font-black flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'pdf'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                : 'text-emerald-400 hover:text-white hover:bg-slate-900 border border-emerald-500/20'
            }`}
          >
            <FileCheck className="w-4 h-4" />
            <span>ملف PDF الكامل 📄</span>
          </button>
        )}

        <button
          onClick={() => setActiveTab('content')}
          className={`px-4 py-2 rounded-xl text-xs font-black flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'content'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>ملخص الثوابت والمواضيع</span>
        </button>

        <button
          onClick={() => setActiveTab('ministerial')}
          className={`px-4 py-2 rounded-xl text-xs font-black flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'ministerial'
              ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>المرشحات الوزارية المركزة</span>
          <span className="px-1.5 py-0.2 rounded-full bg-amber-400/20 text-amber-300 text-[10px]">
            {allMinisterialQuestions.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('notes')}
          className={`px-4 py-2 rounded-xl text-xs font-black flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'notes'
              ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Highlighter className="w-4 h-4" />
          <span>دفتر ملاحظاتي</span>
        </button>

        {isSupervisor && (
          <button
            onClick={() => openBookEditorForBook(book)}
            className="px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 text-amber-300 bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 cursor-pointer whitespace-nowrap"
          >
            <Edit3 className="w-3.5 h-3.5 text-amber-400" />
            <span>تعديل المادة (المشرف) ✏️</span>
          </button>
        )}
      </div>

      {/* Main Content Area */}
      <main className="flex-1 max-w-5xl w-full mx-auto p-4 sm:p-8 space-y-8" style={{ fontSize: `${zoomLevel}%` }}>
        {/* TAB: PDF FULL VIEWER */}
        {activeTab === 'pdf' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="flex items-center gap-3 text-right">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center font-black">
                  <FileCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">{book.pdfFileName || `${book.title}.pdf`}</h3>
                  <span className="text-xs text-slate-400">ملف PDF الكامل معتمد ومدرج بالقارئ التفاعلي</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <a
                  href={book.pdfDataUrl || book.customPdfUrl || '#'}
                  target="_blank"
                  rel="noreferrer"
                  download={book.pdfFileName || `${book.title}.pdf`}
                  className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-md shadow-emerald-600/20"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>تحميل ملف PDF ⬇️</span>
                </a>
                <a
                  href={book.pdfDataUrl || book.customPdfUrl || '#'}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>فتح في نافذة كاملة ↗️</span>
                </a>
              </div>
            </div>

            {/* Embedded PDF iframe / object */}
            <div className="w-full h-[750px] rounded-3xl overflow-hidden border border-slate-800 bg-slate-950 shadow-2xl relative">
              <iframe
                src={book.pdfDataUrl || book.customPdfUrl}
                title={book.title}
                className="w-full h-full border-none"
              />
            </div>
          </div>
        )}

        {activeTab === 'content' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            {/* Book Cover Summary Card */}
            <div className={`p-6 sm:p-8 rounded-3xl bg-gradient-to-r ${book.gradient} text-white shadow-xl space-y-3`}>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-3 py-1 rounded-full bg-white/20 text-xs font-bold backdrop-blur-xs">
                  {book.category}
                </span>
                <span className="px-3 py-1 rounded-full bg-black/20 text-xs font-extrabold text-amber-200">
                  {book.grade}
                </span>
                <span className="text-xs text-white/90 font-medium">
                  {book.targetGuarantee}
                </span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-black">{book.title}</h2>
              <p className="text-xs sm:text-sm text-white/90 leading-relaxed max-w-2xl">
                {book.desc}
              </p>
            </div>

            {/* Chapters & Content Sections */}
            <div className="space-y-6">
              {book.samplePages.map((page, idx) => (
                <div
                  key={idx}
                  className="p-6 sm:p-8 rounded-3xl bg-slate-950/70 border border-slate-800/80 shadow-lg space-y-5"
                >
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <span className="text-xs font-extrabold text-indigo-400">
                      القسم رقم ({idx + 1}) • مراجعة مركزة
                    </span>
                    <span className="text-xs text-slate-500 font-mono">
                      صفحة {page.pageNumber}
                    </span>
                  </div>

                  <h3 className="text-xl font-black text-white">{page.title}</h3>
                  {page.subtitle && (
                    <p className="text-xs text-slate-400 font-medium">{page.subtitle}</p>
                  )}

                  <div className="space-y-3 text-slate-300 leading-relaxed text-sm">
                    {page.content.map((p, i) => (
                      <div key={i} className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800/90 leading-relaxed font-medium">
                        {p}
                      </div>
                    ))}
                  </div>

                  {page.importantFormulas && (
                    <div className="p-4 rounded-2xl bg-indigo-950/40 border border-indigo-800 space-y-2">
                      <span className="text-xs font-bold text-indigo-300">القوانين الأساسية:</span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono font-bold text-indigo-200">
                        {page.importantFormulas.map((f, i) => (
                          <div key={i} className="p-2 rounded-xl bg-slate-900 border border-indigo-900">
                            {f}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {page.ministerialNote && (
                    <div className="p-4 rounded-2xl bg-purple-950/40 border border-purple-800 text-xs text-purple-200 leading-relaxed font-bold">
                      {page.ministerialNote}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'ministerial' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            {/* Header Banner */}
            <div className="p-6 rounded-3xl bg-gradient-to-r from-amber-950/40 via-orange-950/40 to-slate-950 border border-amber-800/80 text-amber-200 space-y-3">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-black flex items-center gap-1">
                  <Award className="w-3.5 h-3.5 text-amber-400" />
                  بنك الثوابت والمرشحات المركزة
                </span>
                <span className="text-xs text-slate-400">
                  حلول نموذجية مقلصة ومباشرة
                </span>
              </div>
              <h3 className="text-lg sm:text-xl font-black text-white">
                أهم الأسئلة والثوابت الوزارية لمادة {book.category} ({book.grade})
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                تقليص وحذف الحشو غير الضروري والتركيز على الثوابت التي تضمن لك أعلى الدرجات بأقل مجهود.
              </p>
            </div>

            {/* Filter and Search Bar */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={ministerialSearch}
                  onChange={(e) => setMinisterialSearch(e.target.value)}
                  placeholder="ابحث في التعاليل، التعاريف، أو القوانين..."
                  className="w-full pr-10 pl-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:border-amber-500 focus:outline-none"
                />
              </div>

              {/* Type Filter Chips */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
                {FILTER_TYPES.map((f) => {
                  const isSelected = selectedTypeFilter === f.id;
                  return (
                    <button
                      key={f.id}
                      onClick={() => setSelectedTypeFilter(f.id)}
                      className={`px-3 py-1.5 rounded-xl whitespace-nowrap font-bold transition-colors cursor-pointer text-xs ${
                        isSelected
                          ? 'bg-amber-600 text-white shadow-sm'
                          : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                      }`}
                    >
                      {f.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Questions List */}
            {filteredQuestions.length === 0 ? (
              <div className="p-8 text-center bg-slate-950 border border-slate-800 rounded-3xl text-slate-400 space-y-2">
                <HelpCircle className="w-8 h-8 mx-auto text-slate-500" />
                <p className="text-xs font-bold">لا توجد أسئلة تطابق بحثك.</p>
                <button
                  onClick={() => {
                    setSelectedTypeFilter('all');
                    setMinisterialSearch('');
                  }}
                  className="text-xs text-amber-400 hover:underline"
                >
                  عرض كافة الثوابت
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredQuestions.map((q, idx) => (
                  <div
                    key={q.id || idx}
                    className="p-6 rounded-3xl bg-slate-950 border border-slate-800 space-y-4 shadow-lg hover:border-slate-700 transition-colors"
                  >
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-black text-indigo-400">
                          ثابت وزاري #{idx + 1}
                        </span>
                        {q.topic && (
                          <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded-md font-medium">
                            {q.topic}
                          </span>
                        )}
                      </div>

                      <span className="text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 px-3 py-1 rounded-full flex items-center gap-1">
                        <Zap className="w-3 h-3 text-amber-400" />
                        {q.type || 'ثابت مؤكد'}
                      </span>
                    </div>

                    <p className="text-sm sm:text-base font-black text-white leading-relaxed">
                      {q.question}
                    </p>

                    <div className="p-4 rounded-2xl bg-emerald-950/30 border border-emerald-800/60 text-emerald-200 text-xs leading-relaxed space-y-1">
                      <div className="flex items-center gap-1.5 text-emerald-400 font-black">
                        <Check className="w-3.5 h-3.5" />
                        <span>الجواب المقلص والنموذجي:</span>
                      </div>
                      <p className="whitespace-pre-line text-emerald-100/90 font-medium pt-1">
                        {q.answer}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'notes' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="p-5 rounded-3xl bg-slate-950 border border-slate-800 space-y-2">
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <Highlighter className="w-5 h-5 text-purple-400" />
                <span>مفكرة الملاحظات والتأشيرات الشخصية</span>
              </h3>
              <p className="text-xs text-slate-400">
                اكتب ملاحظاتك، الأسئلة التي تحتاج مراجعتها، أو القوانين التي ترغب بتثبيتها أثناء القراءة.
              </p>
            </div>

            <textarea
              rows={12}
              value={userNotes}
              onChange={(e) => setUserNotes(e.target.value)}
              placeholder="اكتب ملاحظاتك الدراسية هنا (مثال: مراجعة قانون المقاومات ص 15 قبل الامتحان)..."
              className="w-full p-5 rounded-3xl bg-slate-950 border border-slate-800 text-sm text-slate-200 placeholder-slate-500 focus:border-indigo-500 focus:outline-none font-medium leading-relaxed"
            />

            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500">يتم الحفظ التلقائي في جهازك</span>
              <button
                onClick={handleSaveNotes}
                className="px-6 py-3 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-black flex items-center gap-2 shadow-lg shadow-purple-600/30 transition-transform active:scale-95 cursor-pointer"
              >
                {isSaved ? <CheckCircle2 className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
                <span>{isSaved ? 'تم الحفظ بنجاح' : 'حفظ الملاحظات'}</span>
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
