import React from 'react';
import { useApp } from '../../context/AppContext';
import { X, Bell, CheckCircle2, AlertCircle, Info, Sparkles } from 'lucide-react';

export const NotificationsModal: React.FC = () => {
  const { notifications, markNotificationAsRead, closeModal } = useApp();

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <button
            onClick={closeModal}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-black text-white">مركز الإشعارات والتحديثات</h3>
            <Bell className="w-4 h-4 text-cyan-400" />
          </div>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-3">
          {notifications.map((n) => (
            <div
              key={n.id}
              onClick={() => markNotificationAsRead(n.id)}
              className={`p-3.5 rounded-2xl border transition-all cursor-pointer text-right space-y-1.5 ${
                n.read
                  ? 'bg-slate-950/60 border-slate-800/80 text-slate-400'
                  : 'bg-slate-950 border-blue-500/30 text-white shadow-md'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-slate-500 font-mono">{n.date}</span>
                <div className="flex items-center gap-2">
                  <h4 className="text-xs font-black text-white">{n.title}</h4>
                  {!n.read && <span className="w-2 h-2 rounded-full bg-blue-500"></span>}
                </div>
              </div>

              <p className="text-[11px] text-slate-300 leading-relaxed font-sans">{n.message}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
