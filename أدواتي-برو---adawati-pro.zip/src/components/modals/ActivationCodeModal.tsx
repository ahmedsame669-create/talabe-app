import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import confetti from 'canvas-confetti';
import {
  KeyRound,
  X,
  Sparkles,
  CheckCircle2,
  ShieldCheck,
  PhoneCall,
  Lock,
  Unlock,
  ArrowRight,
  BookOpen,
  HelpCircle,
  Copy
} from 'lucide-react';

export const ActivationCodeModal: React.FC = () => {
  const {
    activeModal,
    closeModal,
    openModal,
    redeemActivationCode,
    showToast,
    paymentInfo,
    setActiveReadingBook,
    books
  } = useApp();

  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [successResult, setSuccessResult] = useState<{ message: string; bookId?: number | 'all' } | null>(null);

  if (activeModal !== 'activation-code') return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim()) {
      showToast('يرجى كتابة كود التفعيل', 'error');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      const res = redeemActivationCode(code);
      setLoading(false);

      if (res.success) {
        setSuccessResult({ message: res.message, bookId: res.bookId });
        try {
          confetti({
            particleCount: 120,
            spread: 80,
            origin: { y: 0.6 }
          });
        } catch {}
      } else {
        showToast(res.message, 'error');
      }
    }, 400);
  };

  const handleOpenActivatedBook = () => {
    if (successResult?.bookId && typeof successResult.bookId === 'number') {
      const targetBook = books.find((b) => b.id === successResult.bookId);
      if (targetBook) {
        setActiveReadingBook(targetBook);
        closeModal();
        return;
      }
    }
    closeModal();
  };

  const handleWhatsAppContact = () => {
    const text = encodeURIComponent('مرحباً منصة طلبتي، أريد الاستفسار عن كود تفعيل الملازم الدراسية (07734378998).');
    window.open(`https://wa.me/${paymentInfo.supportPhone}?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl overflow-hidden">
        {/* Background Glowing Gradients */}
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-48 h-48 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-16 -mb-16 w-48 h-48 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={closeModal}
          className="absolute top-5 left-5 p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800/80 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="w-14 h-14 mx-auto mb-3 rounded-2xl bg-gradient-to-tr from-amber-500 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-amber-500/25">
            <KeyRound className="w-7 h-7" />
          </div>
          <h3 className="text-2xl font-black text-white font-['Tajawal']">
            تفعيل المواد بكود الاشتراك 🔑
          </h3>
          <p className="text-slate-400 text-sm mt-1">
            أدخل كود التفعيل المستلم من إدارة المنصة لفتح المادة وبدء القراءة فوراً
          </p>
        </div>

        {successResult ? (
          <div className="bg-emerald-950/40 border border-emerald-500/30 rounded-2xl p-6 text-center animate-scaleUp">
            <div className="w-16 h-16 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto mb-3">
              <CheckCircle2 className="w-9 h-9" />
            </div>
            <h4 className="text-xl font-bold text-white mb-2">تم التفعيل بنجاح! 🎉</h4>
            <p className="text-emerald-300 text-sm mb-6 leading-relaxed">
              {successResult.message}
            </p>

            <div className="space-y-3">
              <button
                onClick={handleOpenActivatedBook}
                className="w-full py-3.5 px-6 rounded-2xl font-bold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 shadow-lg shadow-emerald-600/30 transition-all flex items-center justify-center gap-2"
              >
                <BookOpen className="w-5 h-5" />
                <span>فتح وقراءة المادة الآن 📖</span>
              </button>

              <button
                onClick={() => {
                  setSuccessResult(null);
                  setCode('');
                }}
                className="w-full py-2.5 text-sm text-slate-400 hover:text-white transition-colors"
              >
                تفعيل كود آخر
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-bold text-slate-300 mb-2">
                كود التفعيل (Activation Code):
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                  placeholder="مثال: TAL-MATH-2026 أو TAL-VIP-ALL"
                  className="w-full px-4 py-3.5 bg-slate-950/80 border-2 border-slate-700 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 rounded-2xl text-white font-mono text-center tracking-wider text-base sm:text-lg uppercase placeholder:text-slate-600 placeholder:text-sm placeholder:font-sans outline-none transition-all"
                  dir="ltr"
                  autoFocus
                />
                <KeyRound className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 pointer-events-none" />
              </div>
            </div>

            {/* Price Note */}
            <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-3.5 text-xs text-slate-300 flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-emerald-400">سعر تفعيل أي مادة: 10,000 د.ع فقط. </span>
                <span>
                  يتم إرسال كود التفعيل للطالب بعد إتمام التحويل عبر زين كاش أو ماستر كارد على الرقم{' '}
                  <b className="text-amber-400 font-mono" dir="ltr">07734378998</b>.
                </span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3 pt-1">
              <button
                type="submit"
                disabled={loading}
                className="w-full py-4 px-6 rounded-2xl font-black text-white bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-500 shadow-lg shadow-amber-500/25 transition-all transform active:scale-[0.98] flex items-center justify-center gap-2 cursor-pointer text-base"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <Unlock className="w-5 h-5" />
                    <span>تفعيل وفتح المادة الآن 🔓</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={handleWhatsAppContact}
                className="w-full py-3 px-4 rounded-2xl font-bold text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 border border-slate-700 transition-colors flex items-center justify-center gap-2 text-xs sm:text-sm cursor-pointer"
              >
                <PhoneCall className="w-4 h-4 text-emerald-400" />
                <span>طلب كود تفعيل عبر الواتساب (07734378998) 📲</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
