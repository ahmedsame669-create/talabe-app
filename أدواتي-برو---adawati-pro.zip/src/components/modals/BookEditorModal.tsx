import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { BookItem, SamplePage, MinisterialQuestionItem, QuizQuestion, SubjectCategory, EducationalStage } from '../../types';
import {
  X,
  Save,
  FileText,
  Upload,
  BookOpen,
  Sparkles,
  PenTool,
  Plus,
  Trash2,
  CheckCircle2,
  Eye,
  AlertCircle,
  Link as LinkIcon,
  HelpCircle,
  Tag,
  Palette,
  Layers,
  FileCheck
} from 'lucide-react';

export const BookEditorModal: React.FC = () => {
  const {
    activeModal,
    closeModal,
    editingBook,
    updateBook,
    showToast,
    setActiveReadingBook
  } = useApp();

  const [activeTab, setActiveTab] = useState<'info' | 'pdf' | 'pages' | 'ministerial' | 'quiz'>('info');

  // Form state initialized from editingBook
  const [formData, setFormData] = useState<Partial<BookItem>>({});
  const [samplePages, setSamplePages] = useState<SamplePage[]>([]);
  const [ministerialArchive, setMinisterialArchive] = useState<MinisterialQuestionItem[]>([]);
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([]);

  // New chapter temporary input
  const [newChapterTitle, setNewChapterTitle] = useState('');
  const [newChapterSubtitle, setNewChapterSubtitle] = useState('');
  const [newChapterContent, setNewChapterContent] = useState('');
  const [newChapterNote, setNewChapterNote] = useState('');

  // New ministerial question temporary input
  const [newMinQText, setNewMinQText] = useState('');
  const [newMinQAnswer, setNewMinQAnswer] = useState('');
  const [newMinQTopic, setNewMinQTopic] = useState('');
  const [newMinQType, setNewMinQType] = useState('ثابت وزاري');
  const [newMinQImportant, setNewMinQImportant] = useState(true);

  // New quiz question temporary input
  const [newQuizQ, setNewQuizQ] = useState('');
  const [newQuizOpt1, setNewQuizOpt1] = useState('');
  const [newQuizOpt2, setNewQuizOpt2] = useState('');
  const [newQuizOpt3, setNewQuizOpt3] = useState('');
  const [newQuizOpt4, setNewQuizOpt4] = useState('');
  const [newQuizCorrect, setNewQuizCorrect] = useState(0);
  const [newQuizExplanation, setNewQuizExplanation] = useState('');

  // PDF upload status
  const [isUploadingPdf, setIsUploadingPdf] = useState(false);

  useEffect(() => {
    if (editingBook) {
      setFormData({
        title: editingBook.title,
        category: editingBook.category,
        grade: editingBook.grade,
        desc: editingBook.desc,
        targetGuarantee: editingBook.targetGuarantee,
        pagesCount: editingBook.pagesCount,
        yearEdition: editingBook.yearEdition,
        fileSize: editingBook.fileSize,
        fileFormat: editingBook.fileFormat || 'PDF',
        author: editingBook.author,
        price: editingBook.price,
        badge: editingBook.badge,
        gradient: editingBook.gradient,
        pdfDataUrl: editingBook.pdfDataUrl,
        customPdfUrl: editingBook.customPdfUrl,
        pdfFileName: editingBook.pdfFileName,
      });
      setSamplePages(editingBook.samplePages || []);
      setMinisterialArchive(editingBook.ministerialArchive || []);
      setQuizQuestions(editingBook.quiz || []);
    }
  }, [editingBook]);

  if (activeModal !== 'book-editor' || !editingBook) return null;

  // Handle PDF file upload (FileReader converts to base64 Data URL)
  const handlePdfFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.includes('pdf') && !file.name.endsWith('.pdf')) {
      showToast('يرجى اختيار ملف بصيغة PDF فقط', 'error');
      return;
    }

    setIsUploadingPdf(true);
    const reader = new FileReader();

    reader.onload = () => {
      const result = reader.result as string;
      const sizeMb = (file.size / (1024 * 1024)).toFixed(1) + ' MB';

      setFormData((prev) => ({
        ...prev,
        pdfDataUrl: result,
        pdfFileName: file.name,
        fileSize: sizeMb
      }));

      setIsUploadingPdf(false);
      showToast(`تم تحميل ملف PDF (${file.name}) بنجاح! 📄✅`, 'success');
    };

    reader.onerror = () => {
      setIsUploadingPdf(false);
      showToast('حدث خطأ أثناء قراءة ملف الـ PDF', 'error');
    };

    reader.readAsDataURL(file);
  };

  // Add a new chapter / sample page
  const handleAddChapter = () => {
    if (!newChapterTitle.trim()) {
      showToast('يرجى كتابة عنوان الفصل أولاً', 'error');
      return;
    }

    const lines = newChapterContent
      .split('\n')
      .map((l) => l.trim())
      .filter((l) => l.length > 0);

    const newPage: SamplePage = {
      pageNumber: samplePages.length + 1,
      title: newChapterTitle.trim(),
      subtitle: newChapterSubtitle.trim() || 'ملخص وزاري مركز',
      content: lines.length > 0 ? lines : ['• محتوى المادة والملاحظات الوزارية المركزة.'],
      ministerialNote: newChapterNote.trim() || undefined
    };

    setSamplePages((prev) => [...prev, newPage]);
    setNewChapterTitle('');
    setNewChapterSubtitle('');
    setNewChapterContent('');
    setNewChapterNote('');
    showToast('تمت إضافة الفصل/القسم التفاعلي بنجاح 📑', 'success');
  };

  const handleDeleteChapter = (index: number) => {
    setSamplePages((prev) => prev.filter((_, i) => i !== index));
    showToast('تم حذف الفصل', 'info');
  };

  // Add ministerial question
  const handleAddMinisterialQuestion = () => {
    if (!newMinQText.trim() || !newMinQAnswer.trim()) {
      showToast('يرجى كتابة نص السؤال والإجابة النموذجية', 'error');
      return;
    }

    const newQ: MinisterialQuestionItem = {
      id: Date.now(),
      question: newMinQText.trim(),
      answer: newMinQAnswer.trim(),
      topic: newMinQTopic.trim() || 'مواضيع عامة',
      type: newMinQType,
      isImportant: newMinQImportant
    };

    setMinisterialArchive((prev) => [newQ, ...prev]);
    setNewMinQText('');
    setNewMinQAnswer('');
    setNewMinQTopic('');
    showToast('تمت إضافة السؤال الوزاري بنجاح 🎯', 'success');
  };

  const handleDeleteMinisterialQuestion = (id: number) => {
    setMinisterialArchive((prev) => prev.filter((q) => q.id !== id));
    showToast('تم حذف السؤال الوزاري', 'info');
  };

  // Add Quiz question
  const handleAddQuizQuestion = () => {
    if (!newQuizQ.trim() || !newQuizOpt1.trim() || !newQuizOpt2.trim()) {
      showToast('يرجى كتابة نص السؤال وخيارين على الأقل', 'error');
      return;
    }

    const options = [
      newQuizOpt1.trim(),
      newQuizOpt2.trim(),
      newQuizOpt3.trim() || 'لا شيء مما سبق',
      newQuizOpt4.trim() || 'جميع ما سبق'
    ];

    const newQuizItem: QuizQuestion = {
      id: Date.now(),
      question: newQuizQ.trim(),
      options,
      correctAnswerIndex: newQuizCorrect,
      explanation: newQuizExplanation.trim() || 'الإجابة الصحيحة وفق المنهج الوزاري المعتمد.'
    };

    setQuizQuestions((prev) => [...prev, newQuizItem]);
    setNewQuizQ('');
    setNewQuizOpt1('');
    setNewQuizOpt2('');
    setNewQuizOpt3('');
    setNewQuizOpt4('');
    setNewQuizExplanation('');
    showToast('تمت إضافة سؤال الاختبار بنجاح ✍️', 'success');
  };

  const handleDeleteQuizQuestion = (id: number) => {
    setQuizQuestions((prev) => prev.filter((q) => q.id !== id));
    showToast('تم حذف سؤال الاختبار', 'info');
  };

  // Save all changes
  const handleSaveAll = () => {
    const updatedBook: Partial<BookItem> = {
      ...formData,
      samplePages,
      ministerialArchive,
      quiz: quizQuestions,
    };

    updateBook(editingBook.id, updatedBook);
    closeModal();
  };

  const GRADIENTS = [
    { label: 'أزرق ملكي', value: 'from-blue-600 via-indigo-600 to-slate-800' },
    { label: 'أخضر زمردي', value: 'from-emerald-600 via-teal-700 to-green-800' },
    { label: 'أرجواني بنفسجي', value: 'from-purple-600 via-indigo-600 to-violet-700' },
    { label: 'كهرماني برتقالي', value: 'from-amber-600 via-orange-600 to-yellow-600' },
    { label: 'أحمر قرمزي', value: 'from-rose-600 via-pink-600 to-red-700' },
    { label: 'سماوي بحري', value: 'from-sky-600 via-blue-700 to-indigo-800' },
    { label: 'ذهبي ناري', value: 'from-amber-600 via-orange-600 to-rose-700' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-4xl max-h-[92vh] flex flex-col bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl text-right font-['Tajawal','Cairo',sans-serif] overflow-hidden"
        dir="rtl"
      >
        {/* Top Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <PenTool className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-white">
                  محرر المادة للمشرف: {editingBook.title}
                </h2>
                <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full font-bold">
                  صلاحيات كاملة 👑
                </span>
              </div>
              <p className="text-xs text-slate-400">
                تعديل البيانات، رفع وتضمين ملفات PDF، إضافة فصول تفاعلية، أسئلة وزارية واختبارات
              </p>
            </div>
          </div>

          <button
            onClick={closeModal}
            className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 p-3 border-b border-slate-800 bg-slate-950/40 overflow-x-auto">
          <button
            onClick={() => setActiveTab('info')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'info'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>البيانات الأساسية</span>
          </button>

          <button
            onClick={() => setActiveTab('pdf')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'pdf'
                ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>ملف الـ PDF والمرفقات</span>
            {formData.pdfDataUrl || formData.customPdfUrl ? (
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
            ) : null}
          </button>

          <button
            onClick={() => setActiveTab('pages')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'pages'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>الفصول والمحتوى التفاعلي ({samplePages.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('ministerial')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'ministerial'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>المرشحات الوزارية ({ministerialArchive.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('quiz')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'quiz'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <PenTool className="w-3.5 h-3.5" />
            <span>اختبار امتحن نفسي ({quizQuestions.length})</span>
          </button>
        </div>

        {/* Tab Content Area */}
        <div className="flex-1 p-5 overflow-y-auto space-y-6">
          {/* TAB 1: BASIC INFO */}
          {activeTab === 'info' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    عنوان الكتاب / المادة:
                  </label>
                  <input
                    type="text"
                    value={formData.title || ''}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-blue-500 text-right font-bold"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    المرحلة الدراسية:
                  </label>
                  <select
                    value={formData.grade || 'الثالث متوسط'}
                    onChange={(e) => setFormData({ ...formData, grade: e.target.value as EducationalStage })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-blue-500 text-right"
                  >
                    <option value="الثالث متوسط">الثالث متوسط</option>
                    <option value="السادس الإعدادي">السادس الإعدادي</option>
                    <option value="السادس الابتدائي">السادس الابتدائي</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    القسم / التخصص:
                  </label>
                  <select
                    value={formData.category || 'الرياضيات'}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value as SubjectCategory })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-blue-500 text-right"
                  >
                    <option value="الرياضيات">الرياضيات</option>
                    <option value="اللغة العربية">اللغة العربية</option>
                    <option value="اللغة الإنجليزية">اللغة الإنجليزية</option>
                    <option value="التربية الإسلامية">التربية الإسلامية</option>
                    <option value="الاجتماعيات">الاجتماعيات</option>
                    <option value="الكيمياء">الكيمياء</option>
                    <option value="الفيزياء">الفيزياء</option>
                    <option value="الأحياء">الأحياء</option>
                    <option value="الحاسوب">الحاسوب</option>
                    <option value="العلوم">العلوم</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    الضمان الوزاري / الشعار:
                  </label>
                  <input
                    type="text"
                    value={formData.targetGuarantee || ''}
                    onChange={(e) => setFormData({ ...formData, targetGuarantee: e.target.value })}
                    placeholder="مثال: ثوابت ومرشحات منصة طلبتي 2026 🎯"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-blue-500 text-right"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    شارة التمييز (Badge):
                  </label>
                  <input
                    type="text"
                    value={formData.badge || ''}
                    onChange={(e) => setFormData({ ...formData, badge: e.target.value })}
                    placeholder="مثال: ثوابت المسائل والقوانين ⚡"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-blue-500 text-right"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    سعر الاشتراك / التفعيل:
                  </label>
                  <input
                    type="text"
                    value={formData.price || '10,000 د.ع'}
                    onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-blue-500 text-right font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    عدد الصفحات:
                  </label>
                  <input
                    type="number"
                    value={formData.pagesCount || 200}
                    onChange={(e) => setFormData({ ...formData, pagesCount: parseInt(e.target.value) || 0 })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-blue-500 text-right font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    حجم الملف التقريبي:
                  </label>
                  <input
                    type="text"
                    value={formData.fileSize || '15.0 MB'}
                    onChange={(e) => setFormData({ ...formData, fileSize: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-blue-500 text-right font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  وصف المادة ومحتوياتها:
                </label>
                <textarea
                  rows={3}
                  value={formData.desc || ''}
                  onChange={(e) => setFormData({ ...formData, desc: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-blue-500 text-right leading-relaxed"
                />
              </div>

              {/* Gradient Theme selector */}
              <div className="space-y-2 pt-2">
                <label className="text-xs font-bold text-slate-300 block">
                  ثيم ولون الغلاف:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {GRADIENTS.map((g, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setFormData({ ...formData, gradient: g.value })}
                      className={`p-2.5 rounded-xl bg-gradient-to-r ${g.value} text-white text-xs font-bold text-center border transition-all cursor-pointer ${
                        formData.gradient === g.value
                          ? 'border-white ring-2 ring-blue-500 scale-[1.02]'
                          : 'border-transparent opacity-80 hover:opacity-100'
                      }`}
                    >
                      {g.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: PDF MANAGEMENT & ATTACHMENT */}
          {activeTab === 'pdf' && (
            <div className="space-y-5">
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-3">
                <div className="flex items-center gap-2">
                  <span className="p-2 rounded-xl bg-amber-500/20 text-amber-400">
                    <FileText className="w-5 h-5" />
                  </span>
                  <div>
                    <h3 className="text-sm font-black text-white">إرفاق وتضمين ملف PDF الكامل للكتاب</h3>
                    <p className="text-xs text-slate-400">
                      يمكنك رفع ملف PDF مباشرة من جهازك أو لصق رابط مباشر لملف PDF ليتمكن الطلاب والمشرف من قراءته وتحميله
                    </p>
                  </div>
                </div>
              </div>

              {/* Option A: Direct File Upload */}
              <div className="p-6 rounded-2xl bg-slate-950/80 border-2 border-dashed border-slate-700 hover:border-amber-500/50 transition-colors text-center space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-blue-500/20 text-blue-400 flex items-center justify-center mx-auto">
                  <Upload className="w-6 h-6" />
                </div>

                <div>
                  <h4 className="text-xs font-black text-white">اختر ملف PDF من جهاز الكمبيوتر أو الهاتف</h4>
                  <p className="text-[11px] text-slate-400">
                    سيتم حفظ الملف في المنصة وعرضه في قارئ الكتب التفاعلي
                  </p>
                </div>

                <label className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-black cursor-pointer shadow-md shadow-blue-600/30 transition-transform active:scale-95">
                  <Upload className="w-4 h-4" />
                  <span>{isUploadingPdf ? 'جاري رفع الملف...' : 'اختيار ملف PDF 📁'}</span>
                  <input
                    type="file"
                    accept="application/pdf,.pdf"
                    onChange={handlePdfFileUpload}
                    className="hidden"
                    disabled={isUploadingPdf}
                  />
                </label>
              </div>

              {/* Option B: External PDF URL */}
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2">
                <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <LinkIcon className="w-3.5 h-3.5 text-blue-400" />
                  <span>أو ضع رابط مباشر لملف PDF (Google Drive / Cloud):</span>
                </label>
                <input
                  type="url"
                  value={formData.customPdfUrl || ''}
                  onChange={(e) => setFormData({ ...formData, customPdfUrl: e.target.value })}
                  placeholder="https://example.com/books/3rd-grade.pdf"
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-blue-500 text-left font-mono"
                  dir="ltr"
                />
              </div>

              {/* Currently Attached PDF Status */}
              {(formData.pdfDataUrl || formData.customPdfUrl) && (
                <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center font-black text-xs">
                      PDF
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-white">
                        {formData.pdfFileName || 'ملف PDF المرفق بنجاح'}
                      </h4>
                      <span className="text-[10px] text-emerald-400 block">
                        الحجم: {formData.fileSize || 'جاهز للعرض والتحميل'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const target = formData.pdfDataUrl || formData.customPdfUrl;
                        if (target) {
                          window.open(target, '_blank');
                        }
                      }}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>معاينة</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setFormData((prev) => ({
                          ...prev,
                          pdfDataUrl: undefined,
                          customPdfUrl: undefined,
                          pdfFileName: undefined
                        }));
                        showToast('تم حذف ملف الـ PDF المرفق', 'info');
                      }}
                      className="p-1.5 rounded-lg bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 cursor-pointer"
                      title="حذف الملف"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: INTERACTIVE CHAPTERS & PAGES */}
          {activeTab === 'pages' && (
            <div className="space-y-6">
              {/* Add Chapter Form */}
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
                <h4 className="text-xs font-black text-white flex items-center gap-2">
                  <Plus className="w-4 h-4 text-indigo-400" />
                  <span>إضافة قسم أو فصل دراسي جديد للمادة</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-400 block mb-1">
                      عنوان الفصل / القسم:
                    </label>
                    <input
                      type="text"
                      value={newChapterTitle}
                      onChange={(e) => setNewChapterTitle(e.target.value)}
                      placeholder="مثال: الفصل الأول: بناء الذرة وقواعد لويس"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-indigo-500 text-right"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-slate-400 block mb-1">
                      العنوان الفرعي:
                    </label>
                    <input
                      type="text"
                      value={newChapterSubtitle}
                      onChange={(e) => setNewChapterSubtitle(e.target.value)}
                      placeholder="مثال: ملخص الثوابت والقوانين"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-indigo-500 text-right"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-400 block mb-1">
                    نقاط الشرح والمحتوى (كل سطر يعتبر نقطة مستقلة):
                  </label>
                  <textarea
                    rows={3}
                    value={newChapterContent}
                    onChange={(e) => setNewChapterContent(e.target.value)}
                    placeholder="• النقطة الأولى في الشرح&#10;• النقطة الثانية والقانون المهم&#10;• الملاحظة الذهبية"
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-indigo-500 text-right leading-relaxed"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-400 block mb-1">
                    ملاحظة وزارية خاصة (اختياري):
                  </label>
                  <input
                    type="text"
                    value={newChapterNote}
                    onChange={(e) => setNewChapterNote(e.target.value)}
                    placeholder="📌 ثابت وزاري مؤكد سنوي (10 درجات)"
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-indigo-500 text-right"
                  />
                </div>

                <button
                  type="button"
                  onClick={handleAddChapter}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-black flex items-center gap-1.5 cursor-pointer shadow-md shadow-indigo-600/20"
                >
                  <Plus className="w-4 h-4" />
                  <span>إضافة هذا الفصل للمادة 📑</span>
                </button>
              </div>

              {/* Existing Chapters List */}
              <div className="space-y-3">
                <h4 className="text-xs font-black text-slate-300">
                  الفصول والأقسام الحالية ({samplePages.length}):
                </h4>

                {samplePages.length === 0 ? (
                  <p className="text-xs text-slate-500 text-center py-4">
                    لا توجد فصول حالياً، يمكنك إضافة فصول من الأعلى.
                  </p>
                ) : (
                  samplePages.map((page, idx) => (
                    <div
                      key={idx}
                      className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2 relative"
                    >
                      <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 text-[10px] font-bold">
                            قسم #{idx + 1}
                          </span>
                          <h5 className="text-xs font-black text-white">{page.title}</h5>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleDeleteChapter(idx)}
                          className="p-1.5 rounded-lg bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 cursor-pointer"
                          title="حذف هذا القسم"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <p className="text-[11px] text-indigo-300 font-bold">{page.subtitle}</p>

                      <ul className="space-y-1 text-xs text-slate-300 pr-2">
                        {page.content.map((c, cIdx) => (
                          <li key={cIdx}>{c}</li>
                        ))}
                      </ul>

                      {page.ministerialNote && (
                        <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-300 font-medium">
                          {page.ministerialNote}
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* TAB 4: MINISTERIAL QUESTIONS ARCHIVE */}
          {activeTab === 'ministerial' && (
            <div className="space-y-6">
              {/* Add ministerial question */}
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
                <h4 className="text-xs font-black text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  <span>إضافة سؤال وزاري / مرشح مؤكد</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2">
                    <label className="text-[11px] font-bold text-slate-400 block mb-1">
                      نص السؤال الوزاري:
                    </label>
                    <input
                      type="text"
                      value={newMinQText}
                      onChange={(e) => setNewMinQText(e.target.value)}
                      placeholder="مثال: علل: يُحفظ فلز الصوديوم في النفط الأبيض؟"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-purple-500 text-right"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-slate-400 block mb-1">
                      نوع السؤال:
                    </label>
                    <select
                      value={newMinQType}
                      onChange={(e) => setNewMinQType(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-purple-500 text-right"
                    >
                      <option value="ثابت وزاري">⭐ ثابت وزاري</option>
                      <option value="تعليل">🔍 تعليل</option>
                      <option value="تعريف">📖 تعريف</option>
                      <option value="مسألة">⚡ مسألة وقانون</option>
                      <option value="مقارنة">⚖️ مقارنة</option>
                      <option value="فراغ وزاري">✏️ فراغ وزاري</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-400 block mb-1">
                    الإجابة النموذجية المعتمدة بالكونترول:
                  </label>
                  <textarea
                    rows={3}
                    value={newMinQAnswer}
                    onChange={(e) => setNewMinQAnswer(e.target.value)}
                    placeholder="اكتب الإجابة النموذجية مع القوانين أو التعليل التام..."
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-purple-500 text-right leading-relaxed"
                  />
                </div>

                <div className="flex items-center justify-between gap-4">
                  <div className="flex-1 max-w-xs">
                    <input
                      type="text"
                      value={newMinQTopic}
                      onChange={(e) => setNewMinQTopic(e.target.value)}
                      placeholder="الموضوع أو الفصل (مثال: الزمرة الأولى)"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2 text-xs text-white focus:outline-none text-right"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={handleAddMinisterialQuestion}
                    className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-black flex items-center gap-1.5 cursor-pointer shadow-md shadow-purple-600/20"
                  >
                    <Plus className="w-4 h-4" />
                    <span>إضافة السؤال الوزاري 🎯</span>
                  </button>
                </div>
              </div>

              {/* List of Ministerial Questions */}
              <div className="space-y-3">
                <h4 className="text-xs font-black text-slate-300">
                  الأسئلة الوزارية الحالية ({ministerialArchive.length}):
                </h4>

                {ministerialArchive.length === 0 ? (
                  <p className="text-xs text-slate-500 text-center py-4">
                    لا توجد أسئلة وزارية مضافة بعد.
                  </p>
                ) : (
                  ministerialArchive.map((q) => (
                    <div
                      key={q.id}
                      className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2.5 relative"
                    >
                      <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded-md bg-purple-500/20 text-purple-300 text-[10px] font-bold">
                            {q.type || 'سؤال وزاري'}
                          </span>
                          {q.topic && (
                            <span className="text-[10px] text-slate-400">
                              • {q.topic}
                            </span>
                          )}
                        </div>

                        <button
                          type="button"
                          onClick={() => handleDeleteMinisterialQuestion(q.id)}
                          className="p-1.5 rounded-lg bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <h5 className="text-xs font-black text-white">{q.question}</h5>
                      <p className="text-xs text-slate-300 bg-slate-900/80 p-3 rounded-xl whitespace-pre-wrap leading-relaxed">
                        {q.answer}
                      </p>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* TAB 5: SELF QUIZ */}
          {activeTab === 'quiz' && (
            <div className="space-y-6">
              {/* Add Quiz Question */}
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
                <h4 className="text-xs font-black text-white flex items-center gap-2">
                  <PenTool className="w-4 h-4 text-emerald-400" />
                  <span>إضافة سؤال اختيار من متعدد لاختبار (امتحن نفسي)</span>
                </h4>

                <div>
                  <label className="text-[11px] font-bold text-slate-400 block mb-1">
                    نص السؤال:
                  </label>
                  <input
                    type="text"
                    value={newQuizQ}
                    onChange={(e) => setNewQuizQ(e.target.value)}
                    placeholder="مثال: ما هو الرمز الكيميائي لعنصر الصوديوم؟"
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-emerald-500 text-right"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 block mb-1">الخيار 1:</label>
                    <input
                      type="text"
                      value={newQuizOpt1}
                      onChange={(e) => setNewQuizOpt1(e.target.value)}
                      placeholder="الخيار الأول"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2 text-xs text-white text-right"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 block mb-1">الخيار 2:</label>
                    <input
                      type="text"
                      value={newQuizOpt2}
                      onChange={(e) => setNewQuizOpt2(e.target.value)}
                      placeholder="الخيار الثاني"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2 text-xs text-white text-right"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 block mb-1">الخيار 3:</label>
                    <input
                      type="text"
                      value={newQuizOpt3}
                      onChange={(e) => setNewQuizOpt3(e.target.value)}
                      placeholder="الخيار الثالث"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2 text-xs text-white text-right"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 block mb-1">الخيار 4:</label>
                    <input
                      type="text"
                      value={newQuizOpt4}
                      onChange={(e) => setNewQuizOpt4(e.target.value)}
                      placeholder="الخيار الرابع"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2 text-xs text-white text-right"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-400 block mb-1">
                      الخيار الصحيح:
                    </label>
                    <select
                      value={newQuizCorrect}
                      onChange={(e) => setNewQuizCorrect(parseInt(e.target.value))}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none text-right font-bold text-emerald-400"
                    >
                      <option value={0}>الخيار الأول هو الصحيح ✓</option>
                      <option value={1}>الخيار الثاني هو الصحيح ✓</option>
                      <option value={2}>الخيار الثالث هو الصحيح ✓</option>
                      <option value={3}>الخيار الرابع هو الصحيح ✓</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-slate-400 block mb-1">
                      توضيح وشرح الإجابة:
                    </label>
                    <input
                      type="text"
                      value={newQuizExplanation}
                      onChange={(e) => setNewQuizExplanation(e.target.value)}
                      placeholder="شرح مختصر يظهر للطالب بعد الحل..."
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none text-right"
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleAddQuizQuestion}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black flex items-center gap-1.5 cursor-pointer shadow-md shadow-emerald-600/20"
                >
                  <Plus className="w-4 h-4" />
                  <span>إضافة سؤال الاختبار ✍️</span>
                </button>
              </div>

              {/* Quiz list */}
              <div className="space-y-3">
                <h4 className="text-xs font-black text-slate-300">
                  أسئلة الاختبار الحالية ({quizQuestions.length}):
                </h4>

                {quizQuestions.length === 0 ? (
                  <p className="text-xs text-slate-500 text-center py-4">
                    لا توجد أسئلة اختبار مضافة بعد.
                  </p>
                ) : (
                  quizQuestions.map((item, qIdx) => (
                    <div
                      key={item.id || qIdx}
                      className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2 relative"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-white">
                          سؤال {qIdx + 1}: {item.question}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleDeleteQuizQuestion(item.id)}
                          className="p-1.5 rounded-lg bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-[11px]">
                        {item.options.map((opt, oIdx) => (
                          <div
                            key={oIdx}
                            className={`p-2 rounded-lg border ${
                              oIdx === item.correctAnswerIndex
                                ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300 font-bold'
                                : 'bg-slate-900 border-slate-800 text-slate-400'
                            }`}
                          >
                            {opt} {oIdx === item.correctAnswerIndex && '✓ (الصحيح)'}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Bottom Actions Bar */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => {
                const previewBookObj: BookItem = {
                  ...editingBook,
                  ...formData,
                  samplePages,
                  ministerialArchive,
                  quiz: quizQuestions
                } as BookItem;
                closeModal();
                setActiveReadingBook(previewBookObj);
              }}
              className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Eye className="w-4 h-4 text-blue-400" />
              <span>معاينة في القارئ 👁️</span>
            </button>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={closeModal}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white text-xs font-bold cursor-pointer"
            >
              إلغاء
            </button>

            <button
              type="button"
              onClick={handleSaveAll}
              className="flex-1 sm:flex-initial px-6 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-black shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 cursor-pointer transition-transform active:scale-95"
            >
              <Save className="w-4 h-4" />
              <span>حفظ التعديلات في المنصة 💾</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
