import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { EducationalStage } from '../../types';
import {
  X,
  GraduationCap,
  Phone,
  User,
  MapPin,
  Sparkles,
  CheckCircle2,
  LogIn,
  ShieldCheck
} from 'lucide-react';

export const StudentLoginModal: React.FC = () => {
  const { activeModal, closeModal, loginUser, user, isLoggedIn, showToast } = useApp();

  const [name, setName] = useState(user.name || '');
  const [phone, setPhone] = useState(user.phone || '07734378998');
  const [grade, setGrade] = useState<EducationalStage>(user.grade as EducationalStage || 'الثالث متوسط');
  const [governorate, setGovernorate] = useState(user.governorate || 'بغداد');

  if (activeModal !== 'student-login-modal') return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      showToast('يرجى كتابة اسم الطالب ورقم الهاتف', 'error');
      return;
    }

    loginUser(phone.trim(), name.trim(), grade, governorate);
    closeModal();
  };

  const IRAQI_GOVERNORATES = [
    'بغداد',
    'البصرة',
    'نينوى (الموصل)',
    'أربيل',
    'كركوك',
    'النجف الأشرف',
    'كربلاء المقدسة',
    'ذي قار (الناصرية)',
    'بابل (الحلة)',
    'ديالى',
    'الأنبار',
    'واسط (الكوت)',
    'ميسان (العمارة)',
    'المثنى (السماوة)',
    'القادسية (الديوانية)',
    'صلاح الدين (تكريت)',
    'دهوك',
    'السليمانية'
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-2xl overflow-hidden font-['Tajawal']">
        {/* Glow */}
        <div className="absolute top-0 right-0 -mr-12 -mt-12 w-40 h-40 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={closeModal}
          className="absolute top-4 left-4 p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="w-13 h-13 mx-auto mb-3 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-blue-600/30">
            <GraduationCap className="w-7 h-7" />
          </div>
          <h3 className="text-xl font-black text-white">تسجيل دخول الطالب 🎓</h3>
          <p className="text-slate-400 text-xs mt-1">
            سجل بياناتك لمزامنة المواد المفعلة والاختبارات والملاحظات الدراسية
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              اسم الطالب الثلاثي:
            </label>
            <div className="relative">
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="مثال: حيدر أحمد علي"
                className="w-full pl-3 pr-10 py-3 bg-slate-950 border border-slate-800 focus:border-blue-500 rounded-xl text-white text-xs font-bold outline-none"
              />
              <User className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              رقم الهاتف / الواتساب:
            </label>
            <div className="relative">
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="07734378998"
                className="w-full pl-3 pr-10 py-3 bg-slate-950 border border-slate-800 focus:border-blue-500 rounded-xl text-white text-xs font-mono font-bold outline-none"
              />
              <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                المرحلة الدراسية:
              </label>
              <select
                value={grade}
                onChange={(e) => setGrade(e.target.value as EducationalStage)}
                className="w-full p-3 bg-slate-950 border border-slate-800 focus:border-blue-500 rounded-xl text-white text-xs font-bold outline-none"
              >
                <option value="السادس العلمي">السادس العلمي</option>
                <option value="السادس الأدبي">السادس الأدبي</option>
                <option value="الثالث متوسط">الثالث متوسط</option>
                <option value="السادس ابتدائي">السادس ابتدائي</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                المحافظة:
              </label>
              <select
                value={governorate}
                onChange={(e) => setGovernorate(e.target.value)}
                className="w-full p-3 bg-slate-950 border border-slate-800 focus:border-blue-500 rounded-xl text-white text-xs font-bold outline-none"
              >
                {IRAQI_GOVERNORATES.map((gov) => (
                  <option key={gov} value={gov}>
                    {gov}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3.5 px-4 rounded-xl font-black text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 shadow-lg shadow-blue-600/25 transition-all flex items-center justify-center gap-2 cursor-pointer text-xs sm:text-sm"
            >
              <LogIn className="w-4 h-4" />
              <span>دخول وحفظ البيانات 🚀</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
