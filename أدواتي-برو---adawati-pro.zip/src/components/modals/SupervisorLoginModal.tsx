import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ShieldCheck,
  KeyRound,
  X,
  Sparkles,
  CheckCircle2,
  Lock,
  Unlock,
  BookOpen,
  FileText,
  Users,
  Settings,
  Flame,
  Award
} from 'lucide-react';

export const SupervisorLoginModal: React.FC = () => {
  const {
    activeModal,
    closeModal,
    isSupervisor,
    verifySupervisorCode,
    exitSupervisorMode,
    SUPERVISOR_CODES,
    showToast,
    setViewMode,
    resetBooksToDefault
  } = useApp();

  const [inputCode, setInputCode] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  if (activeModal !== 'supervisor-login') return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputCode.trim()) {
      setErrorMsg('يرجى كتابة كود المشرف');
      return;
    }

    const ok = verifySupervisorCode(inputCode);
    if (ok) {
      setErrorMsg('');
      setInputCode('');
      closeModal();
    } else {
      setErrorMsg('الكود غير صحيح! يرجى التأكد من كود المشرف المعتمد');
    }
  };

  const handleQuickCode = (code: string) => {
    setInputCode(code);
    const ok = verifySupervisorCode(code);
    if (ok) {
      setErrorMsg('');
      setInputCode('');
      closeModal();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 text-right font-['Tajawal','Cairo',sans-serif] overflow-hidden"
        dir="rtl"
      >
        {/* Glow accent */}
        <div className="absolute -top-24 -left-24 w-52 h-52 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-52 h-52 bg-blue-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center text-white shadow-lg shadow-amber-500/30">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-white">بوابة كود المشرف العام 👑</h2>
                {isSupervisor && (
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold">
                    نشط الآن ✓
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400 font-medium">
                صلاحيات كاملة للتحكم في الكتب والمناهج وإضافة وتعديل ملفات PDF
              </p>
            </div>
          </div>

          <button
            onClick={closeModal}
            className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current status info */}
        {isSupervisor ? (
          <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 space-y-3">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
              <CheckCircle2 className="w-4 h-4" />
              <span>أنت مسجل حالياً بوضع المشرف العام (كافة الصلاحيات مفتوحة)</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              يمكنك الآن تعديل أي كتاب في المنصة بالضغط على زر <b>تعديل المادة ✏️</b> المتوفر على كروت الكتب، أو الدخول للوحة الإدارة وإرفاق ملفات الـ PDF وتعديل الأسئلة الوزارية.
            </p>

            <div className="flex items-center gap-2 pt-1 flex-wrap">
              <button
                onClick={() => {
                  closeModal();
                  setViewMode('admin-dashboard');
                }}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-black shadow-md shadow-blue-600/30 cursor-pointer"
              >
                لوحة الإدارة الكاملة 📊
              </button>
              <button
                onClick={() => {
                  exitSupervisorMode();
                }}
                className="px-4 py-2 bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 rounded-xl text-xs font-bold cursor-pointer"
              >
                إنهاء وضع المشرف 🔒
              </button>
            </div>
          </div>
        ) : (
          /* Enter Code Form */
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-black text-slate-300 block">
                أدخل كود المشرف المعتمد:
              </label>
              <div className="relative">
                <input
                  type="password"
                  value={inputCode}
                  onChange={(e) => {
                    setInputCode(e.target.value);
                    setErrorMsg('');
                  }}
                  placeholder="أدخل الكود (مثال: SUPERVISOR2026)"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-2xl py-3 px-4 text-center font-mono text-sm text-white placeholder-slate-600 focus:outline-none transition-colors"
                  autoFocus
                />
                <KeyRound className="w-5 h-5 text-slate-500 absolute left-4 top-3.5" />
              </div>
              {errorMsg && (
                <p className="text-xs text-rose-400 font-bold pr-1">{errorMsg}</p>
              )}
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-white text-xs font-black rounded-2xl shadow-lg shadow-amber-500/25 flex items-center justify-center gap-2 cursor-pointer transition-transform active:scale-95"
            >
              <Unlock className="w-4 h-4" />
              <span>تفعيل صلاحيات المشرف العام 👑</span>
            </button>
          </form>
        )}

        {/* Quick Demo Access Codes */}
        <div className="space-y-2.5 pt-2 border-t border-slate-800/80">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-bold">أكواد سريعة معتمدة للمشرف:</span>
            <span className="text-[10px] text-amber-400">انقر للنسخ والتفعيل</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {['SUPERVISOR2026', 'ADMIN2026', '123456', 'IRAQ3RD', 'TALABATI2026'].map((code) => (
              <button
                key={code}
                type="button"
                onClick={() => handleQuickCode(code)}
                className="p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700/60 text-slate-200 hover:text-amber-300 text-xs font-mono font-bold transition-all text-center cursor-pointer hover:border-amber-500/40"
              >
                {code}
              </button>
            ))}
          </div>
        </div>

        {/* Privileges checklist */}
        <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-2 text-xs text-slate-300">
          <h4 className="font-black text-white flex items-center gap-1.5 text-[11px]">
            <Award className="w-4 h-4 text-amber-400" />
            <span>ما الذي يمكنك فعله كـ "مشرف عام"؟</span>
          </h4>
          <ul className="space-y-1.5 text-[11px] text-slate-400">
            <li className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              <span>تعديل كافة كتب الثالث متوسط وإضافة فصول وملاحظات وزارية.</span>
            </li>
            <li className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              <span>رفع وتضمين ملفات PDF الخاصة بكل مادة مباشرة من جهازك أو برابط مباشر.</span>
            </li>
            <li className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              <span>إضافة وحذف أسئلة المرشحات الوزارية واختبارات امتحن نفسي.</span>
            </li>
            <li className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              <span>توليد أكواد التفعيل وتفعيل المواد للطلاب فور استلام الحوالة.</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
