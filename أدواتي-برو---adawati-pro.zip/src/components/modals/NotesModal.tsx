import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Plus, Trash2, Edit3, BookOpen, Calendar } from 'lucide-react';
import { SubjectCategory } from '../../types';

export const NotesModal: React.FC = () => {
  const { studyNotes, addStudyNote, deleteStudyNote, closeModal, books } = useApp();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [subject, setSubject] = useState<SubjectCategory>('الرياضيات');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;
    addStudyNote({
      title,
      content,
      subject
    });
    setTitle('');
    setContent('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <button
            onClick={closeModal}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-black text-white">دفتر الملاحظات الدراسية</h3>
            <Edit3 className="w-4 h-4 text-purple-400" />
          </div>
        </div>

        <div className="p-5 overflow-y-auto space-y-5">
          {/* Add note form */}
          <form onSubmit={handleAdd} className="space-y-3 bg-slate-950 p-4 rounded-2xl border border-slate-800 text-right">
            <h4 className="text-xs font-black text-white">إضافة ملاحظة جديدة</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="عنوان الملاحظة (مثال: قوانين المثلثات)"
                className="bg-slate-900 text-white text-xs rounded-xl p-2.5 border border-slate-700 text-right focus:outline-none focus:border-blue-500"
                required
              />

              <select
                value={subject}
                onChange={(e) => setSubject(e.target.value as SubjectCategory)}
                className="bg-slate-900 text-white text-xs rounded-xl p-2.5 border border-slate-700 text-right focus:outline-none focus:border-blue-500"
              >
                <option value="الرياضيات">الرياضيات</option>
                <option value="اللغة العربية">اللغة العربية</option>
                <option value="اللغة الإنجليزية">اللغة الإنجليزية</option>
                <option value="العلوم">العلوم</option>
                <option value="الكيمياء">الكيمياء</option>
                <option value="الفيزياء">الفيزياء</option>
                <option value="الأحياء">الأحياء</option>
                <option value="التربية الإسلامية">التربية الإسلامية</option>
                <option value="الاجتماعيات">الاجتماعيات</option>
              </select>
            </div>

            <textarea
              rows={2}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="اكتب ملاحظاتك، القوانين المهمة، أو الثوابت الوزارية..."
              className="w-full bg-slate-900 text-white text-xs rounded-xl p-2.5 border border-slate-700 text-right focus:outline-none focus:border-blue-500"
              required
            />

            <button
              type="submit"
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-black rounded-xl flex items-center justify-center gap-1.5 transition-transform active:scale-98"
            >
              <Plus className="w-4 h-4" />
              <span>حفظ الملاحظة</span>
            </button>
          </form>

          {/* Notes list */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-black text-slate-400 text-right">ملاحظاتي المحفوظة ({studyNotes.length})</h4>
            {studyNotes.map((note) => (
              <div key={note.id} className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2 text-right">
                <div className="flex items-center justify-between">
                  <button
                    onClick={() => deleteStudyNote(note.id)}
                    className="p-1 rounded-lg text-slate-500 hover:text-rose-400 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>

                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-purple-300 font-bold px-2 py-0.5 rounded-md bg-purple-950/60 border border-purple-800/40">
                      {note.subject}
                    </span>
                    <h5 className="text-xs font-black text-white">{note.title}</h5>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed font-sans">{note.content}</p>

                <div className="flex items-center justify-end gap-1 text-[10px] text-slate-500 font-mono">
                  <span>{note.date}</span>
                  <Calendar className="w-3 h-3" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
