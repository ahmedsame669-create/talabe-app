import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  PlusCircle,
  HelpCircle,
  Award,
  Sparkles,
  BookOpen,
  CheckCircle2
} from 'lucide-react';

export const AddMinisterialQuestionModal: React.FC = () => {
  const { activeModal, closeModal, books, addMinisterialQuestionToBook, showToast } = useApp();

  const [selectedBookId, setSelectedBookId] = useState<number>(books[0]?.id || 1);
  const [questionText, setQuestionText] = useState('');
  const [modelAnswer, setModelAnswer] = useState('');
  const [yearExam, setYearExam] = useState('وزاري 2025 دور أول');
  const [importance, setImportance] = useState<'ثابت ومهم جداً 🔥' | 'مكرر وزارياً' | 'مرشح قوي 2026' | 'سؤال فكري'>('مرشح قوي 2026');
  const [topic, setTopic] = useState('الفصل الأول');

  if (activeModal !== 'add-ministerial-question-modal') return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!questionText.trim() || !modelAnswer.trim()) {
      showToast('يرجى كتابة نص السؤال والجواب النموذجي', 'error');
      return;
    }

    addMinisterialQuestionToBook(selectedBookId, {
      question: questionText.trim(),
      answer: modelAnswer.trim(),
      year: yearExam.trim(),
      importance: importance,
      topic: topic.trim() || 'الفصل الأول'
    });

    setQuestionText('');
    setModelAnswer('');
    closeModal();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-2xl overflow-hidden font-['Tajawal'] max-h-[92vh] overflow-y-auto">
        {/* Glow */}
        <div className="absolute top-0 right-0 -mr-12 -mt-12 w-40 h-40 bg-amber-600/20 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={closeModal}
          className="absolute top-4 left-4 p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="w-13 h-13 mx-auto mb-3 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center text-white shadow-lg shadow-amber-500/30">
            <Award className="w-7 h-7" />
          </div>
          <h3 className="text-xl font-black text-white">إضافة سؤال وزاري أو مرشح جديد 🎯</h3>
          <p className="text-slate-400 text-xs mt-1">
            صلاحية إدارة المنصة لرفع وحفظ أسئلة مع حلولها النموذجية لطلبة العراق
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              اختر المادة الدراسية:
            </label>
            <select
              value={selectedBookId}
              onChange={(e) => setSelectedBookId(Number(e.target.value))}
              className="w-full p-3 bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl text-white text-xs font-bold outline-none"
            >
              {books.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.title} ({b.grade})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                الدور أو السنة الوزارية:
              </label>
              <input
                type="text"
                value={yearExam}
                onChange={(e) => setYearExam(e.target.value)}
                placeholder="مثال: وزاري 2024 دور ثاني"
                className="w-full p-3 bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl text-white text-xs font-bold outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                درجة الأهمية:
              </label>
              <select
                value={importance}
                onChange={(e) => setImportance(e.target.value as any)}
                className="w-full p-3 bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl text-white text-xs font-bold outline-none"
              >
                <option value="ثابت ومهم جداً 🔥">ثابت ومهم جداً 🔥</option>
                <option value="مرشح قوي 2026">مرشح قوي 2026</option>
                <option value="مكرر وزارياً">مكرر وزارياً</option>
                <option value="سؤال فكري">سؤال فكري</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              الوحدة أو الفصل:
            </label>
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="مثال: الفصل الثاني - المقادير الجبرية"
              className="w-full p-3 bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl text-white text-xs font-bold outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              نص السؤال أو التعليل:
            </label>
            <textarea
              required
              rows={3}
              value={questionText}
              onChange={(e) => setQuestionText(e.target.value)}
              placeholder="اكتب صيغة السؤال الوزاري بدقة..."
              className="w-full p-3 bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl text-white text-xs font-medium outline-none resize-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              الجواب النموذجي المعتمد في مركز الفحص:
            </label>
            <textarea
              required
              rows={4}
              value={modelAnswer}
              onChange={(e) => setModelAnswer(e.target.value)}
              placeholder="اكتب الحل النموذجي خطوة بخطوة..."
              className="w-full p-3 bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl text-white text-xs font-medium outline-none resize-none"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3.5 px-4 rounded-xl font-black text-white bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-500 shadow-lg shadow-amber-500/25 transition-all flex items-center justify-center gap-2 cursor-pointer text-xs sm:text-sm"
            >
              <PlusCircle className="w-4 h-4" />
              <span>حفظ وإضافة السؤال للمادة 🚀</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
