import React from 'react';
import { useApp } from '../../context/AppContext';
import { X, BookOpen, ShieldCheck, Award, Smartphone, Globe, Sparkles } from 'lucide-react';

export const AboutModal: React.FC = () => {
  const { closeModal } = useApp();

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <button
            onClick={closeModal}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-black text-white">عن تطبيق منصة طلبتي</h3>
            <BookOpen className="w-4 h-4 text-blue-400" />
          </div>
        </div>

        <div className="p-6 text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 to-cyan-400 p-0.5 shadow-xl mx-auto">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
              <BookOpen className="w-8 h-8 text-cyan-400" />
            </div>
          </div>

          <div className="space-y-1">
            <h2 className="text-base font-black text-white">منصة طلبتي للمناهج الدراسية</h2>
            <p className="text-xs text-blue-400 font-bold">الإصدار 2.5.0 - طبعة 2026 المعتمدة</p>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed text-right">
            تطبيق تعليمي متكامل يوفر جميع الكتب المدرسية والمناهج الوزارية المعتمدة لطلبة المراحل المتوسطة والإعدادية في العراق، مع إمكانية التحميل المباشر والقراءة أوفلاين وخوض الاختبارات الذاتية.
          </p>

          <div className="grid grid-cols-2 gap-2 text-right text-xs">
            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-slate-400 font-bold block">الجهة:</span>
              <span className="text-white font-black">وزارة التربية 🇮🇶</span>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-slate-400 font-bold block">التوافق:</span>
              <span className="text-emerald-400 font-black">Android, iOS, Web</span>
            </div>
          </div>

          <button
            onClick={closeModal}
            className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white text-xs font-black rounded-xl shadow-lg shadow-blue-600/30 cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
