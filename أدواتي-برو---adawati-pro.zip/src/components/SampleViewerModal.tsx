import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  ChevronRight,
  ChevronLeft,
  BookOpen,
  Lock,
  Sparkles,
  Award,
  HelpCircle,
  Maximize2,
  ZoomIn,
  ZoomOut,
  FileText
} from 'lucide-react';

export const SampleViewerModal: React.FC = () => {
  const {
    activeModal,
    closeModal,
    selectedBookForSample,
    openPayModalForBook,
    isBookUnlocked,
    setActiveReadingBook,
  } = useApp();

  const [currentPageIndex, setCurrentPageIndex] = useState(0);
  const [fontSize, setFontSize] = useState<'sm' | 'base' | 'lg'>('base');

  if (activeModal !== 'sample' || !selectedBookForSample) return null;

  const pages = selectedBookForSample.samplePages || [];
  const currentPage = pages[currentPageIndex] || pages[0];
  const unlocked = isBookUnlocked(selectedBookForSample.id);

  const handleNextPage = () => {
    if (currentPageIndex < pages.length - 1) {
      setCurrentPageIndex((prev) => prev + 1);
    }
  };

  const handlePrevPage = () => {
    if (currentPageIndex > 0) {
      setCurrentPageIndex((prev) => prev - 1);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-md">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full">
                  معاينة مجانية (عينة)
                </span>
                <span className="text-xs text-slate-300">
                  {selectedBookForSample.category}
                </span>
              </div>
              <h2 className="text-sm sm:text-base font-black truncate max-w-xs sm:max-w-md">
                {selectedBookForSample.title}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Font size control */}
            <div className="hidden sm:flex items-center bg-slate-800 rounded-xl p-1 text-xs">
              <button
                onClick={() => setFontSize('sm')}
                className={`px-2 py-1 rounded-lg ${fontSize === 'sm' ? 'bg-indigo-600 text-white' : 'text-slate-400'}`}
              >
                A-
              </button>
              <button
                onClick={() => setFontSize('base')}
                className={`px-2 py-1 rounded-lg ${fontSize === 'base' ? 'bg-indigo-600 text-white' : 'text-slate-400'}`}
              >
                A
              </button>
              <button
                onClick={() => setFontSize('lg')}
                className={`px-2 py-1 rounded-lg ${fontSize === 'lg' ? 'bg-indigo-600 text-white' : 'text-slate-400'}`}
              >
                A+
              </button>
            </div>

            <button
              onClick={closeModal}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Reader Page Content Body */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-6 bg-slate-50/50 dark:bg-slate-900/50">
          {currentPage ? (
            <div className="max-w-2xl mx-auto space-y-6">
              {/* Page Title & Subtitle banner */}
              <div className="pb-4 border-b border-slate-200 dark:border-slate-800">
                <span className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 block mb-1">
                  صفحة العينة رقم ({currentPage.pageNumber} من {pages.length})
                </span>
                <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
                  {currentPage.title}
                </h3>
                {currentPage.subtitle && (
                  <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 font-medium mt-1">
                    {currentPage.subtitle}
                  </p>
                )}
              </div>

              {/* Text Paragraphs */}
              <div className={`space-y-3 leading-relaxed text-slate-700 dark:text-slate-200 ${
                fontSize === 'sm' ? 'text-xs' : fontSize === 'lg' ? 'text-base' : 'text-sm'
              }`}>
                {currentPage.content.map((paragraph, idx) => (
                  <p key={idx} className="p-3.5 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 shadow-xs">
                    {paragraph}
                  </p>
                ))}
              </div>

              {/* Important Formulas if exists */}
              {currentPage.importantFormulas && currentPage.importantFormulas.length > 0 && (
                <div className="p-4 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 space-y-2">
                  <span className="text-xs font-black text-indigo-900 dark:text-indigo-300 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                    <span>القوانين الوزارية الهامة للحفظ:</span>
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 font-mono text-xs font-bold text-indigo-950 dark:text-indigo-200">
                    {currentPage.importantFormulas.map((form, i) => (
                      <div key={i} className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-indigo-100 dark:border-indigo-900">
                        {form}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Ministerial Exam Question Snippet */}
              {currentPage.questionSnippet && (
                <div className="p-5 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-amber-900 dark:text-amber-300 flex items-center gap-1.5">
                      <Award className="w-4 h-4 text-amber-600" />
                      <span>سؤال وزاري مكرر:</span>
                    </span>
                    <span className="text-[10px] font-bold bg-amber-200/60 dark:bg-amber-900/60 text-amber-900 dark:text-amber-200 px-2 py-0.5 rounded-md">
                      {currentPage.questionSnippet.year}
                    </span>
                  </div>

                  <p className="text-xs font-bold text-slate-800 dark:text-slate-100">
                    {currentPage.questionSnippet.question}
                  </p>

                  <div className="p-3 rounded-xl bg-white dark:bg-slate-800 border border-amber-100 dark:border-amber-900/60 text-xs text-emerald-700 dark:text-emerald-400 font-medium">
                    <strong className="block text-[11px] text-slate-500 mb-1">الجواب النموذجي المعتمد بالوزاري:</strong>
                    {currentPage.questionSnippet.answer}
                  </div>
                </div>
              )}

              {/* Ministerial Note Box */}
              {currentPage.ministerialNote && (
                <div className="p-4 rounded-2xl bg-purple-50 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-800/80 text-xs text-purple-950 dark:text-purple-200 leading-relaxed font-bold">
                  {currentPage.ministerialNote}
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-12 text-slate-400">
              لا توجد صفحات عينة إضافية
            </div>
          )}
        </div>

        {/* Modal Footer Controls */}
        <div className="p-4 sm:p-5 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 flex-shrink-0">
          {/* Pagination buttons */}
          <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-start">
            <button
              onClick={handlePrevPage}
              disabled={currentPageIndex === 0}
              className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 disabled:opacity-30 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center gap-1 cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
              <span>السابق</span>
            </button>

            <span className="text-xs font-bold font-mono text-slate-500">
              {currentPageIndex + 1} / {pages.length}
            </span>

            <button
              onClick={handleNextPage}
              disabled={currentPageIndex >= pages.length - 1}
              className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 disabled:opacity-30 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center gap-1 cursor-pointer"
            >
              <span>التالي</span>
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>

          {/* Direct Unlock Call to Action */}
          <div className="w-full sm:w-auto">
            {unlocked ? (
              <button
                onClick={() => {
                  closeModal();
                  setActiveReadingBook(selectedBookForSample);
                }}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black shadow-md shadow-emerald-600/30 flex items-center justify-center gap-2"
              >
                <BookOpen className="w-4 h-4" />
                <span>أنت تملك هذا الكتاب — تصفح الآن</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  const book = selectedBookForSample;
                  closeModal();
                  openPayModalForBook(book);
                }}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-black shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Lock className="w-4 h-4 text-amber-300" />
                <span>فتح الملزمة كاملة ({selectedBookForSample.pagesCount} صفحة بـ 10,000 د.ع)</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
