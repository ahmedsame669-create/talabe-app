import React from 'react';
import { BookItem } from '../types';
import { useApp } from '../context/AppContext';
import {
  Lock,
  Unlock,
  Eye,
  FileText,
  Star,
  BookOpen,
  Sparkles,
  Award,
  PenTool,
  CheckCircle2,
  Edit3,
  FileCheck
} from 'lucide-react';

interface BookCardProps {
  book: BookItem;
}

export const BookCard: React.FC<BookCardProps> = ({ book }) => {
  const {
    openPayModalForBook,
    openSampleModalForBook,
    openQuizModalForBook,
    isBookUnlocked,
    setActiveReadingBook,
    isSupervisor,
    openBookEditorForBook
  } = useApp();

  const unlocked = isBookUnlocked(book.id);

  return (
    <div className="group relative bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/90 dark:border-slate-800/90 shadow-md hover:shadow-2xl hover:border-indigo-500/50 transition-all duration-300 flex flex-col justify-between overflow-hidden">
      {/* Top Banner & Gradient Header */}
      <div className={`p-5 bg-gradient-to-r ${book.gradient} text-white relative`}>
        {/* Floating badges */}
        <div className="absolute top-3.5 left-3.5 flex items-center gap-1.5 flex-wrap">
          {(book.pdfDataUrl || book.customPdfUrl) && (
            <span className="text-[10px] font-black bg-emerald-950/80 backdrop-blur-md text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30 flex items-center gap-1">
              <FileCheck className="w-3 h-3" />
              <span>PDF مدمج</span>
            </span>
          )}
          {book.badge && (
            <span className="text-[10px] font-black bg-black/40 backdrop-blur-md text-white px-2.5 py-1 rounded-full border border-white/20 shadow-xs">
              {book.badge}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2 mb-2">
          <span className="text-[11px] font-bold bg-white/20 px-2.5 py-0.5 rounded-lg backdrop-blur-xs">
            {book.category}
          </span>
          <span className="text-[11px] font-extrabold bg-black/20 px-2 py-0.5 rounded-lg text-amber-200 border border-white/10">
            {book.grade}
          </span>
          {isSupervisor && (
            <span className="text-[10px] font-black bg-amber-400 text-slate-950 px-2 py-0.5 rounded-md">
              مشرف 👑
            </span>
          )}
        </div>

        <h3 className="text-lg font-black leading-snug line-clamp-2">
          {book.title}
        </h3>

        {/* Target Score Guarantee Line */}
        <div className="flex items-center gap-1.5 text-xs text-amber-200 mt-2.5 font-black bg-black/25 w-fit px-2.5 py-1 rounded-xl border border-amber-300/20">
          <Award className="w-3.5 h-3.5 text-amber-300 shrink-0" />
          <span>{book.targetGuarantee}</span>
        </div>
      </div>

      {/* Card Body */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed line-clamp-3">
          {book.desc}
        </p>

        {/* Specs Pill info */}
        <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
          <div className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400">
            <FileText className="w-3.5 h-3.5 text-indigo-500" />
            <span className="font-mono font-bold text-slate-700 dark:text-slate-300">{book.pagesCount}</span>
            <span>صفحة مركزة</span>
          </div>

          <div className="flex items-center gap-1 text-slate-500 dark:text-slate-400 justify-end">
            <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
            <span className="font-mono font-bold text-slate-700 dark:text-slate-200">{book.rating}</span>
            <span className="text-[10px]">({book.reviewsCount} تقييم)</span>
          </div>
        </div>

        {/* Price & Lock Status Display */}
        <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
              unlocked
                ? 'bg-emerald-500/20 text-emerald-500'
                : 'bg-amber-500/20 text-amber-600 dark:text-amber-400'
            }`}>
              {unlocked ? <Unlock className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
            </div>
            <div>
              <span className="text-[10px] text-slate-400 font-bold block">
                {unlocked ? 'حالة المادة' : 'سعر الفتح الشامل'}
              </span>
              <span className={`text-xs font-black ${unlocked ? 'text-emerald-500' : 'text-slate-800 dark:text-white'}`}>
                {unlocked ? 'مفتوحة ومفعلة ✓' : book.price}
              </span>
            </div>
          </div>

          <span className="text-[11px] text-slate-400 font-medium font-mono">
            {book.yearEdition}
          </span>
        </div>

        {/* Supervisor direct edit button */}
        {(isSupervisor || book.isEditable) && (
          <button
            onClick={() => openBookEditorForBook(book)}
            className="w-full py-2 px-3 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 text-xs font-black flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <Edit3 className="w-3.5 h-3.5 text-amber-400" />
            <span>تعديل المادة وإرفاق PDF (المشرف) ✏️</span>
          </button>
        )}

        {/* Action Buttons */}
        {unlocked ? (
          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              onClick={() => setActiveReadingBook(book)}
              className="flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black shadow-md shadow-emerald-600/30 transition-all cursor-pointer"
            >
              <BookOpen className="w-4 h-4" />
              <span>تصفح المرشحات</span>
            </button>

            <button
              onClick={() => openQuizModalForBook(book)}
              className="flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-black shadow-md shadow-purple-600/30 transition-all cursor-pointer animate-pulse"
            >
              <PenTool className="w-3.5 h-3.5 text-amber-300" />
              <span>امتحن نفسي ✍️</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
            <button
              onClick={() => openSampleModalForBook(book)}
              className="w-full flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold transition-colors cursor-pointer"
            >
              <Eye className="w-4 h-4 text-indigo-500" />
              <span>معاينة مجانية</span>
            </button>

            <button
              onClick={() => openPayModalForBook(book)}
              className="w-full flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-black shadow-md shadow-indigo-600/25 transition-all cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5 text-amber-300" />
              <span>فتح الملزمة (10 ألف)</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
