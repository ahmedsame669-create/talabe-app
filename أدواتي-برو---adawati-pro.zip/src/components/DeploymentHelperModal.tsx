import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Code2,
  Copy,
  Check,
  Globe,
  Database,
  Terminal,
  ExternalLink,
  ShieldCheck,
  Sparkles,
  CheckCircle2,
  Smartphone,
  Server,
  Layers,
  Flame,
  ArrowRight,
  Download
} from 'lucide-react';

export const DeploymentHelperModal: React.FC = () => {
  const { activeModal, closeModal, showToast, paymentInfo } = useApp();
  const [activeTab, setActiveTab] = useState<
    'github-server' | 'vercel' | 'supabase' | 'mongodb-neon' | 'mobile-install'
  >('github-server');
  const [copied, setCopied] = useState<string | null>(null);

  if (activeModal !== 'deploy-guide') return null;

  // 1. Full standalone server.js script for GitHub (talabe-backend)
  const standaloneServerCode = `const express = require('express');
const cors = require('cors');
const { createClient } = require('@supabase/supabase-js');

const app = express();
app.use(cors());
app.use(express.json());

// ==========================================
// 1. إعدادات الاتصال بقاعدة البيانات (Supabase / MongoDB / Neon)
// ==========================================
const supabaseUrl = process.env.SUPABASE_URL || '';
const supabaseKey = process.env.SUPABASE_ANON_KEY || '';
const supabase = (supabaseUrl && supabaseKey) ? createClient(supabaseUrl, supabaseKey) : null;

// ==========================================
// 2. معلومات الدفع المعتمدة (زين كاش وآسيا حوالة 07734378998)
// ==========================================
const PAYMENT_INFO = {
  zainCash: "${paymentInfo.zainCash || '07734378998'}",
  rafidainCard: "${paymentInfo.rafidainCard || '910160728184'}",
  rasheedCard: "${paymentInfo.rasheedCard || '6281 0000 0000 0000'}",
  asiaHawala: "${paymentInfo.asiaHawala || '07734378998'}",
  price: "10,000 د.ع",
  supportPhone: "${paymentInfo.supportPhone || '07734378998'}"
};

// ==========================================
// 3. قاعدة بيانات الملازم والمناهج (سعر كل ملزمة 10,000 د.ع)
// ==========================================
const booksData = [
  { id: 1, title: 'الرياضيات - الثالث متوسط', category: 'الرياضيات', price: '10,000 د.ع', pages: '240 صفحة', desc: 'المنهج الكامل مع حلول التمارين والأسئلة الوزارية المعتمدة 2026.' },
  { id: 2, title: 'اللغة العربية - الثالث متوسط', category: 'اللغة العربية', price: '10,000 د.ع', pages: '210 صفحة', desc: 'شامل القواعد، الأدب والنصوص والإنشاء مع نماذج وزارية.' },
  { id: 3, title: 'اللغة الإنجليزية - English for Iraq', category: 'اللغة الإنجليزية', price: '10,000 د.ع', pages: '190 صفحة', desc: 'القواعد والقطع الاستيعابية والإنشاءات والتمارين الوزارية المترجمة.' },
  { id: 4, title: 'الكيمياء - الثالث متوسط', category: 'الكيمياء', price: '10,000 د.ع', pages: '170 صفحة', desc: 'المعادلات، المسائل الحسابية، والكشوفات الوزارية المضمونة.' },
  { id: 5, title: 'الفيزياء - الثالث متوسط', category: 'الفيزياء', price: '10,000 د.ع', pages: '185 صفحة', desc: 'شرح القوانين الرياضية، ربط المقاومات، والمسائل المكررة وزارياً.' },
  { id: 6, title: 'الأحياء - الثالث متوسط', category: 'الأحياء', price: '10,000 د.ع', pages: '195 صفحة', desc: 'ملخص أجهزة جسم الإنسان مع كافة الرسومات والمخططات المطلوبة.' },
  { id: 7, title: 'الاجتماعيات - الثالث متوسط', category: 'الاجتماعيات', price: '10,000 د.ع', pages: '220 صفحة', desc: 'التاريخ، الجغرافيا، والتربية الوطنية مع حلول الخرائط والتعاليل.' },
  { id: 8, title: 'التربية الإسلامية - الثالث متوسط', category: 'التربية الإسلامية', price: '10,000 د.ع', pages: '140 صفحة', desc: 'أحكام التلاوة، تفسير السور، والأحاديث النبوية الشريفة.' },
  { id: 9, title: 'العلوم - الثالث متوسط', category: 'العلوم', price: '10,000 د.ع', pages: '200 صفحة', desc: 'شامل ومكثف لجميع الوحدات التعليمية مع حلول أسئلة الفصول.' }
];

// أكواد التفعيل المعتمدة
let activationCodes = [
  { code: 'TAL-VIP-2026', bookId: 'all', isUsed: false, student: 'طالب VIP' },
  { code: 'TAL-MATH-98', bookId: 1, isUsed: false, student: 'علي حسن' },
  { code: 'TAL-ARAB-77', bookId: 2, isUsed: false, student: 'زينب أحمد' }
];

// الطلبات المسجلة
let orders = [];

// ==========================================
// 4. مسارات API (Endpoints)
// ==========================================

// جلب الكتب
app.get('/api/books', async (req, res) => {
  if (supabase) {
    try {
      const { data, error } = await supabase.from('books').select('*');
      if (!error && data && data.length > 0) return res.json(data);
    } catch (e) {}
  }
  res.json(booksData);
});

// معلومات الدفع
app.get('/api/payment-info', (req, res) => {
  res.json(PAYMENT_INFO);
});

// تفعيل كود
app.post('/api/redeem-code', (req, res) => {
  const { code, student_name } = req.body;
  if (!code) return res.status(400).json({ success: false, message: 'يرجى إدخال الكود' });

  const found = activationCodes.find(c => c.code.toUpperCase() === code.trim().toUpperCase());
  if (!found) return res.status(404).json({ success: false, message: 'كود التفعيل غير صالح' });
  if (found.isUsed) return res.status(400).json({ success: false, message: 'تم استخدام هذا الكود سابقاً' });

  found.isUsed = true;
  found.usedBy = student_name || 'طالب';

  res.json({
    success: true,
    message: 'تم تفعيل وفتح المادة بنجاح 🎓',
    bookId: found.bookId
  });
});

// تسجيل طلب شراء ملزمة
app.post('/api/orders', async (req, res) => {
  const { student_name, phone, book_title, payment_method, transaction_ref, governorate } = req.body;
  if (!student_name || !phone || !book_title || !transaction_ref) {
    return res.status(400).json({ success: false, message: 'يرجى إكمال بيانات التحويل ورقم الوصل' });
  }

  const newOrder = {
    id: 'ORD-' + Date.now(),
    student_name,
    phone,
    governorate: governorate || 'العراق',
    book_title,
    payment_method,
    transaction_ref,
    price: '10,000 د.ع',
    status: 'قيد التحقق',
    created_at: new Date().toISOString()
  };

  orders.push(newOrder);

  if (supabase) {
    try {
      await supabase.from('orders').insert([newOrder]);
    } catch (e) {}
  }

  res.json({
    success: true,
    message: 'تم إرسال طلبك بنجاح! سيتم إرسال كود التفعيل لك فور تأكيد الحوالة.'
  });
});

// ==========================================
// 5. واجهة HTML التفاعلية المباشرة (تعمل بدون أخطاء 404 على Vercel و GitHub)
// ==========================================
app.get('*', (req, res) => {
  const booksCards = booksData.map(b => \`
    <div class="book-card">
      <span class="category-badge">\${b.category} • 10,000 د.ع</span>
      <h3 class="book-title">\${b.title}</h3>
      <p class="book-desc">\${b.desc}</p>
      <div class="book-footer">
        <span class="price-tag">10,000 د.ع</span>
        <button onclick="openPaymentModal('\${b.title}')" class="btn-lock">فتح المادة (10,000 د.ع) 🔒</button>
      </div>
    </div>
  \`).join('');

  const html = \`<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>منصة طلبتي التعليمية | المناهج والملازم الوزارية 2026</title>
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;900&display=swap" rel="stylesheet">
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Tajawal', sans-serif; }
    body { background: #0b0f19; color: #f1f5f9; padding: 20px 15px; }
    .container { max-width: 1100px; margin: 0 auto; }
    .header { text-align: center; margin: 25px 0 35px; }
    .header h1 { font-size: 2.3rem; font-weight: 900; color: #60a5fa; margin-bottom: 8px; }
    .header p { color: #94a3b8; font-size: 1rem; }
    .banner { background: linear-gradient(135deg, #1e1b4b, #2563eb); border-radius: 24px; padding: 25px; margin-bottom: 35px; text-align: center; border: 1px solid #3b82f6; box-shadow: 0 10px 30px -10px rgba(37,99,235,0.4); }
    .banner h2 { font-size: 1.5rem; font-weight: 900; margin-bottom: 10px; color: #fff; }
    .banner p { color: #dbeafe; font-size: 0.95rem; margin-bottom: 12px; }
    .badge-phone { display: inline-block; background: rgba(0,0,0,0.4); border: 1px solid #60a5fa; color: #93c5fd; padding: 6px 16px; border-radius: 999px; font-weight: bold; font-family: monospace; font-size: 0.95rem; }
    .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }
    .book-card { background: #131b2e; border: 1px solid #1e293b; border-radius: 20px; padding: 20px; display: flex; flex-direction: column; justify-content: space-between; }
    .category-badge { background: #1e3a8a; color: #93c5fd; font-size: 0.75rem; font-weight: bold; padding: 4px 10px; border-radius: 8px; align-self: flex-start; margin-bottom: 12px; }
    .book-title { font-size: 1.15rem; font-weight: 900; color: #fff; margin-bottom: 8px; }
    .book-desc { font-size: 0.85rem; color: #94a3b8; line-height: 1.5; margin-bottom: 20px; }
    .book-footer { display: flex; align-items: center; justify-content: space-between; border-top: 1px solid #1e293b; padding-top: 15px; }
    .price-tag { font-size: 1.1rem; font-weight: 900; color: #34d399; }
    .btn-lock { background: #d97706; hover: background #b45309; color: #fff; border: none; padding: 8px 16px; border-radius: 12px; font-weight: bold; font-size: 0.85rem; cursor: pointer; }
    .modal-bg { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.85); backdrop-filter: blur(6px); z-index: 100; align-items: center; justify-content: center; padding: 15px; }
    .modal-box { background: #131b2e; border: 1px solid #334155; border-radius: 24px; padding: 25px; width: 100%; max-width: 480px; max-height: 90vh; overflow-y: auto; }
    .form-inp { width: 100%; padding: 12px; border-radius: 12px; background: #0b0f19; border: 1px solid #334155; color: #fff; margin-bottom: 12px; font-size: 0.9rem; outline: none; }
    .btn-pay { width: 100%; background: #2563eb; color: #fff; border: none; padding: 14px; border-radius: 12px; font-weight: 900; font-size: 1rem; cursor: pointer; }
    .btn-wa { display: block; text-align: center; text-decoration: none; background: #16a34a; color: #fff; padding: 12px; border-radius: 12px; font-weight: bold; font-size: 0.9rem; margin-top: 10px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>🎓 منصة طلبتي التعليمية</h1>
      <p>المناهج والملازم المعتمدة وزارياً لطلاب العراق 2026</p>
    </div>

    <div class="banner">
      <h2>جميع المواد مقفلة • سعر تفعيل أي مادة 10,000 د.ع فقط 🔒</h2>
      <p>يتم إرسال كود التفعيل فوراً عبر الواتساب بعد إتمام التحويل</p>
      <div class="badge-phone">رقم زين كاش وآسيا حوالة المعتمد: \${PAYMENT_INFO.supportPhone}</div>
    </div>

    <div class="grid">\${booksCards}</div>
  </div>

  <div id="payModal" class="modal-bg">
    <div class="modal-box">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
        <h3 id="modalTitle" style="font-weight:900;">طلب تفعيل المادة</h3>
        <button onclick="document.getElementById('payModal').style.display='none'" style="background:none; border:none; color:#fff; font-size:1.5rem; cursor:pointer;">✕</button>
      </div>

      <div style="background:#0b0f19; padding:15px; border-radius:14px; border:1px solid #334155; margin-bottom:15px; font-size:0.85rem;">
        <p style="color:#60a5fa; font-weight:bold; margin-bottom:6px;">💳 تفاصيل التحويل (المبلغ: 10,000 د.ع):</p>
        <p>زين كاش: <b style="color:#38bdf8; font-family:monospace;">\${PAYMENT_INFO.zainCash}</b></p>
        <p>آسيا حوالة: <b style="color:#38bdf8; font-family:monospace;">\${PAYMENT_INFO.asiaHawala}</b></p>
      </div>

      <form onsubmit="sendOrder(event)">
        <input id="stuName" class="form-inp" placeholder="اسم الطالب الثلاثي" required />
        <input id="stuPhone" class="form-inp" placeholder="رقم الهاتف (الواتساب)" required />
        <input id="stuTrans" class="form-inp" placeholder="رقم إشعار التحويل / الوصل" required />
        <button type="submit" class="btn-pay">إرسال وتأكيد الطلب 🚀</button>
        <a id="waLink" href="https://wa.me/\${PAYMENT_INFO.supportPhone}" target="_blank" class="btn-wa">📲 مراسلة الدعم الفني عبر الواتساب</a>
      </form>
    </div>
  </div>

  <script>
    let curBook = '';
    function openPaymentModal(title) {
      curBook = title;
      document.getElementById('modalTitle').innerText = 'تفعيل ' + title + ' (10,000 د.ع)';
      document.getElementById('payModal').style.display = 'flex';
    }
    async function sendOrder(e) {
      e.preventDefault();
      const student_name = document.getElementById('stuName').value;
      const phone = document.getElementById('stuPhone').value;
      const transaction_ref = document.getElementById('stuTrans').value;

      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ student_name, phone, book_title: curBook, payment_method: 'زين كاش', transaction_ref })
      });
      const data = await res.json();
      alert('✅ ' + data.message);
      window.open('https://wa.me/\${PAYMENT_INFO.supportPhone}?text=' + encodeURIComponent('مرحباً، حولت 10,000 د.ع لمادة (' + curBook + ') رقم الوصل: ' + transaction_ref), '_blank');
      document.getElementById('payModal').style.display = 'none';
    }
  </script>
</body>
</html>\`;

  res.send(html);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log('🚀 خادم طلبتي يعمل على المنفذ ' + PORT));`;

  // 2. Supabase SQL with activation codes
  const supabaseSqlCode = `-- ==========================================
-- 1. جدول الملازم والكتب (books)
-- ==========================================
CREATE TABLE IF NOT EXISTS books (
  id BIGSERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  desc TEXT NOT NULL,
  price TEXT DEFAULT '10,000 د.ع',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ==========================================
-- 2. جدول أكواد التفعيل للطلاب (activation_codes)
-- ==========================================
CREATE TABLE IF NOT EXISTS activation_codes (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,
  book_id TEXT NOT NULL,
  book_title TEXT NOT NULL,
  student_name TEXT,
  student_phone TEXT DEFAULT '07734378998',
  is_used BOOLEAN DEFAULT FALSE,
  used_by TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ==========================================
-- 3. جدول طلبات الشراء والحوالات (orders)
-- ==========================================
CREATE TABLE IF NOT EXISTS orders (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  student_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  governorate TEXT DEFAULT 'العراق',
  book_title TEXT NOT NULL,
  payment_method TEXT NOT NULL,
  transaction_ref TEXT NOT NULL,
  price TEXT DEFAULT '10,000 د.ع',
  status TEXT DEFAULT 'قيد التحقق',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ==========================================
-- 4. تفعيل سياسات الأمان (Row Level Security)
-- ==========================================
ALTER TABLE books ENABLE ROW LEVEL SECURITY;
ALTER TABLE activation_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "قراءة الكتب متاحة للجميع" ON books FOR SELECT USING (true);
CREATE POLICY "التحقق من أكواد التفعيل" ON activation_codes FOR ALL USING (true);
CREATE POLICY "إرسال وتحديث الطلبات" ON orders FOR ALL USING (true);`;

  // 3. vercel.json
  const vercelJsonCode = `{
  "version": 2,
  "builds": [
    {
      "src": "server.js",
      "use": "@vercel/node"
    }
  ],
  "routes": [
    {
      "src": "/(.*)",
      "dest": "/server.js"
    }
  ]
}`;

  // 4. package.json for backend
  const backendPackageJson = `{
  "name": "talabe-backend",
  "version": "1.0.0",
  "main": "server.js",
  "scripts": {
    "start": "node server.js"
  },
  "dependencies": {
    "@supabase/supabase-js": "^2.49.0",
    "cors": "^2.8.5",
    "express": "^4.21.2"
  }
}`;

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    showToast(`تم نسخ ${label} بنجاح! 📋`, 'success');
    setTimeout(() => setCopied(null), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 rounded-3xl shadow-2xl border border-slate-800 overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200 text-slate-100 font-['Tajawal',sans-serif]">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-slate-950 via-indigo-950 to-slate-950 text-white flex items-center justify-between flex-shrink-0 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-blue-600/30">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black bg-emerald-500/20 text-emerald-300 px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                  جاهز للنسخ الفوري 🚀
                </span>
                <span className="text-xs text-slate-400">Vercel • GitHub • Supabase • Render • الهاتف</span>
              </div>
              <h2 className="text-sm sm:text-base font-black text-white">
                مركز النشر والربط السحابي وتثبيت التطبيق على الهاتف
              </h2>
            </div>
          </div>

          <button
            onClick={closeModal}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="p-3 border-b border-slate-800 bg-slate-950/60 flex items-center gap-2 flex-wrap flex-shrink-0">
          <button
            onClick={() => setActiveTab('github-server')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'github-server'
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 border border-slate-700/50'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>كود GitHub (server.js)</span>
          </button>

          <button
            onClick={() => setActiveTab('vercel')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'vercel'
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 border border-slate-700/50'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>نشر Vercel (vercel.json)</span>
          </button>

          <button
            onClick={() => setActiveTab('supabase')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'supabase'
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 border border-slate-700/50'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>جداول Supabase (SQL)</span>
          </button>

          <button
            onClick={() => setActiveTab('mongodb-neon')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'mongodb-neon'
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 border border-slate-700/50'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>MongoDB Atlas & Neon</span>
          </button>

          <button
            onClick={() => setActiveTab('mobile-install')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'mobile-install'
                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                : 'bg-slate-800/80 text-emerald-400 hover:text-emerald-300 border border-emerald-500/30'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>تثبيت الهاتف ونشر كوكل 📲</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-4">
          {/* TAB 1: GITHUB (talabe-backend/server.js) */}
          {activeTab === 'github-server' && (
            <div className="space-y-4">
              <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h4 className="text-sm font-bold text-white mb-1">
                    ملف <code className="text-amber-400 font-mono">server.js</code> في مستودع GitHub الخاص بك (talabe-backend):
                  </h4>
                  <p className="text-xs text-slate-400">
                    انسخ هذا الكود بالكامل، وافتحه في تبويب GitHub والصقه في ملف <code>server.js</code> واضغط Commit Changes.
                  </p>
                </div>
                <button
                  onClick={() => copyToClipboard(standaloneServerCode, 'كود server.js')}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl flex items-center gap-2 flex-shrink-0 cursor-pointer shadow-md shadow-blue-600/30"
                >
                  {copied === 'كود server.js' ? <Check className="w-4 h-4 text-white" /> : <Copy className="w-4 h-4" />}
                  <span>نسخ الكود بالكامل 📋</span>
                </button>
              </div>

              <pre className="p-4 rounded-2xl bg-slate-950 text-emerald-400 text-xs font-mono overflow-x-auto border border-slate-800 max-h-96 leading-relaxed select-all" dir="ltr">
                {standaloneServerCode}
              </pre>

              {/* package.json helper */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-300">
                    ملف <code className="text-blue-400 font-mono">package.json</code> الخاص بالسيرفر:
                  </span>
                  <button
                    onClick={() => copyToClipboard(backendPackageJson, 'ملف package.json')}
                    className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-bold rounded-lg flex items-center gap-1 cursor-pointer"
                  >
                    {copied === 'ملف package.json' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>نسخ package.json</span>
                  </button>
                </div>
                <pre className="p-3 rounded-xl bg-slate-900 text-cyan-300 text-xs font-mono overflow-x-auto" dir="ltr">
                  {backendPackageJson}
                </pre>
              </div>
            </div>
          )}

          {/* TAB 2: VERCEL */}
          {activeTab === 'vercel' && (
            <div className="space-y-4">
              <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h4 className="text-sm font-bold text-white mb-1">
                    ملف الإعدادات <code className="text-amber-400 font-mono">vercel.json</code>:
                  </h4>
                  <p className="text-xs text-slate-400">
                    ضعه في المجلد الرئيسي لمستودعك على GitHub ليقوم Vercel بتشغيل السيرفر بدون أخطاء.
                  </p>
                </div>
                <button
                  onClick={() => copyToClipboard(vercelJsonCode, 'ملف vercel.json')}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl flex items-center gap-2 flex-shrink-0 cursor-pointer shadow-md shadow-blue-600/30"
                >
                  {copied === 'ملف vercel.json' ? <Check className="w-4 h-4 text-white" /> : <Copy className="w-4 h-4" />}
                  <span>نسخ vercel.json 📋</span>
                </button>
              </div>

              <pre className="p-4 rounded-2xl bg-slate-950 text-amber-400 text-xs font-mono overflow-x-auto border border-slate-800 leading-relaxed" dir="ltr">
                {vercelJsonCode}
              </pre>

              {/* Vercel Steps */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 space-y-2 text-xs text-slate-300">
                <h5 className="font-bold text-white text-sm mb-2">خطوات النشر على Vercel:</h5>
                <ol className="list-decimal list-inside space-y-1.5 text-slate-400">
                  <li>افتح تبويب <b>Vercel</b> المفتوح في متصفحك.</li>
                  <li>اضغط على <b>Add New Project</b> ثم اختر مستودع <b>talabe-backend</b> من GitHub.</li>
                  <li>اترك Build Command فارغاً واضغط <b>Deploy</b>.</li>
                  <li>سيعطيك Vercel رابطاً رسمياً مثل <code>https://talabe-backend.vercel.app</code> يعمل 24/7 بسرعة فائقة.</li>
                </ol>
              </div>
            </div>
          )}

          {/* TAB 3: SUPABASE SQL */}
          {activeTab === 'supabase' && (
            <div className="space-y-4">
              <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h4 className="text-sm font-bold text-white mb-1">
                    أمر SQL لإنشاء جداول الملازم وأكواد التفعيل في Supabase:
                  </h4>
                  <p className="text-xs text-slate-400">
                    افتح تبويب <b>Supabase SQL Editor</b> في متصفحك، الصق هذا الكود واضغط <b>Run</b>.
                  </p>
                </div>
                <button
                  onClick={() => copyToClipboard(supabaseSqlCode, 'أوامر Supabase SQL')}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl flex items-center gap-2 flex-shrink-0 cursor-pointer shadow-md shadow-blue-600/30"
                >
                  {copied === 'أوامر Supabase SQL' ? <Check className="w-4 h-4 text-white" /> : <Copy className="w-4 h-4" />}
                  <span>نسخ أوامر SQL 📋</span>
                </button>
              </div>

              <pre className="p-4 rounded-2xl bg-slate-950 text-cyan-400 text-xs font-mono overflow-x-auto border border-slate-800 max-h-80 leading-relaxed" dir="ltr">
                {supabaseSqlCode}
              </pre>
            </div>
          )}

          {/* TAB 4: MONGODB & NEON */}
          {activeTab === 'mongodb-neon' && (
            <div className="space-y-4 text-xs">
              <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 space-y-3">
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                  <Database className="w-4 h-4" />
                  <span>MongoDB Atlas (تبويب goDB Cloud في صورتك)</span>
                </div>
                <p className="text-slate-400">
                  لربط قاعدة بيانات MongoDB، اضغط في Atlas على <b>Connect &gt; Drivers</b> وانسخ رابط <code>MONGODB_URI</code>، وضعه في متغيرات البيئة في Vercel أو Render.
                </p>
              </div>

              <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 space-y-3">
                <div className="flex items-center gap-2 text-cyan-400 font-bold text-sm">
                  <Flame className="w-4 h-4" />
                  <span>Neon Console (تبويب on Console في صورتك)</span>
                </div>
                <p className="text-slate-400">
                  Neon يوفر قاعدة بيانات PostgreSQL سحابية مجانية فائقة السرعة. انسخ Connection String (DATABASE_URL) وضعه في إعدادات التطبيق.
                </p>
              </div>
            </div>
          )}

          {/* TAB 5: MOBILE INSTALL & GOOGLE */}
          {activeTab === 'mobile-install' && (
            <div className="space-y-4 text-xs">
              <div className="bg-gradient-to-r from-emerald-950/60 to-slate-900 border border-emerald-500/30 rounded-2xl p-5 space-y-3">
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-base">
                  <Smartphone className="w-5 h-5" />
                  <span>طريقة تثبيت التطبيق كـ تطبيق حقيقي على هاتف أندرويد وآيفون:</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div className="bg-slate-950/80 border border-slate-800 p-3.5 rounded-xl space-y-1.5">
                    <span className="font-bold text-white block">📱 على هواتف الأندرويد (Google Chrome):</span>
                    <p className="text-slate-400 text-[11px]">
                      1. افتح رابط التطبيق في متصفح Chrome.<br />
                      2. اضغط على زر الخيارات (الثلاث نقاط في الأعلى).<br />
                      3. اختر <b>"إضافة إلى الشاشة الرئيسية" (Install App / Add to Home Screen)</b>.<br />
                      4. سيظهر تطبيق "منصة طلبتي" بأيقونته على شاشة هاتفك مثل تطبيقات Play Store ويعمل أوفلاين.
                    </p>
                  </div>

                  <div className="bg-slate-950/80 border border-slate-800 p-3.5 rounded-xl space-y-1.5">
                    <span className="font-bold text-white block">🍎 على هواتف الآيفون (Safari):</span>
                    <p className="text-slate-400 text-[11px]">
                      1. افتح رابط التطبيق في متصفح Safari.<br />
                      2. اضغط على زر المشاركة (Share) في الأسفل.<br />
                      3. اختر <b>"إضافة إلى الصفحة الرئيسية" (Add to Home Screen)</b>.<br />
                      4. سيتم تثبيت التطبيق بملء الشاشة.
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 space-y-2">
                <span className="font-bold text-blue-400 text-sm block">🔍 أرشفة وظهور التطبيق على متصفحات وبحث كوكل:</span>
                <p className="text-slate-400 leading-relaxed">
                  تم تضمين كافة وسوم الـ SEO و Schema.org و OpenGraph المعتمدة لظهور منصة طلبتي في نتائج البحث الأولى لكلمات: (ملازم الثالث متوسط 2026، مرشحات الامتحانات الوزارية، منصة طلبتي، تحميل كتب الثالث متوسط العراق).
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
