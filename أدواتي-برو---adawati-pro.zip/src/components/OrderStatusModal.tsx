import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Search,
  CheckCircle2,
  Clock,
  AlertCircle,
  Smartphone,
  CreditCard,
  Send,
  Sparkles,
  BookOpen
} from 'lucide-react';

export const OrderStatusModal: React.FC = () => {
  const { activeModal, closeModal, orders, paymentInfo, setActiveReadingBook, books } = useApp();
  const [query, setQuery] = useState('');

  if (activeModal !== 'order-status') return null;

  const filteredOrders = query.trim()
    ? orders.filter(
        (o) =>
          o.phone.includes(query.trim()) ||
          o.transaction_ref.toLowerCase().includes(query.trim().toLowerCase()) ||
          o.student_name.includes(query.trim()) ||
          o.id.toLowerCase().includes(query.trim().toLowerCase())
      )
    : orders;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-8 animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-600 flex items-center justify-center text-white shadow-md">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black">
                تتبع حالة الطلب والحوالة
              </h2>
              <p className="text-xs text-slate-300">
                الاستعلام الفوري عن حالة تفعيل الملازم والكتب
              </p>
            </div>
          </div>

          <button
            onClick={closeModal}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search input */}
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3.5" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="ابحث برقم الهاتف، أو رقم الحوالة، أو اسم الطالب..."
              className="w-full pl-3 pr-10 py-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Orders list */}
        <div className="p-6 max-h-[60vh] overflow-y-auto space-y-4">
          {filteredOrders.length > 0 ? (
            filteredOrders.map((order) => {
              const matchedBook = books.find((b) => b.id === order.book_id || b.title === order.book_title);

              return (
                <div
                  key={order.id}
                  className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 space-y-4"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[10px] font-mono font-bold bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 px-2 py-0.5 rounded-md">
                          {order.id}
                        </span>
                        <span className="text-[10px] text-slate-400">{order.created_at}</span>
                      </div>
                      <h4 className="text-sm font-black text-slate-900 dark:text-white">
                        {order.book_title}
                      </h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                        الطالب: {order.student_name} ({order.phone})
                      </p>
                    </div>

                    {/* Status Badge */}
                    <div className="flex flex-col items-end">
                      <span
                        className={`text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1.5 ${
                          order.status === 'تم التفعيل والفتح'
                            ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30'
                            : order.status === 'قيد التحقق'
                            ? 'bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/30'
                            : 'bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-500/30'
                        }`}
                      >
                        {order.status === 'تم التفعيل والفتح' ? (
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        ) : order.status === 'قيد التحقق' ? (
                          <Clock className="w-3.5 h-3.5" />
                        ) : (
                          <AlertCircle className="w-3.5 h-3.5" />
                        )}
                        <span>{order.status}</span>
                      </span>
                    </div>
                  </div>

                  {/* Order payment details snippet */}
                  <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 text-xs grid grid-cols-2 gap-2 text-slate-600 dark:text-slate-300">
                    <div>
                      <span className="text-slate-400 block text-[10px]">طريقة الدفع:</span>
                      <span className="font-bold">{order.payment_method}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">رقم الحوالة/الوصل:</span>
                      <span className="font-mono font-bold">{order.transaction_ref}</span>
                    </div>
                  </div>

                  {/* Action on order */}
                  {order.status === 'تم التفعيل والفتح' && matchedBook && (
                    <button
                      onClick={() => {
                        closeModal();
                        setActiveReadingBook(matchedBook);
                      }}
                      className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/30 cursor-pointer"
                    >
                      <BookOpen className="w-4 h-4" />
                      <span>فتح وقراءة الملزمة الآن</span>
                    </button>
                  )}

                  {order.status === 'قيد التحقق' && (
                    <div className="flex items-center justify-between text-xs pt-1">
                      <span className="text-slate-500 text-[11px]">
                        جاري مراجعة إشعار التحويل من قبل المشرف
                      </span>
                      <button
                        onClick={() => {
                          const msg = `مرحباً، أود الاستفسار عن طلبي رقم ${order.id} لملزمة ${order.book_title}. رقم الحوالة: ${order.transaction_ref}`;
                          window.open(
                            `https://wa.me/${paymentInfo.supportPhone}?text=${encodeURIComponent(msg)}`,
                            '_blank'
                          );
                        }}
                        className="text-emerald-600 dark:text-emerald-400 font-bold hover:underline flex items-center gap-1 text-xs"
                      >
                        <Send className="w-3 h-3" />
                        <span>تسريع عبر الواتساب</span>
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          ) : (
            <div className="text-center py-10 text-slate-400">
              لا توجد طلبات مطابقة لبحثك
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
