import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Mail, Lock, Eye, EyeOff, BookOpen, GraduationCap, ArrowRight, Sparkles, CheckCircle2 } from 'lucide-react';

export const MobileLoginScreen: React.FC = () => {
  const { loginUser, showToast } = useApp();
  const [email, setEmail] = useState('ahmed.student@talabati.iq');
  const [password, setPassword] = useState('••••••••');
  const [showPassword, setShowPassword] = useState(false);
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [studentName, setStudentName] = useState('أحمد محمد');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      showToast('يرجى إدخال البريد الإلكتروني أو اسم المستخدم', 'error');
      return;
    }
    loginUser(email, isRegisterMode ? studentName : 'أحمد محمد');
  };

  const handleGoogleLogin = () => {
    loginUser('ahmed.google@talabati.iq', 'أحمد محمد');
  };

  return (
    <div className="min-h-full flex flex-col justify-between p-6 bg-slate-950 text-slate-100 font-['Tajawal','Cairo',sans-serif]">
      {/* Top Branding matching the image */}
      <div className="space-y-4 text-center pt-2">
        <div className="inline-flex flex-col items-center gap-2">
          <div className="relative">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-400 flex items-center justify-center text-white shadow-xl shadow-blue-500/30 border border-blue-400/30">
              <BookOpen className="w-9 h-9" />
            </div>
            <div className="absolute -bottom-1 -right-1 p-1 bg-amber-400 text-slate-950 rounded-full shadow">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
          </div>

          <div>
            <h1 className="text-2xl font-black text-white tracking-tight">منصة طلبتي</h1>
            <p className="text-xs font-bold text-slate-400 mt-0.5">جميع الكتب الدراسية في مكان واحد</p>
          </div>
        </div>

        {/* Vector Art illustration of stacked books */}
        <div className="py-2 flex justify-center">
          <div className="relative w-44 h-32 flex items-center justify-center">
            {/* Glowing background */}
            <div className="absolute inset-0 bg-blue-500/15 blur-2xl rounded-full"></div>
            
            {/* SVG Book Stack Illustration */}
            <svg viewBox="0 0 200 140" className="w-full h-full drop-shadow-2xl">
              {/* Table / Base glow */}
              <ellipse cx="100" cy="120" rx="75" ry="10" fill="#1e293b" opacity="0.8" />
              
              {/* Bottom Book (Cyan/Blue) */}
              <g transform="translate(45, 90)">
                <path d="M0,0 L110,0 C110,0 108,16 95,16 L15,16 C2,16 0,0 0,0 Z" fill="#0284c7" />
                <path d="M0,0 L110,0 L110,4 L0,4 Z" fill="#38bdf8" />
                <rect x="15" y="4" width="80" height="8" rx="2" fill="#0c4a6e" />
              </g>

              {/* Middle Book (Indigo) */}
              <g transform="translate(50, 72)">
                <path d="M0,0 L100,0 C100,0 98,16 88,16 L12,16 C2,16 0,0 0,0 Z" fill="#4f46e5" />
                <path d="M0,0 L100,0 L100,4 L0,4 Z" fill="#818cf8" />
                <rect x="12" y="4" width="76" height="8" rx="2" fill="#312e81" />
              </g>

              {/* Top Book (Royal Blue) */}
              <g transform="translate(56, 54)">
                <path d="M0,0 L88,0 C88,0 86,16 78,16 L10,16 C2,16 0,0 0,0 Z" fill="#2563eb" />
                <path d="M0,0 L88,0 L88,4 L0,4 Z" fill="#60a5fa" />
                <rect x="10" y="4" width="68" height="8" rx="2" fill="#1e3a8a" />
              </g>

              {/* Graduation Cap on top */}
              <g transform="translate(80, 26)">
                <path d="M20,0 L40,8 L20,16 L0,8 Z" fill="#1e293b" stroke="#38bdf8" strokeWidth="1.5" />
                <rect x="12" y="10" width="16" height="6" rx="2" fill="#0f172a" />
                <path d="M38,8 L44,18 L46,18" stroke="#fbbf24" strokeWidth="1.5" fill="none" />
                <circle cx="46" cy="19" r="2" fill="#fbbf24" />
              </g>

              {/* Pencil Holder Cup */}
              <g transform="translate(142, 60)">
                <rect x="0" y="16" width="22" height="34" rx="4" fill="#334155" stroke="#475569" strokeWidth="1.5" />
                {/* Pencils & Ruler */}
                <line x1="6" y1="2" x2="6" y2="20" stroke="#f59e0b" strokeWidth="3" strokeLinecap="round" />
                <line x1="12" y1="-4" x2="12" y2="20" stroke="#10b981" strokeWidth="3" strokeLinecap="round" />
                <line x1="17" y1="6" x2="17" y2="20" stroke="#ec4899" strokeWidth="3" strokeLinecap="round" />
              </g>
            </svg>
          </div>
        </div>

        <div>
          <h2 className="text-lg font-black text-white">
            {isRegisterMode ? 'إنشاء حساب طالب جديد' : 'مرحبا بك'}
          </h2>
          <p className="text-xs text-slate-400">
            {isRegisterMode ? 'انضم إلى آلاف الطلاب وتابع دراستك' : 'سجل الدخول إلى مكتبتك'}
          </p>
        </div>
      </div>

      {/* Form Fields matching the design */}
      <form onSubmit={handleSubmit} className="space-y-3.5 my-auto py-2">
        {isRegisterMode && (
          <div className="space-y-1 text-right">
            <label className="text-[11px] font-bold text-slate-300 block">الاسم الكامل</label>
            <div className="relative">
              <input
                type="text"
                value={studentName}
                onChange={(e) => setStudentName(e.target.value)}
                placeholder="اسم الطالب الثلاثي"
                className="w-full bg-slate-900/90 text-white text-xs rounded-xl px-3.5 py-3 pr-10 border border-slate-800 focus:border-blue-500 focus:outline-none transition-all placeholder:text-slate-500 text-right"
              />
              <div className="absolute right-3 top-3 text-slate-400">
                <GraduationCap className="w-4 h-4" />
              </div>
            </div>
          </div>
        )}

        {/* Email or username input */}
        <div className="space-y-1 text-right">
          <label className="text-[11px] font-bold text-slate-300 block">البريد الإلكتروني أو اسم المستخدم</label>
          <div className="relative">
            <input
              type="text"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@example.com"
              className="w-full bg-slate-900/90 text-white text-xs rounded-xl px-3.5 py-3 pr-10 border border-slate-800 focus:border-blue-500 focus:outline-none transition-all placeholder:text-slate-500 text-right"
            />
            <div className="absolute right-3 top-3 text-slate-400">
              <Mail className="w-4 h-4" />
            </div>
          </div>
        </div>

        {/* Password input */}
        <div className="space-y-1 text-right">
          <div className="flex justify-between items-center">
            <button
              type="button"
              onClick={() => showToast('يمكنك تسجيل الدخول المباشر أو عبر حساب جوجل', 'info')}
              className="text-[10px] text-blue-400 hover:text-blue-300 transition-colors"
            >
              نسيت كلمة المرور؟
            </button>
            <label className="text-[11px] font-bold text-slate-300 block">كلمة المرور</label>
          </div>
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full bg-slate-900/90 text-white text-xs rounded-xl px-3.5 py-3 pr-10 pl-10 border border-slate-800 focus:border-blue-500 focus:outline-none transition-all placeholder:text-slate-500 text-right"
            />
            <div className="absolute right-3 top-3 text-slate-400">
              <Lock className="w-4 h-4" />
            </div>
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute left-3 top-3 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Primary Submit Button */}
        <button
          type="submit"
          className="w-full py-3.5 px-4 bg-gradient-to-r from-blue-600 via-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-black rounded-xl shadow-lg shadow-blue-600/30 transition-all transform active:scale-98 cursor-pointer flex items-center justify-center gap-2 mt-2"
        >
          <span>{isRegisterMode ? 'إنشاء الحساب والدخول' : 'تسجيل الدخول'}</span>
          <ArrowRight className="w-4 h-4 rotate-180" />
        </button>

        {/* Divider */}
        <div className="relative flex py-1 items-center">
          <div className="flex-grow border-t border-slate-800"></div>
          <span className="flex-shrink mx-3 text-[11px] text-slate-500 font-bold">أو</span>
          <div className="flex-grow border-t border-slate-800"></div>
        </div>

        {/* Google Sign in button */}
        <button
          type="button"
          onClick={handleGoogleLogin}
          className="w-full py-3 px-4 bg-slate-900 hover:bg-slate-800/90 text-white text-xs font-bold rounded-xl border border-slate-800 hover:border-slate-700 shadow-sm transition-all flex items-center justify-center gap-2.5 cursor-pointer"
        >
          {/* Google multi-color SVG icon */}
          <svg className="w-4 h-4" viewBox="0 0 24 24">
            <path
              fill="#EA4335"
              d="M12 5c1.6 0 3 .6 4.1 1.6l3.1-3.1C17.3 1.7 14.8 1 12 1 7.4 1 3.5 3.6 1.6 7.4l3.7 2.9C6.2 7.4 8.9 5 12 5z"
            />
            <path
              fill="#4285F4"
              d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5 3.7-8.8z"
            />
            <path
              fill="#FBBC05"
              d="M5.3 14.7c-.2-.7-.4-1.5-.4-2.4s.2-1.7.4-2.4L1.6 7c-.8 1.6-1.3 3.4-1.3 5.3s.5 3.7 1.3 5.3l3.7-2.9z"
            />
            <path
              fill="#34A853"
              d="M12 23c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3.1 0-5.8-2.4-6.7-5.3L1.6 16c1.9 3.8 5.8 7 10.4 7z"
            />
          </svg>
          <span>الدخول بحساب Google</span>
        </button>
      </form>

      {/* Footer link to switch mode */}
      <div className="text-center pt-2 border-t border-slate-900/80">
        <button
          type="button"
          onClick={() => setIsRegisterMode(!isRegisterMode)}
          className="text-xs text-slate-400 hover:text-white transition-colors cursor-pointer"
        >
          {isRegisterMode ? (
            <span>لديك حساب بالفعل؟ <strong className="text-blue-400 underline font-bold">تسجيل الدخول</strong></span>
          ) : (
            <span>ليس لديك حساب؟ <strong className="text-blue-400 underline font-bold">إنشاء حساب جديد</strong></span>
          )}
        </button>
      </div>
    </div>
  );
};
