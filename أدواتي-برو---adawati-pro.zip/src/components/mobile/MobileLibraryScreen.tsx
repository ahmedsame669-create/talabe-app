import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BookItem, SubjectCategory, EducationalStage } from '../../types';
import {
  Search,
  Filter,
  Star,
  Download,
  CheckCircle2,
  BookOpen,
  SlidersHorizontal,
  ChevronLeft,
  GraduationCap
} from 'lucide-react';

export const MobileLibraryScreen: React.FC = () => {
  const {
    books,
    selectedCategory,
    setSelectedCategory,
    selectedGrade,
    setSelectedGrade,
    selectedYear,
    setSelectedYear,
    searchQuery,
    setSearchQuery,
    setActiveMobileScreen,
    setActiveBookDetails,
    downloadBook,
    downloadedBookIds,
    downloadProgress
  } = useApp();

  const [activeFilterTab, setActiveFilterTab] = useState<'all' | 'stage' | 'subject' | 'year'>('all');

  const FILTER_PILLS = [
    { id: 'all', label: 'الكل' },
    { id: 'الثالث متوسط', label: 'الثالث متوسط' },
    { id: 'الرياضيات', label: 'الرياضيات' },
    { id: '2026', label: '2026' }
  ];

  const handlePillClick = (id: string) => {
    if (id === 'all') {
      setSelectedCategory('all');
      setSelectedGrade('all');
      setSelectedYear('الكل');
    } else if (id === 'الثالث متوسط') {
      setSelectedGrade('الثالث متوسط');
    } else if (id === 'الرياضيات') {
      setSelectedCategory('الرياضيات');
    } else if (id === '2026') {
      setSelectedYear('2026');
    }
  };

  const handleSelectBook = (book: BookItem) => {
    setActiveBookDetails(book);
    setActiveMobileScreen('details');
  };

  // Filter books matching search, stage, category, and year
  const filteredBooks = books.filter((book) => {
    const matchesCategory =
      selectedCategory === 'all' ||
      book.category === selectedCategory ||
      (selectedCategory === 'الرياضيات' && book.category === 'الرياضيات');

    const matchesGrade =
      selectedGrade === 'all' ||
      book.grade === selectedGrade ||
      (selectedGrade === 'الثالث متوسط' && book.grade === 'الثالث متوسط');

    const matchesYear =
      selectedYear === 'الكل' || book.yearEdition.includes(selectedYear);

    const matchesSearch =
      !searchQuery.trim() ||
      book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.desc.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.category.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesCategory && matchesGrade && matchesYear && matchesSearch;
  });

  return (
    <div className="min-h-full flex flex-col pb-20 bg-slate-950 text-slate-100 font-['Tajawal','Cairo',sans-serif] overflow-y-auto">
      {/* Top Bar matching Screen 3 */}
      <div className="sticky top-0 z-20 bg-slate-950/95 backdrop-blur-md px-4 py-3 border-b border-slate-800/80 flex items-center justify-between">
        <button
          onClick={() => {
            setSelectedCategory('all');
            setSelectedGrade('all');
            setSelectedYear('الكل');
          }}
          className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          title="تصفية"
        >
          <Filter className="w-5 h-5" />
        </button>

        <h1 className="text-base font-black text-white tracking-wide">المكتبة</h1>

        <div className="w-9"></div>
      </div>

      <div className="p-4 space-y-4">
        {/* Search Input matching the image */}
        <div className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث عن كتاب..."
            className="w-full bg-slate-900 text-white text-xs rounded-2xl py-3 pr-11 pl-4 border border-slate-800 focus:border-blue-500 focus:outline-none transition-all placeholder:text-slate-500 text-right shadow-inner"
          />
          <div className="absolute right-3.5 top-3.5 text-slate-400">
            <Search className="w-4 h-4" />
          </div>
        </div>

        {/* Filter Pills row matching: [الكل, الثالث متوسط, الرياضيات, 2026] */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {FILTER_PILLS.map((pill) => {
            const isSelected =
              (pill.id === 'all' && selectedCategory === 'all' && selectedGrade === 'all' && selectedYear === 'الكل') ||
              (pill.id === 'الثالث متوسط' && selectedGrade === 'الثالث متوسط') ||
              (pill.id === 'الرياضيات' && selectedCategory === 'الرياضيات') ||
              (pill.id === '2026' && selectedYear === '2026');

            return (
              <button
                key={pill.id}
                onClick={() => handlePillClick(pill.id)}
                className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer whitespace-nowrap ${
                  isSelected
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30 border border-blue-400'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {pill.label}
              </button>
            );
          })}
        </div>

        {/* Books List matching the screen 3 format */}
        <div className="space-y-3 pt-1">
          {filteredBooks.map((book) => {
            const isDownloaded = downloadedBookIds.includes(book.id);
            const progress = downloadProgress[book.id];

            return (
              <div
                key={book.id}
                onClick={() => handleSelectBook(book)}
                className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 transition-all flex items-center justify-between gap-3 cursor-pointer group shadow-sm"
              >
                {/* Left: Download Action */}
                <div className="flex items-center gap-2 flex-shrink-0" onClick={(e) => e.stopPropagation()}>
                  <button
                    onClick={() => downloadBook(book)}
                    className={`w-10 h-10 rounded-xl flex items-center justify-center transition-transform active:scale-90 cursor-pointer ${
                      isDownloaded
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : 'bg-blue-600 hover:bg-blue-500 text-white shadow-md shadow-blue-600/30'
                    }`}
                    title={isDownloaded ? 'تم التحميل' : 'تحميل الكتاب بصيغة PDF'}
                  >
                    {progress !== undefined ? (
                      <span className="text-[10px] font-black">{progress}%</span>
                    ) : isDownloaded ? (
                      <CheckCircle2 className="w-5 h-5" />
                    ) : (
                      <Download className="w-5 h-5" />
                    )}
                  </button>
                </div>

                {/* Center: Book Info */}
                <div className="flex-1 text-right min-w-0">
                  <h3 className="text-sm font-black text-white group-hover:text-blue-400 transition-colors">
                    {book.title}
                  </h3>
                  <span className="text-[11px] font-bold text-slate-400 block mt-0.5">
                    {book.grade}
                  </span>

                  <div className="flex items-center justify-end gap-3 mt-1.5 text-[11px]">
                    <span className="text-slate-400 font-mono">{book.downloadsCount ? `${(book.downloadsCount / 1000).toFixed(1)}k` : '14.6k'} 📥</span>
                    <span className="text-slate-600">•</span>
                    <span className="font-mono text-slate-300">{book.fileSize}</span>
                    <span className="text-slate-600">•</span>
                    <span className="font-mono text-slate-300">{book.yearEdition}</span>
                    <span className="text-slate-600">•</span>
                    <div className="flex items-center gap-1 text-amber-400 font-bold">
                      <span>{book.rating}</span>
                      <Star className="w-3.5 h-3.5 fill-amber-400" />
                    </div>
                  </div>
                </div>

                {/* Right: Book Cover 3D Card Thumbnail */}
                <div className="relative w-14 h-18 rounded-xl overflow-hidden flex-shrink-0 shadow-lg border border-slate-700/60 bg-gradient-to-br from-blue-800 via-indigo-900 to-slate-950 flex flex-col justify-between p-2 text-center group-hover:scale-105 transition-transform">
                  <span className="text-[8px] font-black text-cyan-300 leading-tight line-clamp-1">{book.category}</span>
                  <div className="w-full h-1 bg-cyan-400/40 rounded-full my-auto"></div>
                  <span className="text-[8px] font-black text-white">{book.yearEdition}</span>
                </div>
              </div>
            );
          })}

          {filteredBooks.length === 0 && (
            <div className="text-center py-12 px-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
              <BookOpen className="w-10 h-10 text-slate-500 mx-auto" />
              <h3 className="text-sm font-black text-white">لا توجد كتب مطابقة لبحثك</h3>
              <p className="text-xs text-slate-400">جرب اختيار تصنيف آخر أو مسح البحث</p>
              <button
                onClick={() => {
                  setSelectedCategory('all');
                  setSelectedGrade('all');
                  setSelectedYear('الكل');
                  setSearchQuery('');
                }}
                className="px-4 py-2 bg-blue-600 text-white text-xs font-bold rounded-xl"
              >
                إعادة ضبط الفلاتر
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
