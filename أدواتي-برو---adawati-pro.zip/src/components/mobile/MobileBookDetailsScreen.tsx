import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  ChevronRight,
  Share2,
  Heart,
  Download,
  BookOpen,
  Star,
  CheckCircle2,
  FileText,
  Calendar,
  Layers,
  HardDrive,
  Award,
  Sparkles,
  HelpCircle,
  Edit3
} from 'lucide-react';

export const MobileBookDetailsScreen: React.FC = () => {
  const {
    activeBookDetails,
    setActiveMobileScreen,
    favoriteBookIds,
    toggleFavorite,
    downloadBook,
    downloadedBookIds,
    downloadProgress,
    setActiveReadingBook,
    openQuizModalForBook,
    openModal,
    showToast,
    isSupervisor,
    openBookEditorForBook
  } = useApp();

  const book = activeBookDetails;

  if (!book) {
    return (
      <div className="min-h-full flex flex-col items-center justify-center p-6 bg-slate-950 text-white">
        <p className="text-xs text-slate-400">لم يتم اختيار أي كتاب</p>
        <button
          onClick={() => setActiveMobileScreen('library')}
          className="mt-3 px-4 py-2 bg-blue-600 rounded-xl text-xs font-bold"
        >
          العودة للمكتبة
        </button>
      </div>
    );
  }

  const isFav = favoriteBookIds.includes(book.id);
  const isDownloaded = downloadedBookIds.includes(book.id);
  const progress = downloadProgress[book.id];

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: book.title,
          text: `تحميل كتاب ${book.title} - طبعة ${book.yearEdition} من منصة طلبتي`,
          url: window.location.href
        });
      } catch {}
    } else {
      navigator.clipboard?.writeText(window.location.href);
      showToast('تم نسخ رابط الكتاب للمشاركة 🔗', 'success');
    }
  };

  const handleOpenReader = () => {
    setActiveReadingBook(book);
  };

  return (
    <div className="min-h-full flex flex-col pb-20 bg-slate-950 text-slate-100 font-['Tajawal','Cairo',sans-serif] overflow-y-auto">
      {/* Top Bar matching Screen 4 */}
      <div className="sticky top-0 z-20 bg-slate-950/95 backdrop-blur-md px-4 py-3 border-b border-slate-800/80 flex items-center justify-between">
        <button
          onClick={() => setActiveMobileScreen('library')}
          className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <ChevronRight className="w-5 h-5" />
        </button>

        <h1 className="text-base font-black text-white tracking-wide">تفاصيل الكتاب</h1>

        <button
          onClick={handleShare}
          className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <Share2 className="w-5 h-5" />
        </button>
      </div>

      <div className="p-5 space-y-6">
        {/* Large Central 3D Book Cover display matching the mockup */}
        <div className="flex justify-center pt-2">
          <div className="relative group">
            {/* Ambient Backlight Glow */}
            <div className="absolute -inset-4 bg-gradient-to-r from-blue-600/30 via-indigo-600/30 to-cyan-500/20 rounded-3xl blur-2xl opacity-80 group-hover:opacity-100 transition-opacity"></div>

            {/* 3D Book Cover Graphic */}
            <div className="relative w-48 h-64 rounded-2xl bg-gradient-to-b from-slate-900 via-blue-950 to-slate-900 border-2 border-blue-400/40 shadow-2xl p-4 flex flex-col justify-between items-center text-center overflow-hidden">
              {/* Top emblem */}
              <div className="w-full flex justify-between items-center">
                <span className="text-[9px] font-black text-blue-300 px-2 py-0.5 rounded-md bg-blue-900/60 border border-blue-500/30">
                  وزارة التربية
                </span>
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              </div>

              {/* Center Artwork */}
              <div className="my-auto space-y-2">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-500 to-cyan-400 p-0.5 shadow-lg mx-auto">
                  <div className="w-full h-full bg-slate-900 rounded-[14px] flex items-center justify-center">
                    <BookOpen className="w-8 h-8 text-cyan-300" />
                  </div>
                </div>
                <h3 className="text-sm font-black text-white leading-tight">
                  {book.category}
                </h3>
                <span className="text-[10px] text-cyan-200 font-bold block">
                  {book.grade}
                </span>
              </div>

              {/* Bottom tag */}
              <div className="w-full pt-2 border-t border-blue-500/30 flex justify-between items-center text-[9px] text-slate-300 font-mono font-bold">
                <span>PDF</span>
                <span>{book.yearEdition}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Title & Rating */}
        <div className="text-center space-y-2">
          <h2 className="text-xl font-black text-white tracking-tight">
            {book.title}
          </h2>

          <div className="flex items-center justify-center gap-2">
            <div className="flex items-center gap-1 text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber-400" />
              ))}
            </div>
            <span className="text-xs font-bold text-slate-300">({book.rating} تقييم)</span>
          </div>
        </div>

        {/* Specifications Meta List matching the image */}
        <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-4 space-y-3 shadow-inner">
          <div className="flex items-center justify-between text-xs py-1 border-b border-slate-800/80">
            <span className="font-bold text-slate-200 font-mono">{book.yearEdition}</span>
            <span className="text-slate-400 flex items-center gap-1.5 font-bold">
              <span>سنة النشر:</span>
              <Calendar className="w-3.5 h-3.5 text-blue-400" />
            </span>
          </div>

          <div className="flex items-center justify-between text-xs py-1 border-b border-slate-800/80">
            <span className="font-bold text-slate-200">{book.author || 'وزارة التربية'}</span>
            <span className="text-slate-400 flex items-center gap-1.5 font-bold">
              <span>المؤلف / الجهة:</span>
              <Award className="w-3.5 h-3.5 text-indigo-400" />
            </span>
          </div>

          <div className="flex items-center justify-between text-xs py-1 border-b border-slate-800/80">
            <span className="font-bold text-slate-200 font-mono">{book.pagesCount} صفحة</span>
            <span className="text-slate-400 flex items-center gap-1.5 font-bold">
              <span>عدد الصفحات:</span>
              <Layers className="w-3.5 h-3.5 text-cyan-400" />
            </span>
          </div>

          <div className="flex items-center justify-between text-xs py-1 border-b border-slate-800/80">
            <span className="font-bold text-slate-200 font-mono">{book.fileSize}</span>
            <span className="text-slate-400 flex items-center gap-1.5 font-bold">
              <span>الحجم:</span>
              <HardDrive className="w-3.5 h-3.5 text-emerald-400" />
            </span>
          </div>

          <div className="flex items-center justify-between text-xs py-1">
            <span className="font-bold text-blue-400 font-mono uppercase">{book.fileFormat || 'PDF'}</span>
            <span className="text-slate-400 flex items-center gap-1.5 font-bold">
              <span>الصيغة:</span>
              <FileText className="w-3.5 h-3.5 text-purple-400" />
            </span>
          </div>
        </div>

        {/* Primary Action Button: "تحميل الكتاب" */}
        <div className="space-y-3 pt-1">
          <button
            onClick={() => downloadBook(book)}
            className="w-full py-4 bg-gradient-to-r from-blue-600 via-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-sm font-black rounded-2xl shadow-xl shadow-blue-600/30 transition-all transform active:scale-98 cursor-pointer flex items-center justify-center gap-2.5"
          >
            {progress !== undefined ? (
              <div className="flex items-center gap-2">
                <span className="animate-spin">⏳</span>
                <span>جاري التحميل ({progress}%)...</span>
              </div>
            ) : isDownloaded ? (
              <>
                <CheckCircle2 className="w-5 h-5 text-emerald-300" />
                <span>تم التحميل • جاهز للقراءة أوفلاين</span>
              </>
            ) : (
              <>
                <Download className="w-5 h-5" />
                <span>تحميل الكتاب</span>
              </>
            )}
          </button>

          {/* Supervisor Edit Button */}
          {isSupervisor && (
            <button
              onClick={() => openBookEditorForBook(book)}
              className="w-full py-3 px-4 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-black flex items-center justify-center gap-2 cursor-pointer shadow-sm transition-all"
            >
              <Edit3 className="w-4 h-4 text-amber-400" />
              <span>تعديل المادة وإرفاق PDF (صلاحيات المشرف) 👑</span>
            </button>
          )}

          {/* Secondary Actions: Favorite & Share & Reader & Quiz */}
          <div className="grid grid-cols-2 gap-2.5">
            <button
              onClick={() => toggleFavorite(book.id)}
              className={`py-3 px-4 rounded-xl text-xs font-bold border transition-all flex items-center justify-center gap-2 cursor-pointer ${
                isFav
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                  : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
              }`}
            >
              <Heart className={`w-4 h-4 ${isFav ? 'fill-rose-500 text-rose-500' : ''}`} />
              <span>{isFav ? 'في المفضلة' : 'إضافة للمفضلة'}</span>
            </button>

            <button
              onClick={handleShare}
              className="py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Share2 className="w-4 h-4" />
              <span>مشاركة</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2.5 pt-1">
            <button
              onClick={handleOpenReader}
              className="py-3 px-4 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 text-xs font-black transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <BookOpen className="w-4 h-4" />
              <span>قراءة الكتاب الآن 📖</span>
            </button>

            <button
              onClick={() => openQuizModalForBook(book)}
              className="py-3 px-4 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 text-xs font-black transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <HelpCircle className="w-4 h-4" />
              <span>امتحن نفسي ✍️</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
