import React from 'react';
import { useApp } from '../../context/AppContext';
import { MobileLoginScreen } from './MobileLoginScreen';
import { MobileHomeScreen } from './MobileHomeScreen';
import { MobileLibraryScreen } from './MobileLibraryScreen';
import { MobileBookDetailsScreen } from './MobileBookDetailsScreen';
import { MobileProfileScreen } from './MobileProfileScreen';
import {
  Home,
  BookOpen,
  Heart,
  User,
  Wifi,
  Battery,
  Signal,
  Sparkles,
  Smartphone
} from 'lucide-react';

interface MobileAppContainerProps {
  forcedScreen?: 'login' | 'home' | 'library' | 'details' | 'profile';
  standalone?: boolean;
}

export const MobileAppContainer: React.FC<MobileAppContainerProps> = ({
  forcedScreen,
  standalone = false
}) => {
  const {
    activeMobileScreen,
    setActiveMobileScreen,
    isLoggedIn,
    favoriteBookIds
  } = useApp();

  const currentScreen = forcedScreen || (!isLoggedIn ? 'login' : activeMobileScreen);

  return (
    <div className="relative mx-auto w-full max-w-[380px] h-[780px] bg-slate-950 rounded-[48px] p-3 shadow-2xl ring-1 ring-slate-800/80 border-[8px] border-slate-900 flex flex-col overflow-hidden select-none">
      {/* Top Mobile Status Bar (9:41, Wi-Fi, Battery) */}
      <div className="w-full px-5 py-2 flex items-center justify-between text-white text-[11px] font-bold z-30 bg-slate-950/90 backdrop-blur-sm select-none">
        <span className="font-mono">9:41</span>

        {/* Dynamic Island / Speaker notch */}
        <div className="w-24 h-4 bg-black rounded-full border border-slate-800 flex items-center justify-end px-2">
          <div className="w-2 h-2 rounded-full bg-slate-800"></div>
        </div>

        <div className="flex items-center gap-1.5 opacity-90 text-slate-300">
          <Signal className="w-3 h-3" />
          <Wifi className="w-3 h-3" />
          <Battery className="w-4 h-4" />
        </div>
      </div>

      {/* Screen Content Container */}
      <div className="relative flex-1 w-full bg-slate-950 overflow-hidden flex flex-col rounded-[32px]">
        {currentScreen === 'login' && <MobileLoginScreen />}
        {currentScreen === 'home' && <MobileHomeScreen />}
        {currentScreen === 'library' && <MobileLibraryScreen />}
        {currentScreen === 'details' && <MobileBookDetailsScreen />}
        {currentScreen === 'profile' && <MobileProfileScreen />}
      </div>

      {/* Bottom Navigation Bar (Shown on Home, Library, Details, Profile when logged in) */}
      {currentScreen !== 'login' && (
        <div className="absolute bottom-3 inset-x-3 z-30 bg-slate-950/95 backdrop-blur-xl border-t border-slate-800/90 py-2.5 px-4 rounded-b-[40px] flex items-center justify-around">
          {/* المزيد / الملف الشخصي */}
          <button
            onClick={() => setActiveMobileScreen('profile')}
            className={`flex flex-col items-center gap-1 transition-all cursor-pointer ${
              currentScreen === 'profile'
                ? 'text-blue-500 scale-105 font-black'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <User className="w-5 h-5" />
            <span className="text-[10px] font-bold">المزيد</span>
          </button>

          {/* المفضلة */}
          <button
            onClick={() => {
              setActiveMobileScreen('library');
            }}
            className={`relative flex flex-col items-center gap-1 transition-all cursor-pointer ${
              currentScreen === 'details'
                ? 'text-slate-400 hover:text-slate-200'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Heart className="w-5 h-5" />
            <span className="text-[10px] font-bold">المفضلة</span>
            {favoriteBookIds.length > 0 && (
              <span className="absolute -top-1 right-2 w-2 h-2 bg-rose-500 rounded-full"></span>
            )}
          </button>

          {/* المكتبة */}
          <button
            onClick={() => setActiveMobileScreen('library')}
            className={`flex flex-col items-center gap-1 transition-all cursor-pointer ${
              currentScreen === 'library'
                ? 'text-blue-500 scale-105 font-black'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <BookOpen className="w-5 h-5" />
            <span className="text-[10px] font-bold">المكتبة</span>
          </button>

          {/* الرئيسية */}
          <button
            onClick={() => setActiveMobileScreen('home')}
            className={`flex flex-col items-center gap-1 transition-all cursor-pointer ${
              currentScreen === 'home'
                ? 'text-blue-500 scale-105 font-black'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-[10px] font-bold">الرئيسية</span>
          </button>
        </div>
      )}

      {/* Home Indicator Line */}
      <div className="w-28 h-1 bg-slate-700/80 rounded-full mx-auto mt-2 select-none"></div>
    </div>
  );
};
