import React from 'react';
import { useApp } from '../../context/AppContext';
import { BookItem, SubjectCategory, EducationalStage } from '../../types';
import {
  Search,
  Bell,
  Menu,
  BookOpen,
  Calculator,
  Languages,
  FlaskConical,
  Globe2,
  Moon,
  Laptop,
  Atom,
  Binary,
  Microscope,
  Star,
  Download,
  CheckCircle2,
  ChevronLeft,
  Sparkles,
  ArrowRight,
  GraduationCap
} from 'lucide-react';

export const MobileHomeScreen: React.FC = () => {
  const {
    books,
    selectedCategory,
    setSelectedCategory,
    selectedGrade,
    setSelectedGrade,
    searchQuery,
    setSearchQuery,
    setActiveMobileScreen,
    setActiveBookDetails,
    downloadBook,
    downloadedBookIds,
    downloadProgress,
    unreadNotificationsCount,
    openModal
  } = useApp();

  const CATEGORY_ITEMS: {
    id: SubjectCategory;
    name: string;
    icon: React.ReactNode;
    bgGradient: string;
    borderColor: string;
    textColor: string;
  }[] = [
    {
      id: 'الرياضيات',
      name: 'الرياضيات',
      icon: <Calculator className="w-5 h-5 text-blue-400" />,
      bgGradient: 'bg-blue-950/50 hover:bg-blue-900/60',
      borderColor: 'border-blue-500/30',
      textColor: 'text-blue-200'
    },
    {
      id: 'اللغة العربية',
      name: 'اللغة العربية',
      icon: <Languages className="w-5 h-5 text-teal-400" />,
      bgGradient: 'bg-teal-950/50 hover:bg-teal-900/60',
      borderColor: 'border-teal-500/30',
      textColor: 'text-teal-200'
    },
    {
      id: 'اللغة الإنجليزية',
      name: 'اللغة الإنكليزية',
      icon: <Globe2 className="w-5 h-5 text-amber-400" />,
      bgGradient: 'bg-amber-950/50 hover:bg-amber-900/60',
      borderColor: 'border-amber-500/30',
      textColor: 'text-amber-200'
    },
    {
      id: 'العلوم',
      name: 'العلوم',
      icon: <FlaskConical className="w-5 h-5 text-emerald-400" />,
      bgGradient: 'bg-emerald-950/50 hover:bg-emerald-900/60',
      borderColor: 'border-emerald-500/30',
      textColor: 'text-emerald-200'
    },
    {
      id: 'الاجتماعيات',
      name: 'الاجتماعيات',
      icon: <BookOpen className="w-5 h-5 text-purple-400" />,
      bgGradient: 'bg-purple-950/50 hover:bg-purple-900/60',
      borderColor: 'border-purple-500/30',
      textColor: 'text-purple-200'
    },
    {
      id: 'التربية الإسلامية',
      name: 'التربية الإسلامية',
      icon: <Moon className="w-5 h-5 text-yellow-400" />,
      bgGradient: 'bg-yellow-950/50 hover:bg-yellow-900/60',
      borderColor: 'border-yellow-500/30',
      textColor: 'text-yellow-200'
    },
    {
      id: 'الحاسوب',
      name: 'الحاسوب',
      icon: <Laptop className="w-5 h-5 text-indigo-400" />,
      bgGradient: 'bg-indigo-950/50 hover:bg-indigo-900/60',
      borderColor: 'border-indigo-500/30',
      textColor: 'text-indigo-200'
    },
    {
      id: 'الكيمياء',
      name: 'الكيمياء',
      icon: <Atom className="w-5 h-5 text-rose-400" />,
      bgGradient: 'bg-rose-950/50 hover:bg-rose-900/60',
      borderColor: 'border-rose-500/30',
      textColor: 'text-rose-200'
    },
    {
      id: 'الفيزياء',
      name: 'الفيزياء',
      icon: <Binary className="w-5 h-5 text-sky-400" />,
      bgGradient: 'bg-sky-950/50 hover:bg-sky-900/60',
      borderColor: 'border-sky-500/30',
      textColor: 'text-sky-200'
    },
    {
      id: 'الأحياء',
      name: 'الأحياء',
      icon: <Microscope className="w-5 h-5 text-green-400" />,
      bgGradient: 'bg-green-950/50 hover:bg-green-900/60',
      borderColor: 'border-green-500/30',
      textColor: 'text-green-200'
    }
  ];

  const GRADES: EducationalStage[] = [
    'الثالث متوسط',
    'السادس إعدادي',
    'الرابع إعدادي',
    'الخامس إعدادي',
    'الأول متوسط',
    'الثاني متوسط',
    'الابتدائية'
  ];

  const handleSelectBook = (book: BookItem) => {
    setActiveBookDetails(book);
    setActiveMobileScreen('details');
  };

  const handleSelectCategory = (cat: SubjectCategory) => {
    setSelectedCategory(cat);
    setActiveMobileScreen('library');
  };

  // Filter latest books
  const latestBooks = books.slice(0, 6);

  return (
    <div className="min-h-full flex flex-col pb-20 bg-slate-950 text-slate-100 font-['Tajawal','Cairo',sans-serif] overflow-y-auto">
      {/* Top Header Bar matching the image */}
      <div className="sticky top-0 z-20 bg-slate-950/95 backdrop-blur-md px-4 py-3 border-b border-slate-800/80 flex items-center justify-between">
        <button
          onClick={() => setActiveMobileScreen('profile')}
          className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <Menu className="w-5 h-5" />
        </button>

        <h1 className="text-base font-black text-white tracking-wide">الرئيسية</h1>

        <button
          onClick={() => openModal('notifications-modal')}
          className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 relative transition-colors cursor-pointer"
        >
          <Bell className="w-5 h-5" />
          {unreadNotificationsCount > 0 && (
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-blue-500 rounded-full ring-2 ring-slate-950 animate-pulse"></span>
          )}
        </button>
      </div>

      <div className="p-4 space-y-5">
        {/* Search Input Bar */}
        <div className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث عن كتاب، مادة، صف..."
            className="w-full bg-slate-900 text-white text-xs rounded-2xl py-3 pr-11 pl-4 border border-slate-800 focus:border-blue-500 focus:outline-none transition-all placeholder:text-slate-500 text-right shadow-inner"
          />
          <div className="absolute right-3.5 top-3.5 text-slate-400">
            <Search className="w-4 h-4" />
          </div>
        </div>

        {/* Featured Hero Banner matching the mockup */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 border border-blue-600/30 p-5 shadow-xl">
          {/* Background shapes & glow */}
          <div className="absolute top-0 left-0 w-36 h-36 bg-cyan-500/10 rounded-full blur-2xl"></div>
          <div className="absolute -bottom-8 -right-8 w-32 h-32 bg-blue-600/20 rounded-full blur-xl"></div>

          <div className="relative z-10 flex items-center justify-between gap-3">
            <div className="space-y-2 max-w-[62%] text-right">
              <h3 className="text-base font-black text-white leading-snug">
                كل الكتب بين يديك
              </h3>
              <p className="text-[11px] font-bold text-slate-300 leading-relaxed">
                تحميل / مستويات عالية / وجهة سهلة وأنيقة
              </p>
              <button
                onClick={() => {
                  setSelectedGrade('الثالث متوسط');
                  setActiveMobileScreen('library');
                }}
                className="mt-1 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-black rounded-xl shadow-md shadow-blue-600/40 transition-transform active:scale-95 cursor-pointer inline-flex items-center gap-1.5"
              >
                <span>استكشف الآن</span>
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Illustration on the right */}
            <div className="relative w-24 h-24 flex items-center justify-center flex-shrink-0">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-blue-600 to-cyan-400 p-0.5 shadow-lg">
                <div className="w-full h-full bg-slate-900 rounded-[14px] flex flex-col items-center justify-center p-2 text-center">
                  <BookOpen className="w-8 h-8 text-cyan-400 animate-pulse" />
                  <span className="text-[9px] font-black text-white mt-1">طبعة 2026</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Section: الأقسام (Categories) */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-black text-white">الأقسام</h2>
            <button
              onClick={() => {
                setSelectedCategory('all');
                setActiveMobileScreen('library');
              }}
              className="text-[11px] font-bold text-blue-400 hover:text-blue-300 transition-colors cursor-pointer"
            >
              عرض الكل
            </button>
          </div>

          {/* Grid of colorful badges matching the image */}
          <div className="grid grid-cols-5 gap-2">
            {CATEGORY_ITEMS.map((item) => (
              <button
                key={item.id}
                onClick={() => handleSelectCategory(item.id)}
                className={`flex flex-col items-center justify-center p-2.5 rounded-2xl border ${item.borderColor} ${item.bgGradient} transition-all transform hover:scale-105 active:scale-95 cursor-pointer space-y-1.5 shadow-sm text-center`}
              >
                <div className="p-1.5 rounded-xl bg-slate-900/80 shadow-inner flex items-center justify-center">
                  {item.icon}
                </div>
                <span className={`text-[10px] font-black leading-tight ${item.textColor} line-clamp-1`}>
                  {item.name}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Section: الصفوف الدراسية (Grades) */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-black text-white">الصفوف الدراسية</h2>
            <button
              onClick={() => {
                setSelectedGrade('all');
                setActiveMobileScreen('library');
              }}
              className="text-[11px] font-bold text-blue-400 hover:text-blue-300 transition-colors cursor-pointer"
            >
              عرض الكل
            </button>
          </div>

          {/* Horizontal scroll or wrap chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            {GRADES.map((grade) => {
              const isSelected = selectedGrade === grade;
              return (
                <button
                  key={grade}
                  onClick={() => {
                    setSelectedGrade(grade);
                    setActiveMobileScreen('library');
                  }}
                  className={`px-3.5 py-2 rounded-2xl text-[11px] font-black whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30 border border-blue-400'
                      : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800'
                  }`}
                >
                  <GraduationCap className="w-3.5 h-3.5 opacity-80" />
                  <span>{grade}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Section: أحدث الكتب (Latest Books) */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-black text-white">أحدث الكتب</h2>
            <button
              onClick={() => setActiveMobileScreen('library')}
              className="text-[11px] font-bold text-blue-400 hover:text-blue-300 transition-colors cursor-pointer"
            >
              عرض الكل
            </button>
          </div>

          {/* Vertical/Card List */}
          <div className="space-y-2.5">
            {latestBooks.map((book) => {
              const isDownloaded = downloadedBookIds.includes(book.id);
              const progress = downloadProgress[book.id];

              return (
                <div
                  key={book.id}
                  onClick={() => handleSelectBook(book)}
                  className="p-3 rounded-2xl bg-slate-900/90 hover:bg-slate-850 border border-slate-800/90 transition-all flex items-center justify-between gap-3 cursor-pointer group shadow-sm hover:border-slate-700"
                >
                  {/* Left: Action download icon */}
                  <div className="flex items-center gap-2 flex-shrink-0" onClick={(e) => e.stopPropagation()}>
                    <button
                      onClick={() => downloadBook(book)}
                      className={`w-9 h-9 rounded-xl flex items-center justify-center transition-transform active:scale-90 cursor-pointer ${
                        isDownloaded
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : 'bg-blue-600 hover:bg-blue-500 text-white shadow-md shadow-blue-600/30'
                      }`}
                      title={isDownloaded ? 'تم التحميل' : 'تحميل الكتاب'}
                    >
                      {progress !== undefined ? (
                        <span className="text-[9px] font-black">{progress}%</span>
                      ) : isDownloaded ? (
                        <CheckCircle2 className="w-4 h-4" />
                      ) : (
                        <Download className="w-4 h-4" />
                      )}
                    </button>
                  </div>

                  {/* Center: Book Info */}
                  <div className="flex-1 text-right min-w-0">
                    <h4 className="text-xs font-black text-white group-hover:text-blue-400 transition-colors truncate">
                      {book.title}
                    </h4>
                    <span className="text-[10px] text-slate-400 block mt-0.5">
                      {book.grade}
                    </span>
                    <div className="flex items-center justify-end gap-2.5 mt-1 text-[10px] text-slate-400">
                      <span className="font-mono text-slate-300 font-bold">{book.fileSize}</span>
                      <span className="text-slate-600">•</span>
                      <span className="font-mono text-slate-300">{book.yearEdition}</span>
                      <span className="text-slate-600">•</span>
                      <div className="flex items-center gap-0.5 text-amber-400 font-bold">
                        <span>{book.rating}</span>
                        <Star className="w-3 h-3 fill-amber-400" />
                      </div>
                    </div>
                  </div>

                  {/* Right: Book Cover Thumbnail */}
                  <div className="relative w-12 h-16 rounded-lg overflow-hidden flex-shrink-0 shadow-md border border-slate-700/50 bg-gradient-to-b from-blue-900 to-indigo-950 flex flex-col justify-between p-1.5 text-center">
                    <span className="text-[7px] font-black text-cyan-300 line-clamp-1">{book.category}</span>
                    <div className="w-full h-0.5 bg-blue-400/40 rounded"></div>
                    <span className="text-[8px] font-black text-white">{book.yearEdition}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
