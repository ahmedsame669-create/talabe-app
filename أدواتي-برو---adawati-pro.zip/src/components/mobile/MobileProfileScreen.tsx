import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  User,
  BookOpen,
  Heart,
  Download,
  CreditCard,
  Settings,
  FileText,
  Edit3,
  Bell,
  HelpCircle,
  Info,
  LogOut,
  ChevronLeft,
  Star,
  ShieldCheck,
  Smartphone,
  CheckCircle2,
  Lock,
  Unlock,
  KeyRound,
  ExternalLink,
  Sliders,
  Moon,
  Volume2,
  Trash2
} from 'lucide-react';

export const MobileProfileScreen: React.FC = () => {
  const {
    user,
    setUser,
    logoutUser,
    setActiveMobileScreen,
    books,
    favoriteBookIds,
    downloadedBookIds,
    unlockedBookIds,
    studyNotes,
    unreadNotificationsCount,
    openModal,
    showToast,
    paymentInfo
  } = useApp();

  const [activeTab, setActiveTab] = useState<'main' | 'settings' | 'subscriptions'>('main');
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [offlineMode, setOfflineMode] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [highQualityPdf, setHighQualityPdf] = useState(true);

  const unlockedBooksCount = unlockedBookIds.includes('all')
    ? books.length
    : unlockedBookIds.length;

  const MENU_ITEMS = [
    {
      id: 'my-books',
      title: '📚 كتبي',
      subtitle: 'الكتب والملازم المفعلة للدراسة',
      icon: <BookOpen className="w-5 h-5 text-blue-400" />,
      badge: `${unlockedBooksCount} مادة مفعلة`,
      badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
      onClick: () => {
        openModal('my-books');
        showToast('فتح قائمة كتبي والملازم المفعلة 📚', 'info');
      }
    },
    {
      id: 'favorites',
      title: '❤️ المفضلة',
      subtitle: 'الملازم المحفوظة للمراجعة السريعة',
      icon: <Heart className="w-5 h-5 text-rose-400" />,
      badge: `${favoriteBookIds.length} ملازم`,
      badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
      onClick: () => {
        setActiveMobileScreen('library');
        showToast('عرض المواد المفضلة ❤️', 'info');
      }
    },
    {
      id: 'downloads',
      title: '⬇️ التحميلات',
      subtitle: 'المواد المحملة للقراءة بدون إنترنت (أوفلاين)',
      icon: <Download className="w-5 h-5 text-emerald-400" />,
      badge: `${downloadedBookIds.length} جاهز أوفلاين`,
      badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
      onClick: () => {
        openModal('my-books');
        showToast('عرض التحميلات المحفوظة بالجهاز ⬇️', 'info');
      }
    },
    {
      id: 'subscriptions',
      title: '💳 الاشتراكات',
      subtitle: 'حالة الحساب وأكواد التفعيل (10,000 د.ع)',
      icon: <CreditCard className="w-5 h-5 text-amber-400" />,
      badge: 'نشط 🌟',
      badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
      onClick: () => setActiveTab('subscriptions')
    },
    {
      id: 'settings',
      title: '⚙️ الإعدادات',
      subtitle: 'خيارات القراءة والإشعارات والمظهر',
      icon: <Settings className="w-5 h-5 text-purple-400" />,
      badge: undefined,
      badgeColor: '',
      onClick: () => setActiveTab('settings')
    }
  ];

  return (
    <div className="min-h-full flex flex-col pb-24 bg-slate-950 text-slate-100 font-['Tajawal','Cairo',sans-serif] overflow-y-auto">
      {/* Top Header */}
      <div className="sticky top-0 z-20 bg-slate-950/95 backdrop-blur-md px-4 py-3.5 border-b border-slate-800/80 flex items-center justify-between">
        {activeTab !== 'main' ? (
          <button
            onClick={() => setActiveTab('main')}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white flex items-center gap-1 text-xs font-bold cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4 rotate-180" />
            <span>رجوع</span>
          </button>
        ) : (
          <div className="w-6" />
        )}
        <h1 className="text-base font-black text-white tracking-wide">
          {activeTab === 'main' && 'الملف الشخصي للطالب'}
          {activeTab === 'subscriptions' && '💳 الاشتراكات وأكواد التفعيل'}
          {activeTab === 'settings' && '⚙️ إعدادات التطبيق'}
        </h1>
        <div className="w-6" />
      </div>

      <div className="p-4 space-y-5">
        {/* User Card */}
        <div className="p-4.5 rounded-3xl bg-gradient-to-br from-slate-900 via-blue-950/90 to-slate-900 border border-blue-900/40 flex items-center justify-between shadow-xl shadow-blue-950/30 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />

          <div className="flex items-center gap-3.5 relative z-10">
            {/* Student Avatar */}
            <div className="relative w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-500 to-amber-400 p-0.5 shadow-lg shadow-blue-600/30">
              <div className="w-full h-full rounded-[14px] bg-slate-950 flex items-center justify-center text-white font-black text-xl overflow-hidden">
                <span className="text-blue-400 font-bold">أح</span>
              </div>
              <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-slate-900 flex items-center justify-center text-[8px] text-white font-black">
                ✓
              </span>
            </div>

            {/* Student Info matching prompt */}
            <div className="text-right">
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-white tracking-tight">{user.name || 'أحمد سامي'}</h3>
                <span className="text-[10px] font-black px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  {user.badge || 'مشترك مميز ⭐'}
                </span>
              </div>
              <p className="text-xs font-bold text-blue-300 mt-1 flex items-center gap-1.5">
                <span>الصف:</span>
                <span className="text-white font-black">{user.grade || 'الثالث متوسط'}</span>
              </p>
              <p className="text-[10px] text-slate-400 font-mono mt-0.5">معرف الطالب: TAL-{user.name === 'أحمد سامي' ? '2026-IQ' : 'STUDENT'}</p>
            </div>
          </div>

          <button
            onClick={() => showToast('حساب الطالب موثق ومؤكد لدى إدارة طلبتي 🌟', 'success')}
            className="p-2.5 rounded-2xl bg-blue-500/15 text-blue-400 border border-blue-500/30 hover:bg-blue-500/25 transition-all cursor-pointer relative z-10"
            title="حساب موثق"
          >
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
          </button>
        </div>

        {/* MAIN VIEW */}
        {activeTab === 'main' && (
          <>
            {/* Quick Stats Grid */}
            <div className="grid grid-cols-3 gap-2.5 text-center">
              <div
                onClick={() => openModal('my-books')}
                className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-blue-500/40 transition-colors cursor-pointer"
              >
                <span className="text-lg font-black text-blue-400 block font-mono">{unlockedBooksCount}</span>
                <span className="text-[11px] text-slate-400 font-bold">المواد المفعلة</span>
              </div>

              <div
                onClick={() => setActiveMobileScreen('library')}
                className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-rose-500/40 transition-colors cursor-pointer"
              >
                <span className="text-lg font-black text-rose-400 block font-mono">{favoriteBookIds.length}</span>
                <span className="text-[11px] text-slate-400 font-bold">المفضلة</span>
              </div>

              <div
                onClick={() => openModal('my-books')}
                className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-emerald-500/40 transition-colors cursor-pointer"
              >
                <span className="text-lg font-black text-emerald-400 block font-mono">{downloadedBookIds.length}</span>
                <span className="text-[11px] text-slate-400 font-bold">التحميلات</span>
              </div>
            </div>

            {/* Requested Menu Items: 📚 كتبي, ❤️ المفضلة, ⬇️ التحميلات, 💳 الاشتراكات, ⚙️ الإعدادات */}
            <div className="rounded-3xl bg-slate-900/95 border border-slate-800 divide-y divide-slate-800/80 overflow-hidden shadow-lg">
              {MENU_ITEMS.map((item) => (
                <button
                  key={item.id}
                  onClick={item.onClick}
                  className="w-full p-4 flex items-center justify-between hover:bg-slate-800/70 active:bg-slate-800 transition-colors text-right cursor-pointer group"
                >
                  <div className="flex items-center gap-2">
                    <ChevronLeft className="w-4 h-4 text-slate-500 group-hover:text-white transition-colors" />
                    {item.badge && (
                      <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${item.badgeColor}`}>
                        {item.badge}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <h4 className="text-sm font-black text-white group-hover:text-blue-400 transition-colors">
                        {item.title}
                      </h4>
                      <p className="text-[11px] text-slate-400">{item.subtitle}</p>
                    </div>
                    <div className="w-10 h-10 rounded-2xl bg-slate-800/90 border border-slate-700/60 flex items-center justify-center shadow-inner flex-shrink-0">
                      {item.icon}
                    </div>
                  </div>
                </button>
              ))}
            </div>

            {/* Support & Quick Contact */}
            <div className="p-4 rounded-3xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
              <button
                onClick={() => window.open(`https://wa.me/964${paymentInfo.supportPhone.replace(/\D/g, '').substring(1)}`, '_blank')}
                className="px-3 py-1.5 rounded-xl bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600/30 border border-emerald-500/30 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <span>واتساب الدعم</span>
                <ExternalLink className="w-3 h-3" />
              </button>
              <div className="text-right">
                <span className="text-xs font-bold text-white block">الدعم الفني والاشتراكات</span>
                <span className="text-[10px] text-slate-400 font-mono" dir="ltr">{paymentInfo.supportPhone}</span>
              </div>
            </div>

            {/* Logout */}
            <button
              onClick={logoutUser}
              className="w-full p-3.5 rounded-2xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs font-black transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>تسجيل الخروج</span>
            </button>
          </>
        )}

        {/* SUBSCRIPTIONS VIEW */}
        {activeTab === 'subscriptions' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="p-5 rounded-3xl bg-gradient-to-br from-amber-950/40 via-slate-900 to-slate-900 border border-amber-500/30 space-y-3">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30">
                  الحساب نشط ✓
                </span>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-black text-white">اشتراك ملازم الثالث متوسط</h3>
                  <CreditCard className="w-4 h-4 text-amber-400" />
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed text-right">
                سعر فتح وتفعيل المادة الواحدة: <b className="text-emerald-400 font-mono">10,000 د.ع</b> مع وصول كامل للمرشحات الوزارية وحلول الأسئلة.
              </p>

              <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
                <button
                  onClick={() => openModal('activation-code')}
                  className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>إدخال كود تفعيل 🔑</span>
                </button>

                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block">رقم زين كاش وآسيا حوالة:</span>
                  <span className="text-amber-300 font-bold font-mono" dir="ltr">{paymentInfo.zainCash}</span>
                </div>
              </div>
            </div>

            {/* List of activated books */}
            <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-4 space-y-3">
              <h4 className="text-xs font-black text-white text-right">المواد والمناهج المفعلة بحسابك:</h4>
              <div className="space-y-2">
                {books.map((b) => {
                  const isUnlocked = unlockedBookIds.includes('all') || unlockedBookIds.includes(b.id);
                  return (
                    <div
                      key={b.id}
                      className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800/80 flex items-center justify-between text-right"
                    >
                      {isUnlocked ? (
                        <span className="px-2.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>مفعل وجاهز</span>
                        </span>
                      ) : (
                        <button
                          onClick={() => openModal('activation-code')}
                          className="px-2.5 py-1 rounded-xl bg-amber-500/20 text-amber-300 text-[10px] font-bold border border-amber-500/30 flex items-center gap-1 cursor-pointer"
                        >
                          <Lock className="w-3 h-3" />
                          <span>تفعيل (10,000 د.ع)</span>
                        </button>
                      )}

                      <div>
                        <h5 className="text-xs font-bold text-white">{b.title}</h5>
                        <p className="text-[10px] text-slate-400">{b.category} • 2026</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* SETTINGS VIEW */}
        {activeTab === 'settings' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="rounded-3xl bg-slate-900/90 border border-slate-800 divide-y divide-slate-800/80 overflow-hidden">
              {/* Setting 1: Notifications */}
              <div className="p-4 flex items-center justify-between">
                <input
                  type="checkbox"
                  checked={notificationsEnabled}
                  onChange={(e) => {
                    setNotificationsEnabled(e.target.checked);
                    showToast(e.target.checked ? 'تم تفعيل إشعارات الامتحانات والمرشحات 🔔' : 'تم كتم الإشعارات', 'info');
                  }}
                  className="w-5 h-5 accent-blue-500 cursor-pointer"
                />
                <div className="text-right">
                  <h4 className="text-xs font-bold text-white">إشعارات المرشحات والوزاريات</h4>
                  <p className="text-[10px] text-slate-400">تلقي تنبيهات عند إضافة أسئلة وزارية جديدة</p>
                </div>
              </div>

              {/* Setting 2: Offline Mode */}
              <div className="p-4 flex items-center justify-between">
                <input
                  type="checkbox"
                  checked={offlineMode}
                  onChange={(e) => {
                    setOfflineMode(e.target.checked);
                    showToast('تم ضبط وضع الحفظ الأوفلاين 💾', 'info');
                  }}
                  className="w-5 h-5 accent-blue-500 cursor-pointer"
                />
                <div className="text-right">
                  <h4 className="text-xs font-bold text-white">حفظ الملازم بدون إنترنت (أوفلاين)</h4>
                  <p className="text-[10px] text-slate-400">إتاحة فتح الكتب المفعلة بدون الحاجة لاتصال شبكة</p>
                </div>
              </div>

              {/* Setting 3: High Quality PDF */}
              <div className="p-4 flex items-center justify-between">
                <input
                  type="checkbox"
                  checked={highQualityPdf}
                  onChange={(e) => setHighQualityPdf(e.target.checked)}
                  className="w-5 h-5 accent-blue-500 cursor-pointer"
                />
                <div className="text-right">
                  <h4 className="text-xs font-bold text-white">جودة الصفحات الفائقة (HD)</h4>
                  <p className="text-[10px] text-slate-400">عرض النصوص والرسومات بأعلى دقة وضوح</p>
                </div>
              </div>

              {/* Setting 4: Sounds */}
              <div className="p-4 flex items-center justify-between">
                <input
                  type="checkbox"
                  checked={soundEnabled}
                  onChange={(e) => setSoundEnabled(e.target.checked)}
                  className="w-5 h-5 accent-blue-500 cursor-pointer"
                />
                <div className="text-right">
                  <h4 className="text-xs font-bold text-white">أصوات التفاعل والتنقل</h4>
                  <p className="text-[10px] text-slate-400">مؤثرات صوتية لطيفة عند قلب الصفحات</p>
                </div>
              </div>
            </div>

            {/* Clear cache */}
            <button
              onClick={() => showToast('تم تنظيف الذاكرة المؤقتة وتسريع التطبيق ⚡', 'success')}
              className="w-full p-3.5 rounded-2xl bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 text-xs font-bold flex items-center justify-center gap-2 cursor-pointer"
            >
              <Trash2 className="w-4 h-4 text-slate-400" />
              <span>مسح الذاكرة المؤقتة وتسريع التصفح</span>
            </button>
          </div>
        )}

        {/* Footer info */}
        <div className="text-center text-[10px] text-slate-500 font-mono space-y-0.5 pt-2">
          <p>منصة طلبتي التعليمية • الإصدار 2026 المعتمد</p>
          <p>الصف الثالث متوسط • جمهورية العراق 🇮🇶</p>
        </div>
      </div>
    </div>
  );
};
