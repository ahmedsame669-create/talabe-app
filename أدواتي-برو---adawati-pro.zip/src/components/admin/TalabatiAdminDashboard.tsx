import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BookItem, SubjectCategory, EducationalStage } from '../../types';
import {
  LayoutDashboard,
  BookOpen,
  PlusCircle,
  FileText,
  Grid,
  GraduationCap,
  Users,
  BarChart3,
  Download,
  Settings,
  Database,
  LogOut,
  Sparkles,
  TrendingUp,
  Search,
  CheckCircle2,
  Trash2,
  Edit,
  Eye,
  Star,
  Clock,
  ArrowUpRight,
  ShieldCheck,
  HardDrive,
  KeyRound,
  Lock,
  Unlock,
  Copy,
  Send,
  Check,
  PhoneCall
} from 'lucide-react';

type AdminTab =
  | 'overview'
  | 'activation-codes'
  | 'books'
  | 'add-book'
  | 'filters'
  | 'categories'
  | 'grades'
  | 'users'
  | 'analytics'
  | 'downloads'
  | 'settings'
  | 'backup';

export const TalabatiAdminDashboard: React.FC = () => {
  const {
    books,
    addNewBook,
    deleteBook,
    setActiveReadingBook,
    showToast,
    orders,
    approveOrder,
    rejectOrder,
    setViewMode,
    setActiveMobileScreen,
    setActiveBookDetails,
    activationCodes,
    generateActivationCode,
    deleteActivationCode,
    unlockedBookIds,
    unlockBookDirectly,
    lockBook,
    lockAllBooks,
    paymentInfo,
    openBookEditorForBook,
    isSupervisor,
    openModal
  } = useApp();

  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [searchTerm, setSearchTerm] = useState('');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  // Activation Code Generator Form State
  const [selectedBookForCode, setSelectedBookForCode] = useState<string>('all');
  const [studentNameToCode, setStudentNameToCode] = useState('');
  const [studentPhoneToCode, setStudentPhoneToCode] = useState('07734378998');

  // Form state for adding new book
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<SubjectCategory>('الرياضيات');
  const [newGrade, setNewGrade] = useState<EducationalStage>('الثالث متوسط');
  const [newYear, setNewYear] = useState('2026');
  const [newPages, setNewPages] = useState(250);
  const [newFileSize, setNewFileSize] = useState('16.5 MB');
  const [newDesc, setNewDesc] = useState('');

  const handleGenerateCode = (e: React.FormEvent) => {
    e.preventDefault();
    const bookIdVal = selectedBookForCode === 'all' ? 'all' : Number(selectedBookForCode);
    const created = generateActivationCode(
      bookIdVal,
      studentNameToCode.trim() || 'طالب جديد',
      studentPhoneToCode.trim() || '07734378998'
    );
    setStudentNameToCode('');
    setCopiedCode(created.code);
    navigator.clipboard.writeText(created.code);
    setTimeout(() => setCopiedCode(null), 3000);
  };

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    showToast(`تم نسخ الكود ${code} بنجاح! 📋`, 'success');
    setTimeout(() => setCopiedCode(null), 2500);
  };

  const handleSendViaWhatsApp = (code: string, studentPhone: string, bookTitle: string) => {
    const cleanPhone = studentPhone.replace(/\D/g, '') || paymentInfo.supportPhone;
    const formattedPhone = cleanPhone.startsWith('0') ? '964' + cleanPhone.substring(1) : cleanPhone;
    const msg = encodeURIComponent(`مرحباً بك في منصة طلبتي 🎓\nتم تفعيل اشتراكك لمادة: ${bookTitle}\n\n🔑 كود التفعيل الخاص بك هو:\n${code}\n\nيرجى فتح التطبيق، والضغط على "تفعيل بكود" ولصق هذا الكود لفتح المادة مباشرة.`);
    window.open(`https://wa.me/${formattedPhone}?text=${msg}`, '_blank');
  };

  const handleAddBookSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) {
      showToast('يرجى كتابة عنوان الكتاب', 'error');
      return;
    }

    const createdBook: BookItem = {
      id: Date.now(),
      title: newTitle,
      category: newCategory,
      grade: newGrade,
      desc: newDesc || `كتاب مادة ${newTitle} - المنهج الوزاري المعتمد طبعة ${newYear}`,
      targetGuarantee: `المنهج المعتمد ${newYear}`,
      pagesCount: Number(newPages) || 200,
      yearEdition: newYear,
      fileSize: newFileSize,
      fileFormat: 'PDF',
      author: 'وزارة التربية',
      price: 'تحميل مجاني',
      badge: 'جديد 🌟',
      rating: 5.0,
      reviewsCount: 1,
      downloadsCount: 0,
      gradient: 'from-blue-600 via-indigo-600 to-cyan-700',
      samplePages: [
        {
          pageNumber: 1,
          title: `الفصل الأول: مدخل شامل لمادة ${newTitle}`,
          content: [
            '1. المفاهيم الأساسية والقوانين المعتمدة وزارياً.',
            '2. ملخص الثوابت والمسائل الأكثر تكراراً في الامتحانات العامة.',
            '3. نماذج حلول نموذجية متوافقة مع مركز الفحص والتقويم.'
          ],
          ministerialNote: '📌 ثابت وزاري: ركز على التعاريف والمسائل المكررة.'
        }
      ],
      quiz: [
        {
          id: 1,
          question: `ما هو المحور الأساسي للوحدة الأولى في ${newTitle}؟`,
          options: ['المفاهيم التأسيسية والقواعد', 'المسائل التطبيقية', 'التجارب المخبرية', 'النماذج الإثرائية'],
          correctAnswerIndex: 0,
          explanation: 'المفاهيم التأسيسية هي القاعدة لكل الوحدات اللاحقة.'
        }
      ]
    };

    addNewBook(createdBook);
    setNewTitle('');
    setNewDesc('');
    setActiveTab('books');
  };

  const handleExportBackup = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(books, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `talabati_books_backup_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast('تم تصدير نسخة احتياطية لكافة بيانات الكتب بنجاح 💾', 'success');
  };

  const SIDEBAR_ITEMS: { id: AdminTab; label: string; icon: React.ReactNode }[] = [
    { id: 'overview', label: 'الرئيسية', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'activation-codes', label: 'أكواد التفعيل والاشتراكات 🔑', icon: <KeyRound className="w-4 h-4 text-amber-400" /> },
    { id: 'books', label: 'الكتب والمواد', icon: <BookOpen className="w-4 h-4" /> },
    { id: 'add-book', label: 'إضافة كتاب', icon: <PlusCircle className="w-4 h-4" /> },
    { id: 'filters', label: 'المرشحات', icon: <FileText className="w-4 h-4" /> },
    { id: 'categories', label: 'الأقسام', icon: <Grid className="w-4 h-4" /> },
    { id: 'grades', label: 'الصفوف الدراسية', icon: <GraduationCap className="w-4 h-4" /> },
    { id: 'users', label: 'طلبات الطلاب والحوالات', icon: <Users className="w-4 h-4" /> },
    { id: 'analytics', label: 'الإحصائيات', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'downloads', label: 'التحميلات', icon: <Download className="w-4 h-4" /> },
    { id: 'settings', label: 'الإعدادات', icon: <Settings className="w-4 h-4" /> },
    { id: 'backup', label: 'نسخ احتياطي', icon: <Database className="w-4 h-4" /> },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-['Tajawal','Cairo',sans-serif] flex flex-col lg:flex-row">
      {/* Sidebar matching the image */}
      <aside className="w-full lg:w-64 bg-slate-900/95 border-b lg:border-b-0 lg:border-l border-slate-800/80 p-5 flex flex-col justify-between flex-shrink-0 z-20">
        <div className="space-y-6">
          {/* Logo Branding */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-blue-600/30">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-black text-white">لوحة تحكم الإدارة</h2>
              <p className="text-[10px] text-blue-400 font-bold">منصة طلبتي للأكاديمية</p>
            </div>
          </div>

          {/* Navigation links matching the screenshot list */}
          <nav className="space-y-1">
            {SIDEBAR_ITEMS.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer text-right ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30 font-black'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  }`}
                >
                  <span className={isActive ? 'text-white' : 'text-slate-400'}>{item.icon}</span>
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom logout / mode switcher */}
        <div className="pt-6 border-t border-slate-800/80 space-y-2">
          <button
            onClick={() => {
              setViewMode('mobile-app');
              setActiveMobileScreen('home');
            }}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-blue-400 text-xs font-bold transition-colors cursor-pointer"
          >
            <span>معاينة شاشة الهاتف 📱</span>
          </button>

          <button
            onClick={() => showToast('تم إنهاء جلسة الإدارة', 'info')}
            className="w-full flex items-center gap-2.5 px-3.5 py-2 rounded-xl text-rose-400 hover:bg-rose-500/10 text-xs font-bold transition-colors cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>تسجيل الخروج</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-5 lg:p-8 space-y-6 overflow-y-auto">
        {/* Top Header Greeting Bar matching the screenshot */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800/80 rounded-3xl p-5 shadow-lg">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-blue-500/20 text-blue-400">
                <ShieldCheck className="w-4 h-4" />
              </span>
              <h1 className="text-lg font-black text-white">مرحباً بك، المدير</h1>
            </div>
            <p className="text-xs text-slate-400 font-medium">منصة مكتبتي للأكاديمية والكتب الوزارية 2026</p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('add-book')}
              className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-black shadow-md shadow-blue-600/30 flex items-center gap-2 transition-transform active:scale-95 cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>إضافة كتاب جديد</span>
            </button>
          </div>
        </div>

        {/* TAB 1: OVERVIEW (Exact replica of the dashboard layout in the image) */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* 4 Stat KPI Cards matching the screenshot */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Stat 1: إجمالي الكتب */}
              <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 flex items-center justify-between shadow-md">
                <div className="text-right space-y-1">
                  <span className="text-[11px] font-bold text-slate-400">إجمالي الكتب</span>
                  <div className="text-2xl font-black text-white font-mono">250</div>
                  <span className="text-[10px] font-bold text-blue-400 block">+5 هذا الشهر</span>
                </div>
                <div className="w-12 h-12 rounded-2xl bg-blue-500/20 text-blue-400 flex items-center justify-center border border-blue-500/30">
                  <BookOpen className="w-6 h-6" />
                </div>
              </div>

              {/* Stat 2: التحميلات */}
              <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 flex items-center justify-between shadow-md">
                <div className="text-right space-y-1">
                  <span className="text-[11px] font-bold text-slate-400">التحميلات</span>
                  <div className="text-2xl font-black text-emerald-400 font-mono">125,430</div>
                  <span className="text-[10px] font-bold text-emerald-400 block">+8% عن الشهر الماضي</span>
                </div>
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                  <Download className="w-6 h-6" />
                </div>
              </div>

              {/* Stat 3: المستخدمين */}
              <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 flex items-center justify-between shadow-md">
                <div className="text-right space-y-1">
                  <span className="text-[11px] font-bold text-slate-400">المستخدمين</span>
                  <div className="text-2xl font-black text-purple-400 font-mono">50,250</div>
                  <span className="text-[10px] font-bold text-purple-400 block">+1,250 هذا الشهر</span>
                </div>
                <div className="w-12 h-12 rounded-2xl bg-purple-500/20 text-purple-400 flex items-center justify-center border border-purple-500/30">
                  <Users className="w-6 h-6" />
                </div>
              </div>

              {/* Stat 4: المرشحات */}
              <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 flex items-center justify-between shadow-md">
                <div className="text-right space-y-1">
                  <span className="text-[11px] font-bold text-slate-400">المرشحات</span>
                  <div className="text-2xl font-black text-amber-400 font-mono">18</div>
                  <span className="text-[10px] font-bold text-amber-400 block">+2 هذا الشهر</span>
                </div>
                <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                  <Sparkles className="w-6 h-6" />
                </div>
              </div>
            </div>

            {/* Row 2: Charts & Recent added books (Matching the screenshot) */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Line Chart: التحميلات خلال الـ أيام الأخيرة */}
              <div className="lg:col-span-2 p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-md space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-400">تحديث لحظي</span>
                  <h3 className="text-sm font-black text-white">التحميلات خلال الـ أيام الأخيرة</h3>
                </div>

                {/* Real SVG Area / Line Chart matching the mockup wave */}
                <div className="relative h-56 w-full pt-4">
                  <svg viewBox="0 0 600 200" className="w-full h-full overflow-visible">
                    <defs>
                      <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.4" />
                        <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.0" />
                      </linearGradient>
                    </defs>

                    {/* Grid lines */}
                    <line x1="40" y1="30" x2="580" y2="30" stroke="#334155" strokeDasharray="3 3" opacity="0.5" />
                    <line x1="40" y1="80" x2="580" y2="80" stroke="#334155" strokeDasharray="3 3" opacity="0.5" />
                    <line x1="40" y1="130" x2="580" y2="130" stroke="#334155" strokeDasharray="3 3" opacity="0.5" />
                    <line x1="40" y1="180" x2="580" y2="180" stroke="#334155" opacity="0.8" />

                    {/* Y-Axis Labels */}
                    <text x="25" y="35" fill="#64748b" fontSize="10" fontFamily="sans-serif">10K</text>
                    <text x="25" y="85" fill="#64748b" fontSize="10" fontFamily="sans-serif">8K</text>
                    <text x="25" y="135" fill="#64748b" fontSize="10" fontFamily="sans-serif">4K</text>
                    <text x="25" y="185" fill="#64748b" fontSize="10" fontFamily="sans-serif">0</text>

                    {/* Area under wave */}
                    <path
                      d="M 60 150 Q 140 30 220 140 T 380 70 T 540 50 L 540 180 L 60 180 Z"
                      fill="url(#chartGradient)"
                    />

                    {/* Wave Path */}
                    <path
                      d="M 60 150 Q 140 30 220 140 T 380 70 T 540 50"
                      fill="none"
                      stroke="#3b82f6"
                      strokeWidth="3.5"
                      strokeLinecap="round"
                    />

                    {/* Data Points */}
                    <circle cx="60" cy="150" r="4.5" fill="#3b82f6" stroke="#0f172a" strokeWidth="2" />
                    <circle cx="140" cy="65" r="4.5" fill="#60a5fa" stroke="#0f172a" strokeWidth="2" />
                    <circle cx="220" cy="140" r="4.5" fill="#3b82f6" stroke="#0f172a" strokeWidth="2" />
                    <circle cx="300" cy="110" r="4.5" fill="#60a5fa" stroke="#0f172a" strokeWidth="2" />
                    <circle cx="380" cy="70" r="4.5" fill="#3b82f6" stroke="#0f172a" strokeWidth="2" />
                    <circle cx="460" cy="80" r="4.5" fill="#60a5fa" stroke="#0f172a" strokeWidth="2" />
                    <circle cx="540" cy="50" r="5.5" fill="#38bdf8" stroke="#0f172a" strokeWidth="2" />
                  </svg>

                  {/* X-Axis dates */}
                  <div className="flex justify-between items-center text-[10px] text-slate-500 font-bold px-8 pt-1">
                    <span>17 مايو</span>
                    <span>18 مايو</span>
                    <span>19 مايو</span>
                    <span>20 مايو</span>
                    <span>21 مايو</span>
                    <span>22 مايو</span>
                    <span>23 مايو</span>
                  </div>
                </div>
              </div>

              {/* Donut Chart: الكتب حسب الأقسام matching the screenshot */}
              <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-md space-y-4">
                <h3 className="text-sm font-black text-white text-right">الكتب حسب الأقسام</h3>

                <div className="flex items-center justify-center py-2">
                  <div className="relative w-36 h-36">
                    <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                      {/* الرياضيات (25% - Blue) */}
                      <circle cx="50" cy="50" r="38" fill="none" stroke="#3b82f6" strokeWidth="18" strokeDasharray="60 180" strokeDashoffset="0" />
                      {/* اللغة العربية (20% - Teal) */}
                      <circle cx="50" cy="50" r="38" fill="none" stroke="#14b8a6" strokeWidth="18" strokeDasharray="48 192" strokeDashoffset="-60" />
                      {/* اللغة الإنجليزية (18% - Amber) */}
                      <circle cx="50" cy="50" r="38" fill="none" stroke="#f59e0b" strokeWidth="18" strokeDasharray="43 197" strokeDashoffset="-108" />
                      {/* العلوم (15% - Green) */}
                      <circle cx="50" cy="50" r="38" fill="none" stroke="#10b981" strokeWidth="18" strokeDasharray="36 204" strokeDashoffset="-151" />
                      {/* الفيزياء (10% - Sky) */}
                      <circle cx="50" cy="50" r="38" fill="none" stroke="#0ea5e9" strokeWidth="18" strokeDasharray="24 216" strokeDashoffset="-187" />
                      {/* أخرى (12% - Slate) */}
                      <circle cx="50" cy="50" r="38" fill="none" stroke="#64748b" strokeWidth="18" strokeDasharray="29 211" strokeDashoffset="-211" />
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span className="text-xs font-black text-white font-mono">100%</span>
                      <span className="text-[9px] text-slate-400">التوزيع</span>
                    </div>
                  </div>
                </div>

                {/* Legend list matching screenshot */}
                <div className="space-y-1.5 text-xs">
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="font-mono font-bold text-blue-400">25%</span>
                    <span className="flex items-center gap-1.5">
                      <span>الرياضيات</span>
                      <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="font-mono font-bold text-teal-400">20%</span>
                    <span className="flex items-center gap-1.5">
                      <span>اللغة العربية</span>
                      <span className="w-2.5 h-2.5 rounded-full bg-teal-500"></span>
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="font-mono font-bold text-amber-400">18%</span>
                    <span className="flex items-center gap-1.5">
                      <span>اللغة الإنكليزية</span>
                      <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="font-mono font-bold text-emerald-400">15%</span>
                    <span className="flex items-center gap-1.5">
                      <span>العلوم</span>
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="font-mono font-bold text-sky-400">10%</span>
                    <span className="flex items-center gap-1.5">
                      <span>الفيزياء</span>
                      <span className="w-2.5 h-2.5 rounded-full bg-sky-500"></span>
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="font-mono font-bold text-slate-400">12%</span>
                    <span className="flex items-center gap-1.5">
                      <span>أخرى</span>
                      <span className="w-2.5 h-2.5 rounded-full bg-slate-500"></span>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Row 3: Bottom Analytics & Top Downloaded Books & User Ratings */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Latest Added Books */}
              <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-md space-y-4">
                <div className="flex items-center justify-between">
                  <button
                    onClick={() => setActiveTab('books')}
                    className="text-[11px] text-blue-400 hover:text-blue-300 font-bold cursor-pointer"
                  >
                    عرض الكل
                  </button>
                  <h3 className="text-sm font-black text-white">أحدث الكتب المضافة</h3>
                </div>

                <div className="space-y-3">
                  {[
                    { title: 'الكيمياء - الثالث متوسط', time: '2026 منذ ساعة', cat: 'كيمياء' },
                    { title: 'الفيزياء - الثالث متوسط', time: '2026 منذ ساعتين', cat: 'فيزياء' },
                    { title: 'الأحياء - الثالث متوسط', time: '2026 منذ يومين', cat: 'أحياء' },
                    { title: 'اللغة الإنجليزية - الثالث متوسط', time: '2026 منذ 3 أيام', cat: 'إنكليزي' },
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between p-2.5 rounded-2xl bg-slate-800/60 border border-slate-700/50">
                      <span className="text-[10px] text-slate-400 font-mono">{item.time}</span>
                      <div className="flex items-center gap-2.5 text-right">
                        <div>
                          <h4 className="text-xs font-black text-white">{item.title}</h4>
                          <span className="text-[10px] text-blue-400">{item.cat}</span>
                        </div>
                        <div className="w-8 h-10 rounded-lg bg-blue-900/60 border border-blue-600/30 flex items-center justify-center text-[8px] font-black text-cyan-300">
                          PDF
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* الكتب الأكثر تحميلاً (Horizontal Ranking Bars) */}
              <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-md space-y-4">
                <h3 className="text-sm font-black text-white text-right">الكتب الأكثر تحميلاً</h3>

                <div className="space-y-3.5 pt-1">
                  {[
                    { name: 'الرياضيات - الثالث متوسط', count: '16,250', pct: '95%', color: 'bg-blue-500' },
                    { name: 'اللغة العربية - الثالث متوسط', count: '12,980', pct: '80%', color: 'bg-teal-500' },
                    { name: 'اللغة الإنجليزية - الثالث متوسط', count: '10,220', pct: '65%', color: 'bg-amber-500' },
                    { name: 'العلوم - الثالث متوسط', count: '8,910', pct: '50%', color: 'bg-emerald-500' },
                  ].map((item, idx) => (
                    <div key={idx} className="space-y-1 text-right">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-mono text-slate-300 font-bold">{item.count}</span>
                        <span className="font-bold text-white">{item.name}</span>
                      </div>
                      <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
                        <div className={`h-full ${item.color} rounded-full`} style={{ width: item.pct }}></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* التقييمات الحديثة (User Reviews) */}
              <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-md space-y-4">
                <h3 className="text-sm font-black text-white text-right">التقييمات والمراجعات</h3>

                <div className="space-y-3">
                  {[
                    { name: 'محمد علي', role: 'الرياضيات - الثالث متوسط', stars: 5, tag: 'طالب متفوق' },
                    { name: 'سارة حسين', role: 'العلوم - الثالث متوسط', stars: 5, tag: 'طالبة' },
                    { name: 'أحمد مصطفى', role: 'اللغة العربية - الثالث متوسط', stars: 5, tag: 'طالب' },
                  ].map((rev, idx) => (
                    <div key={idx} className="flex items-center justify-between p-2.5 rounded-2xl bg-slate-800/60 border border-slate-700/50">
                      <div className="flex items-center gap-0.5 text-amber-400">
                        {[...Array(rev.stars)].map((_, i) => (
                          <Star key={i} className="w-3 h-3 fill-amber-400" />
                        ))}
                      </div>

                      <div className="text-right">
                        <h4 className="text-xs font-black text-white">{rev.name}</h4>
                        <span className="text-[10px] text-slate-400 block">{rev.role}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: BOOKS MANAGEMENT */}
        {activeTab === 'books' && (
          <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-md space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveTab('add-book')}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>إضافة كتاب جديد</span>
                </button>
              </div>

              <div className="relative max-w-xs w-full">
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="بحث في الكتب..."
                  className="w-full bg-slate-800 text-white text-xs rounded-xl py-2 px-3 pr-8 border border-slate-700 focus:outline-none focus:border-blue-500 text-right"
                />
                <Search className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-2.5" />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 font-bold">
                    <th className="py-3 px-2">الإجراءات</th>
                    <th className="py-3 px-2">التحميلات</th>
                    <th className="py-3 px-2">التقييم</th>
                    <th className="py-3 px-2">الصفحة / الحجم</th>
                    <th className="py-3 px-2">المرحلة</th>
                    <th className="py-3 px-2">القسم</th>
                    <th className="py-3 px-2">عنوان الكتاب</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80">
                  {books
                    .filter((b) => !searchTerm || b.title.includes(searchTerm) || b.category.includes(searchTerm))
                    .map((book) => (
                      <tr key={book.id} className="hover:bg-slate-800/50 transition-colors">
                        <td className="py-3 px-2 flex items-center gap-1.5">
                          <button
                            onClick={() => openBookEditorForBook(book)}
                            className="p-1.5 bg-amber-500/20 text-amber-300 rounded-lg hover:bg-amber-500/30 border border-amber-500/30"
                            title="تعديل المادة وإرفاق PDF (المشرف)"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              setActiveBookDetails(book);
                              setActiveReadingBook(book);
                            }}
                            className="p-1.5 bg-blue-500/20 text-blue-400 rounded-lg hover:bg-blue-500/30"
                            title="قراءة الكتاب"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => deleteBook(book.id)}
                            className="p-1.5 bg-rose-500/20 text-rose-400 rounded-lg hover:bg-rose-500/30"
                            title="حذف الكتاب"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                        <td className="py-3 px-2 font-mono text-slate-300 font-bold">{book.downloadsCount}</td>
                        <td className="py-3 px-2 text-amber-400 font-bold">★ {book.rating}</td>
                        <td className="py-3 px-2 text-slate-400 font-mono">{book.pagesCount} ص • {book.fileSize}</td>
                        <td className="py-3 px-2 font-bold text-slate-300">{book.grade}</td>
                        <td className="py-3 px-2">
                          <span className="px-2 py-0.5 rounded-md bg-blue-900/60 text-blue-300 text-[10px] font-bold border border-blue-500/30">
                            {book.category}
                          </span>
                        </td>
                        <td className="py-3 px-2 font-black text-white">{book.title}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB: ACTIVATION CODES MANAGEMENT (طلب المستخدم الخاص بالادمن) */}
        {activeTab === 'activation-codes' && (
          <div className="space-y-6">
            {/* Quick Generator Box */}
            <div className="p-6 rounded-3xl bg-slate-900/95 border border-slate-800 shadow-xl space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 rounded-xl bg-amber-500/20 text-amber-400">
                      <KeyRound className="w-5 h-5" />
                    </span>
                    <h2 className="text-base font-black text-white">
                      توليد كود تفعيل جديد للطالب بعد الاشتراك (10,000 د.ع)
                    </h2>
                  </div>
                  <p className="text-xs text-slate-400">
                    أنشئ كود اشتراك معتمد لمادة معينة أو لجميع المواد وشاركه مع الطالب عبر الواتساب فور استلام الحوالة
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => unlockBookDirectly('all')}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Unlock className="w-3.5 h-3.5" />
                    <span>فتح كل المواد تجريبياً</span>
                  </button>
                  <button
                    onClick={() => lockAllBooks()}
                    className="px-3 py-1.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Lock className="w-3.5 h-3.5" />
                    <span>قفل كل المواد 🔒</span>
                  </button>
                </div>
              </div>

              {/* Generator Form */}
              <form onSubmit={handleGenerateCode} className="grid grid-cols-1 sm:grid-cols-4 gap-3.5">
                <div>
                  <label className="text-[11px] font-bold text-slate-400 block mb-1">المادة المطلوب تفعيلها:</label>
                  <select
                    value={selectedBookForCode}
                    onChange={(e) => setSelectedBookForCode(e.target.value)}
                    className="w-full bg-slate-800 text-white text-xs rounded-xl p-3 border border-slate-700 focus:outline-none focus:border-amber-500 text-right"
                  >
                    <option value="all">⭐ تفعيل شامل (جميع المناهج والمواد)</option>
                    {books.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.title} (10,000 د.ع)
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-400 block mb-1">اسم الطالب:</label>
                  <input
                    type="text"
                    value={studentNameToCode}
                    onChange={(e) => setStudentNameToCode(e.target.value)}
                    placeholder="مثال: سجاد حيدر"
                    className="w-full bg-slate-800 text-white text-xs rounded-xl p-3 border border-slate-700 focus:outline-none focus:border-amber-500 text-right"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-400 block mb-1">رقم هاتف الطالب / الواتساب:</label>
                  <input
                    type="tel"
                    value={studentPhoneToCode}
                    onChange={(e) => setStudentPhoneToCode(e.target.value)}
                    placeholder="07734378998"
                    className="w-full bg-slate-800 text-white text-xs rounded-xl p-3 border border-slate-700 focus:outline-none focus:border-amber-500 text-right font-mono"
                  />
                </div>

                <div className="flex items-end">
                  <button
                    type="submit"
                    className="w-full py-3 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-white text-xs font-black rounded-xl shadow-lg shadow-amber-500/25 flex items-center justify-center gap-2 cursor-pointer transition-transform active:scale-95"
                  >
                    <KeyRound className="w-4 h-4" />
                    <span>توليد الكود فوراً 🔑</span>
                  </button>
                </div>
              </form>
            </div>

            {/* Activation Codes Table */}
            <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-md space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400">
                  إجمالي الأكواد: <b className="text-white font-mono">{activationCodes.length}</b>
                </span>
                <h3 className="text-sm font-black text-white">سجل أكواد التفعيل المصدرة وحالتها</h3>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 font-bold">
                      <th className="py-3 px-2">الإجراءات والمشاركة</th>
                      <th className="py-3 px-2">الحالة</th>
                      <th className="py-3 px-2">تاريخ الإنشاء</th>
                      <th className="py-3 px-2">هاتف الطالب</th>
                      <th className="py-3 px-2">اسم الطالب</th>
                      <th className="py-3 px-2">المادة</th>
                      <th className="py-3 px-2 font-mono">كود التفعيل (Code)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80">
                    {activationCodes.map((item) => (
                      <tr key={item.id} className="hover:bg-slate-800/50 transition-colors">
                        <td className="py-3 px-2 flex items-center gap-2">
                          <button
                            onClick={() => handleCopyCode(item.code)}
                            className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg flex items-center gap-1 text-[11px] font-bold"
                            title="نسخ الكود"
                          >
                            {copiedCode === item.code ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                            <span>نسخ</span>
                          </button>

                          <button
                            onClick={() =>
                              handleSendViaWhatsApp(item.code, item.studentPhone || '07734378998', item.bookTitle)
                            }
                            className="px-2 py-1 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 rounded-lg flex items-center gap-1 text-[11px] font-bold"
                            title="إرسال للطالب واتساب"
                          >
                            <Send className="w-3.5 h-3.5" />
                            <span>واتساب</span>
                          </button>

                          <button
                            onClick={() => deleteActivationCode(item.id)}
                            className="p-1.5 text-rose-400 hover:bg-rose-500/20 rounded-lg"
                            title="حذف الكود"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>

                        <td className="py-3 px-2">
                          {item.isUsed ? (
                            <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 text-[10px] font-bold border border-slate-700">
                              تم التفعيل ({item.usedBy || 'طالب'})
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30 animate-pulse">
                              صالح وجاهز للاستخدام ✓
                            </span>
                          )}
                        </td>

                        <td className="py-3 px-2 text-slate-400 font-mono text-[11px]">{item.createdAt}</td>
                        <td className="py-3 px-2 font-mono text-slate-300" dir="ltr">
                          {item.studentPhone || '07734378998'}
                        </td>
                        <td className="py-3 px-2 font-bold text-white">{item.studentName || 'طالب'}</td>
                        <td className="py-3 px-2 text-blue-300 font-bold">{item.bookTitle}</td>
                        <td className="py-3 px-2">
                          <span className="px-2.5 py-1 rounded-lg bg-amber-500/15 text-amber-400 font-mono font-black text-xs border border-amber-500/30 select-all tracking-wide">
                            {item.code}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB: USERS & ORDERS */}
        {activeTab === 'users' && (
          <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-md space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-400">
                إجمالي الطلبات: <b className="text-white font-mono">{orders.length}</b>
              </span>
              <h3 className="text-sm font-black text-white">سجل طلبات الطلاب وتحويلات الأموال (10,000 د.ع)</h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 font-bold">
                    <th className="py-3 px-2">الإجراءات وتوليد الكود</th>
                    <th className="py-3 px-2">الحالة</th>
                    <th className="py-3 px-2">المبلغ</th>
                    <th className="py-3 px-2">رقم الحوالة / الوصل</th>
                    <th className="py-3 px-2">طريقة الدفع</th>
                    <th className="py-3 px-2">المادة المطلوبة</th>
                    <th className="py-3 px-2">الهاتف / المحافظة</th>
                    <th className="py-3 px-2">اسم الطالب</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80">
                  {orders.map((ord) => (
                    <tr key={ord.id} className="hover:bg-slate-800/50 transition-colors">
                      <td className="py-3 px-2 flex items-center gap-2">
                        {ord.status !== 'تم التفعيل والفتح' ? (
                          <button
                            onClick={() => approveOrder(ord.id)}
                            className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[11px] font-black flex items-center gap-1 cursor-pointer"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>موافقة وتوليد كود</span>
                          </button>
                        ) : (
                          <button
                            onClick={() =>
                              handleSendViaWhatsApp('TAL-2026-VIP', ord.phone, ord.book_title)
                            }
                            className="px-2 py-1 bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600/30 rounded-lg text-[11px] font-bold flex items-center gap-1"
                          >
                            <PhoneCall className="w-3.5 h-3.5" />
                            <span>مراسلة</span>
                          </button>
                        )}
                        <button
                          onClick={() => rejectOrder(ord.id)}
                          className="p-1.5 text-rose-400 hover:bg-rose-500/20 rounded-lg"
                          title="رفض"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>

                      <td className="py-3 px-2">
                        {ord.status === 'تم التفعيل والفتح' ? (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
                            مفعل ومؤكد ✓
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold border border-amber-500/30 animate-pulse">
                            قيد التحقق ⏳
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-2 font-black text-emerald-400 font-mono">{ord.price || '10,000 د.ع'}</td>
                      <td className="py-3 px-2 font-mono text-cyan-300 text-[11px]">{ord.transaction_ref}</td>
                      <td className="py-3 px-2 font-bold text-slate-300">{ord.payment_method}</td>
                      <td className="py-3 px-2 text-white font-bold">{ord.book_title}</td>
                      <td className="py-3 px-2 text-slate-300">
                        <span className="font-mono block" dir="ltr">
                          {ord.phone}
                        </span>
                        <span className="text-[10px] text-slate-400">{ord.governorate}</span>
                      </td>
                      <td className="py-3 px-2 font-black text-white">{ord.student_name}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 3: ADD NEW BOOK */}
        {activeTab === 'add-book' && (
          <div className="max-w-2xl mx-auto p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-6">
            <div className="space-y-1 text-right">
              <h2 className="text-lg font-black text-white">إضافة كتاب أو منهج دراسي جديد</h2>
              <p className="text-xs text-slate-400">املأ بيانات الكتاب ليتم إضافته للمنصة وتحميله فوراً</p>
            </div>

            <form onSubmit={handleAddBookSubmit} className="space-y-4 text-right">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300 block">عنوان الكتاب الكامل</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="مثال: الرياضيات - الثالث متوسط (الجزء الثاني)"
                  className="w-full bg-slate-800 text-white text-xs rounded-xl p-3 border border-slate-700 focus:outline-none focus:border-blue-500 text-right"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300 block">القسم / المادة</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as SubjectCategory)}
                    className="w-full bg-slate-800 text-white text-xs rounded-xl p-3 border border-slate-700 focus:outline-none focus:border-blue-500 text-right"
                  >
                    <option value="الرياضيات">الرياضيات</option>
                    <option value="اللغة العربية">اللغة العربية</option>
                    <option value="اللغة الإنجليزية">اللغة الإنجليزية</option>
                    <option value="العلوم">العلوم</option>
                    <option value="الاجتماعيات">الاجتماعيات</option>
                    <option value="الكيمياء">الكيمياء</option>
                    <option value="الفيزياء">الفيزياء</option>
                    <option value="الأحياء">الأحياء</option>
                    <option value="التربية الإسلامية">التربية الإسلامية</option>
                    <option value="الحاسوب">الحاسوب</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300 block">الصف الدراسي</label>
                  <select
                    value={newGrade}
                    onChange={(e) => setNewGrade(e.target.value as EducationalStage)}
                    className="w-full bg-slate-800 text-white text-xs rounded-xl p-3 border border-slate-700 focus:outline-none focus:border-blue-500 text-right"
                  >
                    <option value="الثالث متوسط">الثالث متوسط</option>
                    <option value="السادس إعدادي">السادس إعدادي</option>
                    <option value="السادس علمي">السادس علمي</option>
                    <option value="السادس أدبي">السادس أدبي</option>
                    <option value="الرابع إعدادي">الرابع إعدادي</option>
                    <option value="الخامس إعدادي">الخامس إعدادي</option>
                    <option value="الأول متوسط">الأول متوسط</option>
                    <option value="الثاني متوسط">الثاني متوسط</option>
                    <option value="الابتدائية">الابتدائية</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300 block">سنة الطبعة</label>
                  <input
                    type="text"
                    value={newYear}
                    onChange={(e) => setNewYear(e.target.value)}
                    className="w-full bg-slate-800 text-white text-xs rounded-xl p-3 border border-slate-700 text-center font-mono"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300 block">عدد الصفحات</label>
                  <input
                    type="number"
                    value={newPages}
                    onChange={(e) => setNewPages(Number(e.target.value))}
                    className="w-full bg-slate-800 text-white text-xs rounded-xl p-3 border border-slate-700 text-center font-mono"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300 block">حجم الملف</label>
                  <input
                    type="text"
                    value={newFileSize}
                    onChange={(e) => setNewFileSize(e.target.value)}
                    className="w-full bg-slate-800 text-white text-xs rounded-xl p-3 border border-slate-700 text-center font-mono"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300 block">الوصف والملاحظات</label>
                <textarea
                  rows={3}
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="وصف مختصر لمحتوى الكتاب والمواضيع الوزارية..."
                  className="w-full bg-slate-800 text-white text-xs rounded-xl p-3 border border-slate-700 focus:outline-none focus:border-blue-500 text-right"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-black rounded-xl shadow-lg shadow-blue-600/30 transition-transform active:scale-98 cursor-pointer flex items-center justify-center gap-2"
              >
                <PlusCircle className="w-4 h-4" />
                <span>حفظ ونشر الكتاب في المنصة</span>
              </button>
            </form>
          </div>
        )}

        {/* TAB 4: BACKUP & EXPORT */}
        {activeTab === 'backup' && (
          <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-md space-y-6 max-w-xl mx-auto text-center">
            <div className="w-16 h-16 rounded-2xl bg-blue-600/20 text-blue-400 flex items-center justify-center mx-auto border border-blue-500/30">
              <Database className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h3 className="text-lg font-black text-white">النسخ الاحتياطي وتصدير البيانات</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                يمكنك تصدير كافة بيانات الكتب والمناهج وحسابات الطلاب كملف JSON لضمان حفظ البيانات واسترجاعها في أي وقت.
              </p>
            </div>

            <button
              onClick={handleExportBackup}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white text-xs font-black rounded-xl shadow-lg shadow-blue-600/30 inline-flex items-center gap-2 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>تنزيل ملف النسخة الاحتياطية (JSON)</span>
            </button>
          </div>
        )}
      </main>
    </div>
  );
};
