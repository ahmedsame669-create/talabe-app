import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import confetti from 'canvas-confetti';
import {
  X,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Sparkles,
  CreditCard,
  Smartphone,
  CheckCircle2,
  BookOpen,
  PenTool,
  Lock,
  Unlock,
  GraduationCap,
  ArrowRight,
  ArrowLeft,
  Tv,
  HelpCircle,
  Zap,
  ShieldCheck,
  Award,
  ChevronRight,
  Eye,
  FastForward
} from 'lucide-react';

interface SceneStep {
  id: number;
  title: string;
  timeRange: string;
  duration: number; // in seconds
  voiceNarration: string;
  badge: string;
  bulletPoints: string[];
}

const TUTORIAL_SCENES: SceneStep[] = [
  {
    id: 1,
    title: 'الخطوة الأولى: اختيار المرحلة ومعاينة المرشحات مجاناً',
    timeRange: '0:00 - 0:15',
    duration: 15,
    voiceNarration: 'أهلاً بكم في منصة طلبتي! اختر مرحلتك الدراسية مثل الثالث متوسط أو السادس علمي، وتصفح ملخص الثوابت والتعاليل المقلصة مجاناً.',
    badge: '١. تصفح ومعاينة',
    bulletPoints: [
      'تحديد الصف الدراسي (ثالث متوسط، سادس علمي، أدبي، مهني، ابتدائي)',
      'الاطلاع على نموذج الأسئلة والتعاليل الذهبية عبر زر (معاينة مجانية)',
      'التأكد من تقليص الحشو والتركيز على ثوابت الامتحان الوزاري'
    ]
  },
  {
    id: 2,
    title: 'الخطوة الثانية: اختيار وسيلة الدفع (ماستر كارد أو زين كاش)',
    timeRange: '0:15 - 0:30',
    duration: 15,
    voiceNarration: 'اضغط على زر (فتح الملزمة 10 آلاف د.ع)، واختر الدفع المباشر عبر ماستر كارد الرافدين (الكي كارد) أو تحويل محفظة زين كاش.',
    badge: '٢. وسيلة الدفع',
    bulletPoints: [
      'سعر موحد وشامل (10,000 دينار عراقي فقط)',
      'دفع إلكتروني مباشر عبر بطاقة ماستر كارد الرافدين',
      'إمكانية التحويل المباشر لمحفظة زين كاش (07700000000)'
    ]
  },
  {
    id: 3,
    title: 'الخطوة الثالثة: إدخال معلومات الدفع والتأكيد الآمن',
    timeRange: '0:30 - 0:45',
    duration: 15,
    voiceNarration: 'أدخل رقم بطاقتك وتاريخ الانتهاء والرمز السري CVV، ثم اضغط على زر التفعيل الفوري المشفر بنظام مصرف الرافدين.',
    badge: '٣. الدفع الفوري',
    bulletPoints: [
      'كتابة اسم الطالب ورقم البطاقة (16 رقم)',
      'إدخال تاريخ الانتهاء والرمز السري 3 أرقام (CVV)',
      'بوابة دفع مؤمنة ومشفرة 100% بدون أي وسيط'
    ]
  },
  {
    id: 4,
    title: 'الخطوة الرابعة: التفعيل التلقائي الفوري وامتحان نفسي',
    timeRange: '0:45 - 1:00',
    duration: 15,
    voiceNarration: 'مبروك! تُفتح المادة تلقائياً فوراً بدون انتظار. يمكنك تصفح كافة الصفحات وخوض اختبار (امتحن نفسي ✍️) وتقييم درجتك.',
    badge: '٤. فتح فوري واختبار',
    bulletPoints: [
      'فتح الملزمة وتخزينها في حسابك وخزانة كتبك المفعلة',
      'تصفح كافة الأسئلة والحلول النموذجية والطباعة PDF',
      'خوض اختبار تفاعلي فوري (امتحن نفسي ✍️) للحصول على درجتك وتوضيح مركز الفحص'
    ]
  }
];

export const VideoTutorialModal: React.FC = () => {
  const { activeModal, closeModal, openPayModalForBook, books } = useApp();
  
  const [currentSceneIdx, setCurrentSceneIdx] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [progressSec, setProgressSec] = useState<number>(0); // Total 0 - 60
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [simulatedTap, setSimulatedTap] = useState<{ x: number; y: number; visible: boolean }>({ x: 50, y: 50, visible: false });

  const totalDuration = 60; // 60 seconds total

  // Playback timer loop
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (activeModal === 'video-tutorial' && isPlaying) {
      interval = setInterval(() => {
        setProgressSec((prev) => {
          const next = prev + 0.25 * playbackSpeed;
          if (next >= totalDuration) {
            setIsPlaying(false);
            return totalDuration;
          }
          return next;
        });
      }, 250);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [activeModal, isPlaying, playbackSpeed]);

  // Determine current scene based on progressSec
  useEffect(() => {
    const sceneIndex = Math.min(3, Math.floor(progressSec / 15));
    if (sceneIndex !== currentSceneIdx) {
      setCurrentSceneIdx(sceneIndex);
      // Trigger tap animation when scene changes
      triggerSimulatedTap(sceneIndex);
    }
  }, [progressSec, currentSceneIdx]);

  // Trigger simulated finger tap animation
  const triggerSimulatedTap = (sceneIdx: number) => {
    const positions = [
      { x: 75, y: 35 }, // Scene 1: Tab click
      { x: 30, y: 65 }, // Scene 2: Pay button click
      { x: 50, y: 82 }, // Scene 3: Confirm payment click
      { x: 50, y: 60 }, // Scene 4: Quiz button click
    ];
    const pos = positions[sceneIdx] || { x: 50, y: 50 };
    setSimulatedTap({ x: pos.x, y: pos.y, visible: true });
    setTimeout(() => {
      setSimulatedTap((prev) => ({ ...prev, visible: false }));
    }, 1200);
  };

  // Reset when opening
  useEffect(() => {
    if (activeModal === 'video-tutorial') {
      setProgressSec(0);
      setCurrentSceneIdx(0);
      setIsPlaying(true);
      triggerSimulatedTap(0);
    }
  }, [activeModal]);

  if (activeModal !== 'video-tutorial') return null;

  const currentScene = TUTORIAL_SCENES[currentSceneIdx];

  const handleSeek = (newProgress: number) => {
    setProgressSec(newProgress);
    const newIdx = Math.min(3, Math.floor(newProgress / 15));
    setCurrentSceneIdx(newIdx);
    triggerSimulatedTap(newIdx);
  };

  const handleJumpToScene = (idx: number) => {
    handleSeek(idx * 15);
  };

  const handleTogglePlay = () => {
    if (progressSec >= totalDuration) {
      setProgressSec(0);
      setCurrentSceneIdx(0);
      setIsPlaying(true);
    } else {
      setIsPlaying(!isPlaying);
    }
  };

  const handleRestart = () => {
    setProgressSec(0);
    setCurrentSceneIdx(0);
    setIsPlaying(true);
    triggerSimulatedTap(0);
  };

  const handleSpeedToggle = () => {
    const speeds = [1, 1.25, 1.5];
    const nextIdx = (speeds.indexOf(playbackSpeed) + 1) % speeds.length;
    setPlaybackSpeed(speeds[nextIdx]);
  };

  const handleStartSubscribing = () => {
    closeModal();
    const firstBook = books[0];
    if (firstBook) {
      openPayModalForBook(firstBook);
    } else {
      const el = document.getElementById('books-section');
      el?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Format time (MM:SS)
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-slate-900 rounded-3xl shadow-2xl border border-indigo-900/60 overflow-hidden my-4 sm:my-8 text-white">
        {/* Header Bar */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-950 via-indigo-950 to-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-600/30">
              <Tv className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 text-[10px] font-black border border-rose-500/30 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                  فيديو تعليمي تفاعلي (60 ثانية)
                </span>
                <span className="text-xs text-amber-300 font-bold hidden sm:inline">
                  دليل الاشتراك والدفع الفوري
                </span>
              </div>
              <h2 className="text-sm sm:text-base font-black text-white">
                كيفية الاشتراك بالمواد وتفعيل المرشحات الوزارية عبر منصة طلبتي
              </h2>
            </div>
          </div>

          <button
            onClick={closeModal}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Player & Stage Area */}
        <div className="p-4 sm:p-6 space-y-4">
          {/* Main Simulated Screen */}
          <div className="relative aspect-video max-h-[380px] w-full rounded-2xl sm:rounded-3xl bg-slate-950 border border-slate-800 shadow-2xl overflow-hidden flex flex-col justify-between select-none">
            {/* Top Simulated App Bar */}
            <div className="px-4 py-2 bg-slate-900/90 border-b border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
                </div>
                <span className="text-[11px] font-mono text-slate-300">talabati.iq/subscribe</span>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-md">
                  {currentScene.badge}
                </span>
                <span className="text-[11px] font-mono font-bold text-amber-400">
                  {formatTime(progressSec)} / 1:00
                </span>
              </div>
            </div>

            {/* Video Scene Graphic Representation */}
            <div className="relative flex-1 p-4 sm:p-6 flex items-center justify-center overflow-hidden">
              {/* Scene 1: Subject Selection & Preview */}
              {currentSceneIdx === 0 && (
                <div className="w-full max-w-lg space-y-3 text-center animate-in fade-in zoom-in-95 duration-300">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-bold border border-indigo-500/30">
                    <GraduationCap className="w-4 h-4" />
                    <span>المرحلة 1: تصفح المرشحات والصفوف</span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div className="p-3 rounded-2xl bg-indigo-600 text-white font-black shadow-lg shadow-indigo-600/30 scale-105 border border-indigo-400">
                      الثالث المتوسط 🏆
                      <span className="block text-[9px] text-amber-200 mt-1 font-normal">ضمان 60-85 درجة</span>
                    </div>
                    <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-slate-400 font-bold">
                      السادس العلمي ⚡
                      <span className="block text-[9px] text-slate-500 mt-1 font-normal">ضمان 100 درجة</span>
                    </div>
                    <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-slate-400 font-bold">
                      السادس الأدبي 📖
                      <span className="block text-[9px] text-slate-500 mt-1 font-normal">ضمان 100 درجة</span>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-between text-right">
                    <div>
                      <h4 className="text-xs sm:text-sm font-black text-white">مرشحات وثوابت الاجتماعيات والرياضيات</h4>
                      <p className="text-[10px] text-slate-400">تقليص التعاليل بنقاط ذهبية مركزة</p>
                    </div>
                    <span className="px-2.5 py-1 rounded-xl bg-indigo-500/20 text-indigo-300 text-[11px] font-bold flex items-center gap-1">
                      <Eye className="w-3.5 h-3.5" />
                      <span>معاينة مجانية</span>
                    </span>
                  </div>
                </div>
              )}

              {/* Scene 2: Selecting Payment Method */}
              {currentSceneIdx === 1 && (
                <div className="w-full max-w-lg space-y-3 text-center animate-in fade-in zoom-in-95 duration-300">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-bold border border-amber-500/30">
                    <CreditCard className="w-4 h-4" />
                    <span>المرحلة 2: اختيار طريقة الدفع المباشر</span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-indigo-950/40 border border-indigo-500/40 text-center">
                    <span className="text-[11px] text-slate-300">سعر الفتح والتفعيل الشامل:</span>
                    <div className="text-xl sm:text-2xl font-black text-amber-400 font-mono">10,000 دينار عراقي</div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="p-3.5 rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-black shadow-lg border border-indigo-400 flex items-center justify-center gap-2">
                      <CreditCard className="w-4 h-4 text-amber-300" />
                      <span>ماستر كارد الرافدين 💳</span>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-slate-300 font-bold flex items-center justify-center gap-2">
                      <Smartphone className="w-4 h-4 text-pink-400" />
                      <span>زين كاش (تحويل مباشر) 📱</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Scene 3: Card Details Input & Verification */}
              {currentSceneIdx === 2 && (
                <div className="w-full max-w-lg space-y-3 animate-in fade-in zoom-in-95 duration-300">
                  <div className="p-3 rounded-2xl bg-gradient-to-tr from-slate-950 to-indigo-950 border border-amber-500/30 text-white flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-lg bg-amber-400/20 border border-amber-400/40 flex items-center justify-center font-black text-[10px] text-amber-300">
                        QI
                      </div>
                      <span className="text-xs font-black text-amber-200">مصرف الرافدين • ماستر كارد</span>
                    </div>
                    <span className="font-mono text-xs text-slate-300 tracking-widest">5200 •••• •••• 4892</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300">
                      <span className="block text-[9px] text-slate-500">اسم الطالب:</span>
                      <span className="font-bold text-white">علي كرار الساعدي</span>
                    </div>
                    <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 text-left">
                      <span className="block text-[9px] text-slate-500">ينتهي في:</span>
                      <span className="font-bold text-white font-mono">08/28</span>
                    </div>
                  </div>

                  <div className="p-3 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 text-white text-xs font-black text-center shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-300" />
                    <span>تأكيد الدفع (10,000 د.ع) وتفعيل الملزمة فوراً 🚀</span>
                  </div>
                </div>
              )}

              {/* Scene 4: Instant Unlock & Quiz Test */}
              {currentSceneIdx === 3 && (
                <div className="w-full max-w-lg space-y-3 text-center animate-in fade-in zoom-in-95 duration-300">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto ring-4 ring-emerald-500/10">
                    <CheckCircle2 className="w-7 h-7" />
                  </div>

                  <h3 className="text-sm sm:text-base font-black text-emerald-400">
                    ✓ تم الفتح والتفعيل الفوري بنجاح!
                  </h3>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="p-3 rounded-2xl bg-emerald-600 text-white font-black flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/30">
                      <BookOpen className="w-4 h-4" />
                      <span>تصفح الملزمة كاملة</span>
                    </div>

                    <div className="p-3 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-black flex items-center justify-center gap-1.5 shadow-md shadow-purple-600/30 animate-pulse">
                      <PenTool className="w-4 h-4 text-amber-300" />
                      <span>امتحن نفسي ✍️</span>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-400">
                    أصبح بإمكانك القراءة وطباعة المادة واختبار نفسك في أي وقت من جهازك!
                  </p>
                </div>
              )}

              {/* Simulated Interactive Tap Indicator */}
              {simulatedTap.visible && (
                <div
                  className="absolute pointer-events-none transition-all duration-500 z-30 -translate-x-1/2 -translate-y-1/2"
                  style={{ left: `${simulatedTap.x}%`, top: `${simulatedTap.y}%` }}
                >
                  <div className="relative">
                    <span className="w-10 h-10 rounded-full bg-indigo-500/40 border-2 border-indigo-400 animate-ping absolute -top-5 -left-5" />
                    <div className="w-7 h-7 rounded-full bg-indigo-500 text-white flex items-center justify-center shadow-lg border-2 border-white text-xs font-black">
                      👆
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Subtitles / Narration Banner */}
            <div className="p-3 bg-slate-900/95 border-t border-slate-800 text-xs sm:text-sm text-amber-200 font-medium flex items-center justify-between gap-3">
              <div className="flex items-center gap-2 overflow-hidden">
                <Sparkles className="w-4 h-4 text-amber-400 shrink-0 animate-pulse" />
                <p className="truncate">
                  {currentScene.voiceNarration}
                </p>
              </div>

              <span className="text-[10px] text-slate-400 shrink-0 font-mono">
                {currentScene.timeRange}
              </span>
            </div>
          </div>

          {/* Video Controls Toolbar */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
            {/* Timeline Progress Bar Scrubber */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
                <span>{formatTime(progressSec)}</span>
                <span className="text-slate-300 font-bold">{currentScene.title}</span>
                <span>1:00</span>
              </div>

              <div
                onClick={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const clickX = e.clientX - rect.left;
                  const ratio = Math.max(0, Math.min(1, clickX / rect.width));
                  handleSeek(ratio * totalDuration);
                }}
                className="w-full h-2.5 bg-slate-800 hover:bg-slate-700 rounded-full overflow-hidden cursor-pointer relative"
              >
                <div
                  className="h-full bg-gradient-to-r from-rose-500 via-indigo-500 to-emerald-500 transition-all duration-150 rounded-full"
                  style={{ width: `${(progressSec / totalDuration) * 100}%` }}
                />
              </div>
            </div>

            {/* Control Buttons */}
            <div className="flex items-center justify-between flex-wrap gap-2 pt-1">
              <div className="flex items-center gap-2">
                <button
                  onClick={handleTogglePlay}
                  className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white transition-transform active:scale-95 cursor-pointer flex items-center gap-1.5 text-xs font-black shadow-md shadow-indigo-600/30"
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  <span>{isPlaying ? 'إيقاف مؤقت' : 'تشغيل الفيديو'}</span>
                </button>

                <button
                  onClick={handleRestart}
                  className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                  title="إعادة من البداية"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>

                <button
                  onClick={handleSpeedToggle}
                  className="px-2.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono font-bold transition-colors cursor-pointer"
                  title="سرعة التشغيل"
                >
                  {playbackSpeed}x
                </button>
              </div>

              {/* Scene Jump Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto text-xs">
                {TUTORIAL_SCENES.map((scene, idx) => (
                  <button
                    key={scene.id}
                    onClick={() => handleJumpToScene(idx)}
                    className={`px-3 py-1.5 rounded-xl text-[11px] font-black transition-all cursor-pointer whitespace-nowrap ${
                      currentSceneIdx === idx
                        ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 shadow-sm'
                        : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                    }`}
                  >
                    {idx + 1}. {scene.badge.replace(/^\d+\.\s*/, '')}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* 4 Step Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
            {TUTORIAL_SCENES.map((scene, idx) => {
              const isActive = currentSceneIdx === idx;
              return (
                <div
                  key={scene.id}
                  onClick={() => handleJumpToScene(idx)}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between space-y-2 ${
                    isActive
                      ? 'bg-indigo-950/40 border-indigo-500 text-white shadow-lg ring-2 ring-indigo-500/20'
                      : 'bg-slate-950 border-slate-800/80 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className={`text-[10px] font-black px-2 py-0.5 rounded-md ${
                      isActive ? 'bg-indigo-600 text-white' : 'bg-slate-900 text-slate-400'
                    }`}>
                      خطوة {idx + 1}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500">{scene.timeRange}</span>
                  </div>

                  <h4 className={`text-xs font-black leading-snug ${isActive ? 'text-white' : 'text-slate-300'}`}>
                    {scene.title}
                  </h4>

                  <ul className="space-y-1 text-[10px] text-slate-400 leading-tight">
                    {scene.bulletPoints.map((pt, i) => (
                      <li key={i} className="flex items-start gap-1">
                        <span className="text-indigo-400">•</span>
                        <span>{pt}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>

          {/* Bottom Call to Action */}
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-emerald-950 via-slate-900 to-indigo-950 border border-emerald-500/30 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-1 text-center sm:text-right">
              <div className="flex items-center gap-1.5 justify-center sm:justify-start text-emerald-400 text-xs font-black">
                <CheckCircle2 className="w-4 h-4" />
                <span>جاهز للبدء والنجاح بالوزاري؟</span>
              </div>
              <p className="text-xs text-slate-300">
                افتح مادتك الآن بـ 10,000 د.ع فقط وابدأ القراءة والاختبار الفوري فوراً.
              </p>
            </div>

            <div className="flex items-center gap-2.5 w-full sm:w-auto">
              <button
                onClick={handleStartSubscribing}
                className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 transition-transform active:scale-95 cursor-pointer"
              >
                <Unlock className="w-4 h-4 text-amber-300" />
                <span>ابدأ الاشتراك الآن 🚀</span>
              </button>

              <button
                onClick={closeModal}
                className="px-4 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
