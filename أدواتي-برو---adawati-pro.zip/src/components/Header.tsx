import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  BookOpen,
  FolderLock,
  SearchCheck,
  Timer,
  ShieldAlert,
  Send,
  Sparkles,
  Smartphone,
  LayoutDashboard,
  Grid,
  Download,
  PlayCircle,
  Menu,
  X,
  GraduationCap,
  Bell,
  Edit3,
  Sun,
  Moon,
  Code2,
  KeyRound,
  ShieldCheck
} from 'lucide-react';

export const Header: React.FC = () => {
  const {
    viewMode,
    setViewMode,
    openModal,
    unlockedBookIds,
    paymentInfo,
    unreadNotificationsCount,
    setActiveReadingBook,
    isSupervisor,
    showToast
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleWhatsAppSupport = () => {
    const text = encodeURIComponent('مرحباً منصة طلبتي، أحتاج مساعدة بخصوص تحميل المناهج أو الملازم الدراسية.');
    window.open(`https://wa.me/${paymentInfo.supportPhone}?text=${text}`, '_blank');
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-950/95 backdrop-blur-xl border-b border-slate-800 text-white shadow-xl">
      {/* Top Bar for View Modes Switcher */}
      <div className="bg-slate-900/90 border-b border-slate-800/80 px-4 py-2">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          {/* Mode Switcher Tabs */}
          <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-2xl border border-slate-800">
            <button
              onClick={() => {
                setViewMode('showcase-gallery');
                showToast('تم التبديل إلى استعراض الشاشات الخمس للتطبيق والتصميم الكامل 🖼️', 'info');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                viewMode === 'showcase-gallery'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Grid className="w-3.5 h-3.5" />
              <span>معرض الشاشات الخمس (Showcase)</span>
            </button>

            <button
              onClick={() => {
                setViewMode('mobile-app');
                showToast('تم فتح الهاتف التفاعلي 📱 - جرب التنقل بين الشاشات والتحميل!', 'info');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                viewMode === 'mobile-app'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>تطبيق الهاتف التفاعلي 📱</span>
            </button>

            <button
              onClick={() => {
                setViewMode('admin-dashboard');
                showToast('تم فتح لوحة تحكم الإدارة الكاملة 💻', 'info');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                viewMode === 'admin-dashboard'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span>لوحة الإدارة والإحصائيات</span>
            </button>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2 text-xs">
            <button
              onClick={() => openModal('supervisor-login')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-xl transition-colors font-bold cursor-pointer ${
                isSupervisor
                  ? 'text-amber-300 bg-amber-500/20 border border-amber-400/50 shadow-sm shadow-amber-500/20'
                  : 'text-amber-400 hover:text-white bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>{isSupervisor ? 'المشرف العام (نشط) 👑' : 'كود المشرف 👑'}</span>
            </button>

            <button
              onClick={() => {
                openModal('deploy-guide');
                showToast('تم فتح مركز نسخ كود السيرفر والنشر السحابي (Vercel/GitHub) 📋', 'info');
              }}
              className="flex items-center gap-1 text-blue-300 hover:text-white bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/30 px-2.5 py-1 rounded-xl transition-colors font-bold cursor-pointer"
            >
              <Code2 className="w-3.5 h-3.5 text-blue-400" />
              <span>نسخ كود السيرفر 📋</span>
            </button>

            <button
              onClick={() => openModal('activation-code')}
              className="flex items-center gap-1 text-cyan-300 hover:text-white bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 px-2.5 py-1 rounded-xl transition-colors font-bold cursor-pointer"
            >
              <KeyRound className="w-3.5 h-3.5 text-cyan-400" />
              <span>تفعيل بكود 🔑</span>
            </button>

            <button
              onClick={() => openModal('notes-modal')}
              className="flex items-center gap-1 text-slate-300 hover:text-blue-400 px-2 py-1 rounded-lg hover:bg-slate-800 transition-colors"
            >
              <Edit3 className="w-3.5 h-3.5 text-purple-400" />
              <span>الملاحظات الدراسية</span>
            </button>

            <button
              onClick={() => openModal('notifications-modal')}
              className="relative flex items-center gap-1 text-slate-300 hover:text-blue-400 px-2 py-1 rounded-lg hover:bg-slate-800 transition-colors"
            >
              <Bell className="w-3.5 h-3.5 text-cyan-400" />
              <span>الإشعارات</span>
              {unreadNotificationsCount > 0 && (
                <span className="w-2 h-2 rounded-full bg-blue-500"></span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Main Header Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          {/* Logo & Platform Name */}
          <div
            onClick={() => {
              setActiveReadingBook(null);
              setViewMode('showcase-gallery');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-3 cursor-pointer group select-none"
          >
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-500 flex items-center justify-center text-white shadow-lg shadow-blue-600/30 group-hover:scale-105 transition-transform">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-black tracking-tight text-white font-['Tajawal']">
                  منصة <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-cyan-300 to-indigo-300">طلبتي</span>
                </span>
                <span className="text-[10px] font-black bg-blue-500/20 text-blue-300 border border-blue-500/30 px-2 py-0.5 rounded-full hidden sm:inline-block">
                  المناهج الوزارية 2026 🇮🇶
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium hidden sm:block">
                جميع الكتب الدراسية والمناهج المعتمدة في مكان واحد
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-2 bg-slate-900/90 p-1.5 rounded-2xl border border-slate-800">
            <button
              onClick={() => {
                setViewMode('mobile-app');
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black text-white hover:bg-slate-800 transition-all cursor-pointer"
            >
              <Smartphone className="w-4 h-4 text-blue-400" />
              <span>تطبيق الهاتف</span>
            </button>

            <button
              onClick={() => openModal('install-app')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black text-emerald-300 hover:text-white bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 transition-all cursor-pointer"
            >
              <Download className="w-4 h-4 text-emerald-400" />
              <span>تثبيت PWA</span>
            </button>

            <button
              onClick={() => openModal('my-books')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-slate-200 hover:text-white hover:bg-slate-800 transition-all cursor-pointer relative"
            >
              <FolderLock className="w-4 h-4 text-emerald-400" />
              <span>التحميلات الأوفلاين</span>
              {unlockedBookIds.length > 0 && (
                <span className="w-2 h-2 rounded-full bg-emerald-500 absolute top-1.5 left-1.5" />
              )}
            </button>

            <button
              onClick={() => openModal('exam-countdown')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-slate-200 hover:text-white hover:bg-slate-800 transition-all cursor-pointer"
            >
              <Timer className="w-4 h-4 text-rose-400" />
              <span>جدول الامتحانات الوزارية</span>
            </button>
          </nav>

          {/* Action buttons */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={handleWhatsAppSupport}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black shadow-lg shadow-emerald-600/30 transition-transform hover:scale-105 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">الدعم والمساعدة</span>
            </button>

            {/* Mobile Menu Trigger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown */}
        {mobileMenuOpen && (
          <div className="lg:hidden pb-4 pt-2 border-t border-slate-800 space-y-2 animate-in slide-in-from-top-2 duration-200">
            <button
              onClick={() => {
                setViewMode('showcase-gallery');
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs font-black text-white"
            >
              <span>معرض الشاشات الخمس للتطبيق 🖼️</span>
              <Grid className="w-4 h-4 text-blue-400" />
            </button>

            <button
              onClick={() => {
                setViewMode('mobile-app');
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-between p-3 rounded-xl bg-blue-600 text-xs font-black text-white"
            >
              <span>فتح تطبيق الهاتف التفاعلي 📱</span>
              <Smartphone className="w-4 h-4 text-white" />
            </button>

            <button
              onClick={() => {
                setViewMode('admin-dashboard');
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs font-black text-slate-200"
            >
              <span>لوحة تحكم الإدارة الكاملة 💻</span>
              <LayoutDashboard className="w-4 h-4 text-blue-400" />
            </button>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                openModal('install-app');
              }}
              className="w-full flex items-center justify-between p-3 rounded-xl bg-emerald-600 text-xs font-black text-white"
            >
              <span>تثبيت التطبيق على جهازك 📲</span>
              <Download className="w-4 h-4 text-white" />
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
