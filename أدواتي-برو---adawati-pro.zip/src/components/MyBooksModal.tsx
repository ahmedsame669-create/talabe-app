import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  FolderLock,
  BookOpen,
  Search,
  CheckCircle2,
  PenTool,
  Award
} from 'lucide-react';

export const MyBooksModal: React.FC = () => {
  const {
    activeModal,
    closeModal,
    books,
    unlockedBookIds,
    orders,
    approveOrder,
    setActiveReadingBook,
    openQuizModalForBook,
    showToast,
  } = useApp();

  const [searchPhone, setSearchPhone] = useState('');

  if (activeModal !== 'my-books') return null;

  const unlockedBooks = books.filter((b) => unlockedBookIds.includes(b.id));

  const handleSearchByPhone = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchPhone.trim()) return;

    const clean = searchPhone.trim();

    const matchedOrders = orders.filter(
      (o) => o.phone.includes(clean) || o.transaction_ref.toLowerCase().includes(clean.toLowerCase())
    );

    if (matchedOrders.length > 0) {
      matchedOrders.forEach((o) => {
        if (o.status === 'تم التفعيل والفتح') {
          approveOrder(o.id);
        }
      });
      showToast(`تم العثور على ${matchedOrders.length} طلبات مسجلة برقمك`, 'success');
    } else {
      showToast('لم يتم العثور على طلبات مفعلة بهذا الرقم حتى الآن', 'info');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-8 animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 flex items-center justify-center text-white shadow-md">
              <FolderLock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black">
                خزانة موادي ومرشحاتي المفعلة
              </h2>
              <p className="text-xs text-slate-300">
                المواد التي قمت بفتحها وتفعيلها للقراءة والاختبار
              </p>
            </div>
          </div>

          <button
            onClick={closeModal}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search by phone box */}
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
          <form onSubmit={handleSearchByPhone} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3.5" />
              <input
                type="text"
                value={searchPhone}
                onChange={(e) => setSearchPhone(e.target.value)}
                placeholder="أدخل رقم هاتفك أو رقم الوصل للبحث عن مشترياتك..."
                className="w-full pl-3 pr-10 py-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500"
              />
            </div>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-colors cursor-pointer"
            >
              استرجاع موادي
            </button>
          </form>
        </div>

        {/* Books List Content */}
        <div className="p-6 max-h-[60vh] overflow-y-auto space-y-4">
          {unlockedBooks.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {unlockedBooks.map((book) => (
                <div
                  key={book.id}
                  className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 flex flex-col justify-between space-y-3 hover:border-emerald-500 transition-colors"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] font-bold bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 px-2 py-0.5 rounded-md">
                        مفعلة وجاهزة ✓
                      </span>
                      <span className="text-[10px] text-amber-500 font-extrabold">
                        {book.grade}
                      </span>
                    </div>

                    <h4 className="text-sm font-black text-slate-900 dark:text-white line-clamp-2">
                      {book.title}
                    </h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                      {book.targetGuarantee}
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button
                      onClick={() => {
                        closeModal();
                        setActiveReadingBook(book);
                      }}
                      className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/30 transition-transform active:scale-95 cursor-pointer"
                    >
                      <BookOpen className="w-4 h-4" />
                      <span>تصفح</span>
                    </button>

                    <button
                      onClick={() => {
                        closeModal();
                        openQuizModalForBook(book);
                      }}
                      className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-black flex items-center justify-center gap-1.5 shadow-md shadow-purple-600/30 transition-transform active:scale-95 cursor-pointer"
                    >
                      <PenTool className="w-3.5 h-3.5 text-amber-300" />
                      <span>امتحن نفسي</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-10 space-y-3 text-slate-500 dark:text-slate-400">
              <div className="w-14 h-14 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto text-slate-400">
                <FolderLock className="w-7 h-7" />
              </div>
              <h4 className="text-sm font-black text-slate-700 dark:text-slate-200">
                لا توجد مواد مفعلة في هذا الجهاز حالياً
              </h4>
              <p className="text-xs max-w-sm mx-auto leading-relaxed">
                إذا قمت بالتحويل مسبقاً، أدخل رقم هاتفك بالأعلى لاسترجاع موادك، أو تصفح المنصة وافتح مادتك بـ 10,000 د.ع فقط مع ميزة الاختبار الفوري.
              </p>
              <button
                onClick={closeModal}
                className="mt-2 px-5 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-500 transition-colors cursor-pointer"
              >
                تصفح بنك المرشحات
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
