import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { EducationalStage } from '../types';
import {
  X,
  Timer,
  Calendar,
  Sparkles,
  Award,
  Zap,
  GraduationCap
} from 'lucide-react';

interface StageSchedule {
  stage: EducationalStage;
  stageName: string;
  startDate: string;
  exams: {
    subject: string;
    day: string;
    date: string;
    focusTip: string;
  }[];
}

const SCHEDULES_DATA: StageSchedule[] = [
  {
    stage: 'الثالث متوسط',
    stageName: 'الثالث المتوسط',
    startDate: '1 حزيران 2026',
    exams: [
      { subject: 'التربية الإسلامية واللغة العربية', day: 'الأحد', date: '2026/06/01', focusTip: 'التركيز على قواعد الصفة المشبهة واسم الفاعل وإنشاء الوطن والعلم' },
      { subject: 'اللغة الإنكليزية', day: 'الثلاثاء', date: '2026/06/03', focusTip: 'قطع الكتاب الأهم: سيارة البانثر ولوسي، وإنشاء دعوة صديق' },
      { subject: 'الرياضيات', day: 'الخميس', date: '2026/06/05', focusTip: 'تطبيقات الجذور والتربيعية، حل المعادلات بالدستور، والمتباينة المطلقة' },
      { subject: 'الاجتماعيات', day: 'الأحد', date: '2026/06/08', focusTip: 'تعاليل ثورة العشرين، أسباب سقوط بغداد، والمناخ والتضاريس' },
      { subject: 'صحة وبيئة والإنسان', day: 'الثلاثاء', date: '2026/06/10', focusTip: 'الجهاز العضلي والهيكلي، الدورة الدموية الكبرى والصغرى' },
      { subject: 'الكيمياء', day: 'الخميس', date: '2026/06/12', focusTip: 'الترتيب الإلكتروني، استخراج الصوديوم والكلور، وحساب النسبة الكتلية' },
      { subject: 'الفيزياء', day: 'الأحد', date: '2026/06/15', focusTip: 'قانون كولوم، ربط المقاومات على التوالي والتوازي، وقدرة الأجهزة' }
    ]
  },
  {
    stage: 'السادس علمي',
    stageName: 'السادس العلمي',
    startDate: '15 حزيران 2026',
    exams: [
      { subject: 'التربية الإسلامية', day: 'الإثنين', date: '2026/06/15', focusTip: 'أحاديث النهي عن الغضب وحقوق الوالدين، مع أحكام التلاوة' },
      { subject: 'اللغة العربية', day: 'الأربعاء', date: '2026/06/17', focusTip: 'إعراب أسماء الاستفهام وأدوات النفي (لم، لما، لن، ما)' },
      { subject: 'اللغة الإنكليزية', day: 'السبت', date: '2026/06/20', focusTip: 'قطع زيد طارق ورادار السرعة، وإنشاء يوم سيء أو عطلة ممتعة' },
      { subject: 'الأحياء', day: 'الإثنين', date: '2026/06/22', focusTip: 'مقارنات الانقسام الاختزالي، دورة كريبس، وقوانين مندل الوراثية' },
      { subject: 'الرياضيات', day: 'الخميس', date: '2026/06/25', focusTip: 'مبرهنة ديموافر، التقريب باستخدام رول والقيمة المتوسطة، والمساحات' },
      { subject: 'الكيمياء', day: 'الأحد', date: '2026/06/28', focusTip: 'قانون هيس، محاليل بفر والأيون المشترك، وقوانين فرداي' },
      { subject: 'الفيزياء', day: 'الأربعاء', date: '2026/07/01', focusTip: 'ربط المتسعات، الحث الكهرومغناطيسي، والظاهرة الكهروضوئية' }
    ]
  },
  {
    stage: 'السادس أدبي',
    stageName: 'السادس الأدبي',
    startDate: '16 حزيران 2026',
    exams: [
      { subject: 'اللغة العربية', day: 'الثلاثاء', date: '2026/06/16', focusTip: 'أساليب الطلب، الاستثناء، وشعراء مدرسة الإحياء والمهجر' },
      { subject: 'التاريخ', day: 'الخميس', date: '2026/06/18', focusTip: 'معاهدة 1930، ثورة العشرين في الفرات الأوسط، وحكم مدحت باشا' },
      { subject: 'الجغرافيا', day: 'الأحد', date: '2026/06/21', focusTip: 'توزيع السكان وهجرتهم، العوامل الطبيعية المؤثرة بالزراعة' },
      { subject: 'الاقتصاد', day: 'الثلاثاء', date: '2026/06/23', focusTip: 'التضخم والبطالة، الدخل القومي، والسياسة النقدية للبنك المركزي' }
    ]
  },
  {
    stage: 'الابتدائية',
    stageName: 'السادس الابتدائي',
    startDate: '12 آيار 2026',
    exams: [
      { subject: 'التربية الإسلامية', day: 'الثلاثاء', date: '2026/05/12', focusTip: 'سورة النجم، الحديث النبوي الشريف في الحث على طلب العلم' },
      { subject: 'اللغة العربية', day: 'الخميس', date: '2026/05/14', focusTip: 'المبتدأ والخبر، كان وأخواتها، وإن وأخواتها، والفاعل' },
      { subject: 'اللغة الإنكليزية', day: 'الأحد', date: '2026/05/17', focusTip: 'العائلة والوظائف، المعاكسات البسيطة، وإنشاء اكتب عن نفسك وعائلتك' },
      { subject: 'الرياضيات', day: 'الثلاثاء', date: '2026/05/19', focusTip: 'الكسور العشرية، النسبة والتناسب، ومقياس الرسم والمحيط' },
      { subject: 'العلوم', day: 'الخميس', date: '2026/05/21', focusTip: 'التكاثر بالبذور والدرنات، الجهاز العصبي، والكتلة والوزن' }
    ]
  }
];

export const MinisterialExamCountdown: React.FC = () => {
  const { activeModal, closeModal, setSelectedGrade } = useApp();
  const [selectedTab, setSelectedTab] = useState<EducationalStage>('الثالث متوسط');

  if (activeModal !== 'exam-countdown') return null;

  const currentSchedule = SCHEDULES_DATA.find((s) => s.stage === selectedTab) || SCHEDULES_DATA[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl bg-slate-900 rounded-3xl shadow-2xl border border-slate-800 overflow-hidden my-8 text-white font-['Tajawal']">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-600 flex items-center justify-center text-white shadow-md">
              <Timer className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black">
                جدول ومواعيد الامتحانات الوزارية 2026
              </h2>
              <p className="text-xs text-slate-400">
                مواعيد الامتحانات الرسمية للثالث المتوسط والسادس الإعدادي والابتدائي
              </p>
            </div>
          </div>

          <button
            onClick={closeModal}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stage Selector Tabs */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center gap-2 overflow-x-auto">
          {SCHEDULES_DATA.map((s) => {
            const isSelected = selectedTab === s.stage;
            return (
              <button
                key={s.stage}
                onClick={() => setSelectedTab(s.stage)}
                className={`px-4 py-2 rounded-xl text-xs font-black transition-all whitespace-nowrap cursor-pointer ${
                  isSelected
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30 scale-105'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {s.stageName}
              </button>
            );
          })}
        </div>

        {/* Motivational Banner */}
        <div className="p-4 bg-blue-950/40 border-b border-blue-900/60 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-blue-400 shrink-0" />
            <span className="text-blue-200 font-bold">
              تاريخ انطلاق امتحانات {currentSchedule.stageName}: <strong className="text-rose-400 font-mono text-sm">{currentSchedule.startDate}</strong>
            </span>
          </div>

          <button
            onClick={() => {
              setSelectedGrade(currentSchedule.stage);
              closeModal();
            }}
            className="px-3 py-1.5 rounded-lg bg-blue-600 text-white text-[11px] font-black hover:bg-blue-500 transition-colors shrink-0 cursor-pointer"
          >
            عرض مرشحات الصف
          </button>
        </div>

        {/* Subjects Schedule List */}
        <div className="p-6 max-h-[60vh] overflow-y-auto space-y-3">
          {currentSchedule.exams.map((exam, idx) => (
            <div
              key={idx}
              className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 hover:border-blue-500 transition-colors text-right"
            >
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2 text-xs">
                  <span className="font-bold text-slate-400">{exam.day}</span>
                  <span className="px-2.5 py-1 rounded-lg bg-rose-500/10 text-rose-400 font-mono font-bold border border-rose-500/20">
                    {exam.date}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <h4 className="text-sm font-black text-white">
                    {exam.subject}
                  </h4>
                  <span className="w-6 h-6 rounded-lg bg-blue-600 text-white text-xs font-mono font-bold flex items-center justify-center">
                    {idx + 1}
                  </span>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-200 text-xs flex items-center justify-end gap-2 text-right">
                <span className="font-medium">
                  <strong>نصيحة الثوابت:</strong> {exam.focusTip}
                </span>
                <Zap className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
