import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Smartphone,
  Apple,
  Download,
  Share2,
  PlusSquare,
  CheckCircle2,
  Sparkles,
  Zap,
  ShieldCheck,
  Globe,
  Monitor,
  Laptop,
  ArrowRight,
  ExternalLink,
  ChevronRight,
  Tablet,
  Check
} from 'lucide-react';

export const InstallAppModal: React.FC = () => {
  const {
    activeModal,
    closeModal,
    isIOS,
    isAndroid,
    isInstalled,
    isInstallable,
    promptInstall,
    showToast
  } = useApp();

  const [activeTab, setActiveTab] = useState<'android' | 'ios' | 'desktop'>(
    isIOS ? 'ios' : 'android'
  );

  const [copiedLink, setCopiedLink] = useState(false);

  if (activeModal !== 'install-app') return null;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.origin);
    setCopiedLink(true);
    showToast('تم نسخ رابط المنصة للمشاركة أو الفتح في المتصفح ✅', 'success');
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleAndroidDirectInstall = () => {
    promptInstall();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-4 sm:my-8 text-slate-900 dark:text-white">
        {/* Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-500 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-600/30">
              <Download className="w-5 h-5 animate-bounce" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-black border border-emerald-500/30">
                  تطبيق رسمي خفيف وسريع
                </span>
                <span className="text-[10px] text-amber-300 font-bold">بدون متجر وبدون مساحة</span>
              </div>
              <h2 className="text-base sm:text-lg font-black">
                تثبيت تطبيق «منصة طلبتي» على جهازك
              </h2>
            </div>
          </div>

          <button
            onClick={closeModal}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection (Android, Apple iOS, Desktop) */}
        <div className="p-3 bg-slate-100 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 grid grid-cols-3 gap-2 text-xs">
          <button
            onClick={() => setActiveTab('android')}
            className={`py-2.5 px-3 rounded-xl font-black flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeTab === 'android'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30 scale-102'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <Smartphone className="w-4 h-4 text-emerald-300" />
            <span>أجهزة أندرويد (Android)</span>
          </button>

          <button
            onClick={() => setActiveTab('ios')}
            className={`py-2.5 px-3 rounded-xl font-black flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeTab === 'ios'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 scale-102'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <Apple className="w-4 h-4 text-slate-100" />
            <span>أجهزة آبل (iPhone / iPad)</span>
          </button>

          <button
            onClick={() => setActiveTab('desktop')}
            className={`py-2.5 px-3 rounded-xl font-black flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeTab === 'desktop'
                ? 'bg-slate-800 text-white shadow-md scale-102'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <Laptop className="w-4 h-4 text-amber-300" />
            <span>كمبيوتر / لابتوب</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-5 sm:p-6 space-y-5 max-h-[65vh] overflow-y-auto">
          {/* ANDROID TAB */}
          {activeTab === 'android' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              {/* Direct Install Banner */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-indigo-500/10 border border-emerald-500/30 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="space-y-1 text-center sm:text-right">
                  <div className="flex items-center gap-1.5 justify-center sm:justify-start text-emerald-600 dark:text-emerald-400 text-xs font-black">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>جاهز للتثبيت الفوري على هاتفك</span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300">
                    أيقونة مباشرة على شاشة هاتفك مع سرعة مضاعفة وبدون الحاجة لفتح المتصفح كل مرة.
                  </p>
                </div>

                <button
                  onClick={handleAndroidDirectInstall}
                  className="w-full sm:w-auto px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 transition-transform active:scale-95 cursor-pointer shrink-0"
                >
                  <Download className="w-4 h-4 text-white" />
                  <span>تثبيت التطبيق الآن 📱</span>
                </button>
              </div>

              {/* Step by step for Android */}
              <div className="space-y-3">
                <h4 className="text-xs font-black text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  طريقة التثبيت اليدوي عبر متصفح كروم (Google Chrome):
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 space-y-2 text-center">
                    <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white font-black text-xs flex items-center justify-center mx-auto">
                      1
                    </div>
                    <h5 className="text-xs font-black text-slate-900 dark:text-white">
                      افتح القائمة ⋮
                    </h5>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                      اضغط على النقاط الثلاث (⋮) في أعلى يسار أو يمين متصفح Google Chrome.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 space-y-2 text-center">
                    <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white font-black text-xs flex items-center justify-center mx-auto">
                      2
                    </div>
                    <h5 className="text-xs font-black text-slate-900 dark:text-white">
                      اختر «تثبيت التطبيق»
                    </h5>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                      انقر على خيار <strong>«تثبيت التطبيق»</strong> أو <strong>«إضافة إلى الشاشة الرئيسية»</strong>.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 space-y-2 text-center">
                    <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white font-black text-xs flex items-center justify-center mx-auto">
                      3
                    </div>
                    <h5 className="text-xs font-black text-slate-900 dark:text-white">
                      تم التثبيت ✓
                    </h5>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                      ستظهر أيقونة «منصة طلبتي» على شاشة هاتفك مع الملازم والاختبارات الفورية!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* APPLE IOS TAB */}
          {activeTab === 'ios' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="p-4 rounded-2xl bg-gradient-to-r from-indigo-500/10 via-purple-500/10 to-pink-500/10 border border-indigo-500/30 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-md">
                  <Apple className="w-5 h-5" />
                </div>
                <div className="text-xs">
                  <span className="font-black text-indigo-900 dark:text-indigo-200 block">
                    تثبيت سهل وسريع على أجهزة iPhone و iPad:
                  </span>
                  <span className="text-slate-500 dark:text-slate-400 text-[11px]">
                    يعمل التطبيق كـ Web App متكامل بملء الشاشة مع كافة المزايا دون الحاجة لحساب App Store.
                  </span>
                </div>
              </div>

              {/* iOS 3-Step Illustrated Guide */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 space-y-2.5 text-center">
                  <div className="w-10 h-10 rounded-2xl bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20 flex items-center justify-center mx-auto">
                    <Share2 className="w-5 h-5" />
                  </div>
                  <div className="text-[11px] font-black text-indigo-600 dark:text-indigo-400">
                    الخطوة الأولى
                  </div>
                  <h5 className="text-xs font-black text-slate-900 dark:text-white">
                    اضغط زر المشاركة (Share)
                  </h5>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                    من متصفح Safari بالأسفل، اضغط على زر المشاركة <strong>(مربع فيه سهم لأعلى ⎋)</strong>.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 space-y-2.5 text-center">
                  <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 flex items-center justify-center mx-auto">
                    <PlusSquare className="w-5 h-5" />
                  </div>
                  <div className="text-[11px] font-black text-indigo-600 dark:text-indigo-400">
                    الخطوة الثانية
                  </div>
                  <h5 className="text-xs font-black text-slate-900 dark:text-white">
                    إضافة إلى الشاشة الرئيسية
                  </h5>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                    مرر لأسفل القائمة وانقر على خيار <strong>«Add to Home Screen»</strong> أو <strong>«إضافة إلى الصفحة الرئيسية ⊞»</strong>.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 space-y-2.5 text-center">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div className="text-[11px] font-black text-emerald-600 dark:text-emerald-400">
                    الخطوة الثالثة
                  </div>
                  <h5 className="text-xs font-black text-slate-900 dark:text-white">
                    اضغط «إضافة (Add)»
                  </h5>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                    انقر فوق زر <strong>Add (إضافة)</strong> في أعلى الزاوية، وسيثبت التطبيق بجانب تطبيقاتك!
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* DESKTOP TAB */}
          {activeTab === 'desktop' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center shrink-0">
                    <Laptop className="w-5 h-5 text-amber-300" />
                  </div>
                  <div>
                    <h5 className="text-xs font-black text-slate-900 dark:text-white">
                      تثبيت تطبيق طلبتي على الكمبيوتر (Windows / Mac)
                    </h5>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      تصفح الملازم واختبر نفسك على شاشة كبيرة وبأداء سريع جداً.
                    </p>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs space-y-2">
                  <div className="flex items-center gap-2 font-bold text-slate-700 dark:text-slate-200">
                    <Check className="w-4 h-4 text-emerald-500" />
                    <span>في متصفح Chrome أو Edge: اضغط على أيقونة التثبيت ⊕ في شريط العنوان (URL).</span>
                  </div>
                  <div className="flex items-center gap-2 font-bold text-slate-700 dark:text-slate-200">
                    <Check className="w-4 h-4 text-emerald-500" />
                    <span>أو اضغط على القائمة (⋮) ثم «حفظ ومشاركة» ➔ «تثبيت منصة طلبتي».</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* App Features Grid */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-3">
            <h4 className="text-xs font-black text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>لماذا يُفضل تثبيت تطبيق طلبتي على هاتفك؟</span>
            </h4>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
              <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-1">
                <Zap className="w-4 h-4 text-amber-500 mx-auto" />
                <span className="font-bold block text-[11px]">سرعة فائقة</span>
                <span className="text-[9px] text-slate-400">فتح فوري بدون بطء</span>
              </div>

              <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-1">
                <ShieldCheck className="w-4 h-4 text-emerald-500 mx-auto" />
                <span className="font-bold block text-[11px]">حفظ تلقائي</span>
                <span className="text-[9px] text-slate-400">لموادك ونتائجك</span>
              </div>

              <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-1">
                <Smartphone className="w-4 h-4 text-indigo-500 mx-auto" />
                <span className="font-bold block text-[11px]">شاشة كاملة</span>
                <span className="text-[9px] text-slate-400">تجربة تطبيق احترافي</span>
              </div>

              <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-1">
                <Download className="w-4 h-4 text-rose-500 mx-auto" />
                <span className="font-bold block text-[11px]">حجم خفيف</span>
                <span className="text-[9px] text-slate-400">أقل من 2MB فقط</span>
              </div>
            </div>
          </div>

          {/* Quick Share Link */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs">
            <div className="flex items-center gap-2 text-slate-600 dark:text-slate-300 overflow-hidden">
              <Globe className="w-4 h-4 text-indigo-500 shrink-0" />
              <span className="truncate font-mono text-[11px]">{typeof window !== 'undefined' ? window.location.origin : 'talabati.iq'}</span>
            </div>

            <button
              onClick={handleCopyLink}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[11px] transition-colors cursor-pointer shrink-0"
            >
              {copiedLink ? 'تم النسخ ✓' : 'نسخ الرابط'}
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-100 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span>متوافق 100% مع كافة هواتف الأندرويد والآيفون</span>
          </div>

          <button
            onClick={closeModal}
            className="px-5 py-2 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-black hover:opacity-90 transition-opacity cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
