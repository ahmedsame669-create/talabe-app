export type SubjectCategory =
  | 'all'
  | 'الرياضيات'
  | 'اللغة العربية'
  | 'اللغة الإنجليزية'
  | 'العلوم'
  | 'الاجتماعيات'
  | 'التربية الإسلامية'
  | 'الحاسوب'
  | 'الكيمياء'
  | 'الفيزياء'
  | 'الأحياء'
  | 'تاريخ'
  | 'جغرافيا'
  | 'اقتصاد'
  | 'قواعد ولغة'
  | 'أخرى';

export type EducationalStage =
  | 'all'
  | 'السادس علمي'
  | 'السادس أدبي'
  | 'السادس أحيائي'
  | 'السادس تطبيقي'
  | 'الثالث متوسط'
  | 'الثاني متوسط'
  | 'الأول متوسط'
  | 'السادس ابتدائي'
  | 'الابتدائية'
  | 'السادس إعدادي'
  | 'الخامس إعدادي'
  | 'الرابع إعدادي';

export type PaymentMethod =
  | 'زين كاش'
  | 'ماستر كارد الرافدين'
  | 'ماستر كارد الرشيد'
  | 'آسيا حوالة'
  | 'تحميل مجاني';

export type OrderStatus = 'قيد التحقق' | 'تم التفعيل والفتح' | 'مرفوض';

export interface SamplePage {
  pageNumber: number;
  title: string;
  subtitle?: string;
  content: string[];
  ministerialNote?: string;
  importantFormulas?: string[];
  questionSnippet?: {
    question: string;
    answer: string;
  };
}

export interface MinisterialQuestionItem {
  id: number;
  question: string;
  answer: string;
  topic?: string;
  isImportant?: boolean;
  type?: 'تعليل' | 'تعريف' | 'ثابت وزاري' | 'مسألة' | 'مقارنة' | 'إنشاء' | 'فراغ وزاري';
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
}

export interface BookItem {
  id: number;
  title: string;
  category: SubjectCategory;
  grade: EducationalStage;
  desc: string;
  targetGuarantee: string; // e.g. "طبعة 2026 المعتمدة"
  pagesCount: number;
  yearEdition: string;
  fileSize: string; // e.g. "18.7 MB"
  fileFormat: string; // "PDF"
  author: string; // "منصة طلبتي التعليمية"
  price: string; // "10,000 د.ع"
  badge?: string;
  rating: number;
  reviewsCount: number;
  downloadsCount: number;
  gradient: string;
  coverImage?: string;
  samplePages: SamplePage[];
  ministerialArchive?: MinisterialQuestionItem[];
  quiz?: QuizQuestion[];
  fullSummaryUrl?: string;
  downloadUrl?: string;
  pdfDataUrl?: string; // Data URL / Base64 of uploaded PDF file
  customPdfUrl?: string; // External PDF link
  pdfFileName?: string;
  isEditable?: boolean;
  lastEditedBy?: string;
  lastEditedAt?: string;
  isFavorite?: boolean;
  isDownloaded?: boolean;
  createdAt?: string;
}

export interface StudyNote {
  id: string;
  bookId: number;
  bookTitle: string;
  pageNumber?: number;
  title: string;
  content: string;
  color: string;
  date: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  type: 'book' | 'update' | 'quiz' | 'alert';
  read: boolean;
}

export interface PaymentInfo {
  zainCash: string;
  rafidainCard: string;
  rasheedCard: string;
  asiaHawala: string;
  price: string;
  supportPhone: string;
  supportTelegram: string;
  whatsappMessageTemplate?: string;
}

export interface Order {
  id: string;
  student_name: string;
  phone: string;
  governorate?: string;
  book_id: number;
  book_title: string;
  payment_method: PaymentMethod;
  transaction_ref: string;
  price: string;
  status: OrderStatus;
  created_at: string;
  receipt_img?: string;
  admin_notes?: string;
}

export interface MinisterialExamDate {
  subject: string;
  date: string;
  timeRemainingDays: number;
  tips: string;
}

export interface ActivationCode {
  id: string;
  code: string;
  bookId: number | 'all';
  bookTitle: string;
  studentName?: string;
  studentPhone?: string;
  isUsed: boolean;
  usedBy?: string;
  usedAt?: string;
  createdAt: string;
  createdBy: string;
}

export interface UserProfile {
  name: string;
  email: string;
  role: 'طالب' | 'معلم' | 'مشرف' | 'مدير';
  badge: string;
  avatarUrl?: string;
  phone?: string;
  grade?: EducationalStage | string;
  governorate?: string;
  joinedDate: string;
}

export interface RegisteredStudent {
  id: string;
  name: string;
  phone: string;
  governorate: string;
  grade: EducationalStage | string;
  registeredAt: string;
  unlockedSubjectsCount: number;
  lastActive: string;
  status: 'نشط' | 'محظور' | 'جديد';
}
